#pragma once

#include <cstring>
#include <string>
#include <vector>
#include <functional>
#include <string_view>

#include "util/types.hpp"

std::wstring utf8_to_wchar(std::string_view src);
std::string wchar_to_utf8(std::wstring_view src);
std::string utf16_to_utf8(std::u16string_view src);
std::u16string utf8_to_utf16(std::string_view src);

// Copy null-terminated string from a std::basic_string or a char array to a char array with truncation
template <typename D, typename T> requires requires (D& d, T& t) { std::declval<decltype(&t[0])&>() = &d[0]; }
inline void strcpy_trunc(D&& dst, const T& src)
{
	const usz count = std::size(src) >= std::size(dst) ? std::max<usz>(std::size(dst), 1) - 1 : std::size(src);
	std::copy_n(std::data(src), count, std::data(dst));
	std::fill_n(std::data(dst) + count, std::size(dst) - count, std::remove_cvref_t<decltype(dst[0])>{});
}

// Convert string to signed integer
bool try_to_int64(s64* out, std::string_view value, s64 min, s64 max, std::string_view name = {});

// Convert string to unsigned integer
bool try_to_uint64(u64* out, std::string_view value, u64 min, u64 max, std::string_view name = {});

// Convert string to unsigned int128_t
bool try_to_uint128(u128* out, std::string_view value, std::string_view name = {});

// Convert string to float
bool try_to_float(f64* out, std::string_view value, f64 min, f64 max, std::string_view name = {});

// Convert float to string locale independent
bool try_to_string(std::string* out, f64 value, std::string_view name = {});

// Get the file extension of a file path ("png", "jpg", etc.)
std::string get_file_extension(const std::string& file_path);

namespace fmt
{
	// Replaces all occurrences of 'from' with 'to' until 'count' substrings were replaced.
	std::string replace_all(std::string_view src, std::string_view from, std::string_view to, usz count = umax);

	template <usz list_size>
	std::string replace_all(std::string src, const std::pair<std::string_view, std::string> (&list)[list_size])
	{
		if constexpr (list_size == 0)
			return src;

		for (usz pos = 0; pos < src.length(); ++pos)
		{
			for (usz i = 0; i < list_size; ++i)
			{
				const usz comp_length = list[i].first.length();

				if (src.length() - pos < comp_length)
				{
					continue;
				}

				if (src.substr(pos, comp_length) == list[i].first)
				{
					src.erase(pos, comp_length);
					src.insert(pos, list[i].second.data(), list[i].second.length());
					pos += list[i].second.length() - 1;
					break;
				}
			}
		}

		return src;
	}

	template <usz list_size>
	std::string replace_all(std::string src, const std::pair<std::string_view, std::function<std::string()>> (&list)[list_size])
	{
		if constexpr (list_size == 0)
			return src;

		for (usz pos = 0; pos < src.length(); ++pos)
		{
			for (usz i = 0; i < list_size; ++i)
			{
				const usz comp_length = list[i].first.length();

				if (src.length() - pos < comp_length)
				{
					continue;
				}

				if (src.substr(pos, comp_length) == list[i].first)
				{
					src.erase(pos, comp_length);
					auto replacement = list[i].second();
					src.insert(pos, replacement);
					pos += replacement.length() - 1;
					break;
				}
			}
		}

		return src;
	}

	static inline
	std::string replace_all(std::string src, const std::vector<std::pair<std::string, std::string>>& list)
	{
		if (list.empty())
			return src;

		for (usz pos = 0; pos < src.length(); ++pos)
		{
			for (usz i = 0; i < list.size(); ++i)
			{
				const usz comp_length = list[i].first.length();

				if (src.length() - pos < comp_length)
				{
					continue;
				}

				if (src.substr(pos, comp_length) == list[i].first)
				{
					src.erase(pos, comp_length);
					src.insert(pos, list[i].second);
					pos += list[i].second.length() - 1;
					break;
				}
			}
		}

		return src;
	}

	// Splits the string into a vector of strings using the separators. The vector may contain empty strings unless is_skip_empty is true.
	std::vector<std::string> split(std::string_view source, std::initializer_list<std::string_view> separators, bool is_skip_empty = true);

	// Splits the string_view into a vector of string_views using the separators. The vector may contain empty string_views unless is_skip_empty is true.
	std::vector<std::string_view> split_sv(std::string_view source, std::initializer_list<std::string_view> separators, bool is_skip_empty = true);

	// Removes all preceding and trailing characters specified by 'values' from 'source'.
	std::string trim(const std::string& source, std::string_view values = " \t");

	// Removes all preceding and trailing characters specified by 'values' from 'source' and returns the result.
	std::string_view trim_sv(std::string_view source, std::string_view values = " \t");

	// Removes all preceding characters specified by 'values' from 'source'.
	std::string trim_front(const std::string& source, std::string_view values = " \t");

	// Removes all preceding characters specified by 'values' from 'source' and returns the result.
	std::string_view trim_front_sv(std::string_view source, std::string_view values = " \t");

	// Removes all trailing characters specified by 'values' from 'source'.
	void trim_back(std::string& source, std::string_view values = " \t");

	// Removes all trailing characters specified by 'values' from 'source' and returns the result.
	std::string_view trim_back_sv(std::string_view source, std::string_view values = " \t");

	template <typename T>
	std::string merge(const T& source, std::string_view separator, bool is_skip_empty = false)
	{
		if (source.empty())
		{
			return {};
		}

		usz total = (source.size() - 1) * separator.size();
		for (const auto& s : source)
		{
			total += s.size();
		}

		std::string result;
		result.reserve(total);

		auto it  = source.begin();
		auto end = source.end();

		if (is_skip_empty)
		{
			for (; it != end; ++it)
			{
				if (it->empty()) continue;

				if (!result.empty() && !separator.empty())
				{
					result.append(separator);
				}

				result.append(*it);
			}

			return result;
		}

		for (--end; it != end; ++it)
		{
			result.append(*it);

			if (!separator.empty())
				result.append(separator);
		}

		return result.append(*end);
	}

	template <typename T>
	std::string merge(std::initializer_list<T> sources, std::string_view separator, bool is_skip_empty = false)
	{
		if (!sources.size())
		{
			return {};
		}

		usz total = (sources.size() - 1) * separator.size();
		for (const auto& s : sources)
		{
			if (s.empty()) continue;
			total += s.size() + (s.size() - 1) * separator.size();
		}

		std::string result;
		result.reserve(total);

		bool first = true;

		for (const auto& v : sources)
		{
			if (v.empty()) continue;

			std::string sub = fmt::merge(v, separator, is_skip_empty);
			if (sub.empty()) continue;

			if (first)
			{
				first = false;
			}
			else if (!separator.empty())
			{
				result.append(separator);
			}

			result.append(std::move(sub));
		}

		return result;
	}

	// Returns the string transformed to uppercase
	std::string to_upper(std::string_view string);

	// Returns the string transformed to lowercase
	std::string to_lower(std::string_view string);

	// Returns the string shortened to length
	std::string truncate(std::string_view src, usz length);

	struct buf_to_hexstring
	{
		buf_to_hexstring(const u8* buf, usz len, usz line_length = 16, bool with_prefix = false)
			: buf(buf), len(len), line_length(line_length), with_prefix(with_prefix) {}

		const u8* buf;
		usz len;
		usz line_length;
		bool with_prefix;
	};

	struct string_hash
	{
		using hash_type = std::hash<std::string_view>;
		using is_transparent = void;

		std::size_t operator()(const char* str) const
		{
			return hash_type{}(str);
		}
		std::size_t operator()(std::string_view str) const
		{
			return hash_type{}(str);
		}
		std::size_t operator()(std::string const& str) const
		{
			return hash_type{}(str);
		}
	};
}
