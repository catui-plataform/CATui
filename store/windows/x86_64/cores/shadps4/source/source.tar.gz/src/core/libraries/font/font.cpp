// SPDX-FileCopyrightText: Copyright 2024 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include <algorithm>
#include <array>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdarg>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <limits>
#include <memory>
#include <mutex>
#include <new>
#include <optional>
#include <string>
#include <system_error>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <fmt/format.h>
#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_TRUETYPE_TABLES_H
#include "common/logging/log.h"
#include "core/emulator_settings.h"
#include "core/file_sys/fs.h"
#include "core/libraries/error_codes.h"
#include "core/libraries/font/font.h"
#include "core/libraries/font/font_internal.h"
#include "core/libraries/font/fontft.h"
#include "core/libraries/font/fontft_internal.h"
#include "core/libraries/kernel/kernel.h"
#include "core/libraries/kernel/process.h"
#include "core/libraries/kernel/time.h"
#include "core/libraries/libs.h"
#include "core/memory.h"
#include "core/tls.h"
#include "font_error.h"

#ifdef formatParams
#undef formatParams
#endif

namespace {
using Libraries::Font::OrbisFontCreateStringDetail;
using Libraries::Font::OrbisFontGenerateGlyphParams;
using Libraries::Font::OrbisFontGlyph;
using Libraries::Font::OrbisFontGlyphMetrics;
using Libraries::Font::OrbisFontGlyphOpaque;
using Libraries::Font::OrbisFontGlyphOutline;
using Libraries::Font::OrbisFontGlyphOutlinePoint;
using Libraries::Font::OrbisFontHandle;
using Libraries::Font::OrbisFontMem;
using Libraries::Font::OrbisFontRenderCharacter;
using Libraries::Font::OrbisFontString;
using Libraries::Font::OrbisFontStyleFrame;
using Libraries::Font::OrbisFontTextCharacter;
using Libraries::Font::OrbisFontTextParseFunction;
using Libraries::Font::OrbisFontTextSource;
using Libraries::Font::OrbisFontWriting;
using Libraries::Font::OrbisFontWritingLetterStep;
using Libraries::Font::OrbisFontWritingMetrics;
using Libraries::Font::OrbisFontWritingStep;
using Libraries::Font::Internal::Param;

constexpr u16 kTextSourceMagic = 0x0F04;
constexpr u32 kWritingFormHorizontal = 0x10;
constexpr u32 kWritingFormHorizontalRtl = 0x11;
constexpr u32 kWritingFormHorizontalLtr = 0x12;
constexpr u16 kFontStringMagic = 0x0F05;
constexpr u16 kFontWritingMagic = 0x0F06;
constexpr u16 kCreateStringDetailMagic = 0x0FD4;
constexpr s32 kTextParserResultError = -1;
constexpr s32 kTextParserResultTerminate = 0;
constexpr s32 kTextParserResultFontCode = 1;
constexpr size_t kMaxParsedStringCharacters = 4096;
constexpr s32 kWritingMaskNone = 0;
constexpr s32 kWritingMaskFormatCharacters = 1;
constexpr u64 kCharacterFlagFormat = 1ull << 42;

struct HleFontString {
    u16 magic = kFontStringMagic;
    u8 flags = 0;
    u8 reserved0 = 0;
    u32 writing_form = kWritingFormHorizontal;

    const OrbisFontMem* memory = nullptr;
    OrbisFontTextSource* source = nullptr;
    OrbisFontHandle default_font = nullptr;

    u32 terminate_code = 0;
    void* terminate_order = nullptr;

    u32 text_count = 0;
    u32 render_count = 0;

    struct HleFontCharacterStorage* character_storage = nullptr;
};

struct HleFontCharacterStorage {
    std::atomic<u32> ref_count{1};
    std::vector<OrbisFontTextCharacter> characters{};
};

struct HleFontWriting {
    u16 magic = kFontWritingMagic;
    u16 reserved0 = 0;
    u32 writing_form = kWritingFormHorizontal;

    OrbisFontString string = nullptr;
    HleFontCharacterStorage* character_storage = nullptr;
    OrbisFontHandle default_font = nullptr;
    size_t next_index = 0;
    size_t current_index = 0;
    float pen_x = 0.0f;
    float pen_y = 0.0f;
    bool has_aggregate_metrics = false;
    bool has_current_step = false;
    bool mask_format_characters = true;
    bool owns_character_storage = false;
    const char* debug_trace_label = nullptr;

    OrbisFontWritingStep step{};
    OrbisFontWritingMetrics metrics{};
    OrbisFontGlyphMetrics raw_glyph_metrics{};
    bool has_raw_glyph_metrics = false;
};

struct PromptRenderTraceState {
    bool active = false;
    const char* label = nullptr;
    size_t index = 0;
    u32 glyph_code = 0;
    float step_x = 0.0f;
    float step_y = 0.0f;
};

thread_local PromptRenderTraceState g_prompt_render_trace{};

static void FillWritingMetricsFromGlyph(HleFontWriting& writing,
                                        const OrbisFontGlyphMetrics& glyph_metrics) {
    writing.raw_glyph_metrics = glyph_metrics;
    writing.has_raw_glyph_metrics = true;
    writing.step.advanceX = glyph_metrics.Horizontal.advance;
    writing.step.advanceY = glyph_metrics.Vertical.advance;
    writing.step.GlyphMetrics = glyph_metrics;
    // LLE keeps the writing-step anchor at the current pen position for the ordinary horizontal
    // path and applies bearings only when expanding the aggregate extents.
    writing.step.Positioning.x = writing.step.x;
    writing.step.Positioning.y = writing.step.y;
    writing.step.GlyphMetrics.width = writing.step.x;
    writing.step.GlyphMetrics.height = writing.step.y;
}

static void ZeroWritingMetrics(OrbisFontWritingMetrics* metrics) {
    if (metrics) {
        std::memset(metrics, 0, sizeof(*metrics));
    }
}

static bool MatchesAsciiPrompt(const HleFontString& font_string, std::string_view expected) {
    if (!font_string.character_storage ||
        font_string.character_storage->characters.size() != expected.size()) {
        return false;
    }

    for (size_t i = 0; i < expected.size(); ++i) {
        if (font_string.character_storage->characters[i].characterCode !=
            static_cast<u32>(expected[i])) {
            return false;
        }
    }

    return true;
}

static bool ContainsAsciiText(const HleFontString& font_string, std::string_view needle) {
    if (!font_string.character_storage || needle.empty() ||
        font_string.character_storage->characters.size() < needle.size()) {
        return false;
    }

    const auto& characters = font_string.character_storage->characters;
    for (size_t start = 0; start + needle.size() <= characters.size(); ++start) {
        bool match = true;
        for (size_t i = 0; i < needle.size(); ++i) {
            if (characters[start + i].characterCode != static_cast<u32>(needle[i])) {
                match = false;
                break;
            }
        }
        if (match) {
            return true;
        }
    }

    return false;
}

static std::string ExtractAsciiText(const HleFontString& font_string) {
    std::string text;
    const auto* storage = font_string.character_storage;
    if (!storage) {
        return text;
    }

    text.reserve(storage->characters.size());
    for (const auto& ch : storage->characters) {
        const u32 code = ch.characterCode;
        if (code == '\n' || code == '\r' || code == '\t') {
            text.push_back(static_cast<char>(code));
            continue;
        }
        if (code < 0x20 || code > 0x7e) {
            return {};
        }
        text.push_back(static_cast<char>(code));
    }
    return text;
}

static void ResetWritingAggregateMetrics(HleFontWriting& writing) {
    writing.has_aggregate_metrics = false;
    ZeroWritingMetrics(&writing.metrics);
}

static void AccumulateWritingMetrics(HleFontWriting& writing) {
    const OrbisFontWritingMetrics previous_metrics = writing.metrics;
    const bool had_aggregate_metrics = writing.has_aggregate_metrics;
    const auto& glyph_metrics =
        writing.has_raw_glyph_metrics ? writing.raw_glyph_metrics : writing.step.GlyphMetrics;
    const float left = writing.step.x + glyph_metrics.Horizontal.bearingX;
    const float right = left + glyph_metrics.width;
    const float top = writing.step.y - glyph_metrics.Horizontal.bearingY;
    const float bottom = top + glyph_metrics.height;

    writing.metrics.advanceX = writing.step.x + writing.step.advanceX;
    writing.metrics.advanceY = writing.step.y + writing.step.advanceY;

    if (!had_aggregate_metrics) {
        writing.metrics.Extent.left = left;
        writing.metrics.Extent.right = right;
        writing.metrics.Extent.top = top;
        writing.metrics.Extent.bottom = bottom;
        writing.has_aggregate_metrics = true;
        return;
    }

    writing.metrics.Extent.left = std::min(previous_metrics.Extent.left, left);
    writing.metrics.Extent.right = std::max(previous_metrics.Extent.right, right);
    writing.metrics.Extent.top = std::min(previous_metrics.Extent.top, top);
    writing.metrics.Extent.bottom = std::max(previous_metrics.Extent.bottom, bottom);
}

static HleFontString* GetHleFontString(OrbisFontString font_string) {
    auto* s = reinterpret_cast<HleFontString*>(font_string);
    if (!s || s->magic != kFontStringMagic) {
        return nullptr;
    }
    return s;
}

static HleFontWriting* GetHleFontWriting(OrbisFontWriting* font_writing) {
    if (!font_writing) {
        return nullptr;
    }

    auto* w = reinterpret_cast<HleFontWriting*>(font_writing->systemUse);
    if (w->magic != kFontWritingMagic) {
        return nullptr;
    }

    return w;
}

static void AddRefCharacterStorage(HleFontCharacterStorage* storage) {
    if (storage) {
        storage->ref_count.fetch_add(1, std::memory_order_relaxed);
    }
}

static void ReleaseCharacterStorage(HleFontCharacterStorage*& storage) {
    if (!storage) {
        return;
    }

    if (storage->ref_count.fetch_sub(1, std::memory_order_acq_rel) == 1) {
        delete storage;
    }
    storage = nullptr;
}

static void ReleaseWritingCharacterStorage(HleFontWriting& writing) {
    if (!writing.owns_character_storage) {
        return;
    }

    ReleaseCharacterStorage(writing.character_storage);
    writing.owns_character_storage = false;
}

static u16 TextSourceMagic(const Libraries::Font::OrbisFontTextSource* text_source) {
    return static_cast<u16>(text_source->systemUse0 & 0xffffu);
}

static void SetTextSourceWritingForm(Libraries::Font::OrbisFontTextSource* text_source,
                                     u32 writing_form) {
    text_source->systemUse0 =
        (text_source->systemUse0 & 0x00000000ffffffffULL) | (static_cast<u64>(writing_form) << 32);
}

static bool IsWhitespaceCode(u32 code) {
    switch (code) {
    case 0x0009:
    case 0x000A:
    case 0x000B:
    case 0x000C:
    case 0x000D:
    case 0x0020:
    case 0x0085:
    case 0x00A0:
    case 0x1680:
    case 0x2028:
    case 0x2029:
    case 0x202F:
    case 0x205F:
    case 0x3000:
        return true;
    default:
        return code >= 0x2000 && code <= 0x200A;
    }
}

static bool IsFormatCode(u32 code) {
    switch (code) {
    case 0x00AD:
    case 0x061C:
    case 0x200B:
    case 0x200C:
    case 0x200D:
    case 0x200E:
    case 0x200F:
    case 0x2060:
    case 0x2061:
    case 0x2062:
    case 0x2063:
    case 0x2064:
    case 0x2066:
    case 0x2067:
    case 0x2068:
    case 0x2069:
    case 0xFE0E:
    case 0xFE0F:
    case 0xFEFF:
        return true;
    default:
        return false;
    }
}

static u64 PackCharacterFlags(u8 char_type, u8 bidi_level, bool is_format) {
    u64 flags = static_cast<u64>(char_type) << 8;
    flags |= static_cast<u64>(bidi_level) << 24;
    if (is_format) {
        flags |= kCharacterFlagFormat;
    }
    return flags;
}

static void InitializeCharacterNode(OrbisFontTextCharacter& character, OrbisFontHandle font,
                                    u32 code, void* text_order) {
    character.prev = nullptr;
    character.next = nullptr;
    character.textOrder = text_order;
    character.font = font;
    character.shapeEntry = nullptr;
    character.characterCode = code;
    std::memset(character.reserved_0x2c, 0, sizeof(character.reserved_0x2c));
    character.clusterSpan = 1;
    character.clusterIndex = 0;
    character.clusterKind = 0;
    character.synthetic = 0;
    std::memset(character.reserved_0x34, 0, sizeof(character.reserved_0x34));
    character.flags = PackCharacterFlags(IsWhitespaceCode(code) ? 0x0E : 0, 0, IsFormatCode(code));
    std::memset(character.reserved_0x40, 0, sizeof(character.reserved_0x40));
}

static void LinkCharacterNodes(std::vector<OrbisFontTextCharacter>& characters) {
    for (size_t i = 0; i < characters.size(); ++i) {
        characters[i].prev = (i == 0) ? nullptr : &characters[i - 1];
        characters[i].next = (i + 1 < characters.size()) ? &characters[i + 1] : nullptr;
    }
}

static OrbisFontTextCharacter* GetTextCharacters(HleFontString* font_string) {
    return (font_string && font_string->character_storage &&
            !font_string->character_storage->characters.empty())
               ? font_string->character_storage->characters.data()
               : nullptr;
}

static ptrdiff_t FindCharacterIndex(const HleFontString* font_string,
                                    const OrbisFontTextCharacter* character) {
    if (!font_string || !font_string->character_storage || !character ||
        font_string->character_storage->characters.empty()) {
        return -1;
    }

    const auto* base = font_string->character_storage->characters.data();
    const auto* end = base + font_string->character_storage->characters.size();
    if (character < base || character >= end) {
        return -1;
    }

    return character - base;
}

static OrbisFontHandle GetCharacterFont(const HleFontString* font_string,
                                        const OrbisFontTextCharacter* character) {
    if (character && character->font) {
        return character->font;
    }

    return font_string ? font_string->default_font : nullptr;
}

static bool PopulateWritingStep(HleFontWriting& writing, HleFontString& font_string, size_t index) {
    auto* storage = font_string.character_storage;
    if (!storage || index >= storage->characters.size()) {
        return false;
    }

    const auto& character = storage->characters[index];
    const auto character_font = GetCharacterFont(&font_string, &character);

    writing.step.x = writing.pen_x;
    writing.step.y = writing.pen_y;
    writing.step.advanceX = 0.0f;
    writing.step.advanceY = 0.0f;
    writing.step.font = character_font;
    writing.step.Profile = {};
    writing.step.Profile.characterCount = 1;
    writing.step.glyphCode = character.characterCode;
    writing.step.Positioning.x = 0.0f;
    writing.step.Positioning.y = 0.0f;
    std::memset(&writing.step.GlyphMetrics, 0, sizeof(writing.step.GlyphMetrics));
    std::memset(&writing.raw_glyph_metrics, 0, sizeof(writing.raw_glyph_metrics));
    writing.has_raw_glyph_metrics = false;

    if ((character.flags & kCharacterFlagFormat) != 0 && writing.mask_format_characters) {
        writing.step.Profile.invisibleGlyph = 1;
    }

    if (character_font && character.characterCode != 0) {
        OrbisFontGlyphMetrics glyph_metrics{};
        s32 metrics_rc = sceFontGetRenderCharGlyphMetrics(character_font, character.characterCode,
                                                          &glyph_metrics);
        if (metrics_rc != ORBIS_OK) {
            metrics_rc =
                sceFontGetCharGlyphMetrics(character_font, character.characterCode, &glyph_metrics);
        }

        if (metrics_rc == ORBIS_OK) {
            FillWritingMetricsFromGlyph(writing, glyph_metrics);
        } else {
            LOG_WARNING(Lib_Font, "sceFontWriting step metrics failed for code={} rc={} (index={})",
                        character.characterCode, metrics_rc, index);
        }
    }

    writing.pen_x += writing.step.advanceX;
    writing.pen_y += writing.step.advanceY;
    return true;
}

static bool PopulateWritingStep(HleFontWriting& writing, size_t index,
                                OrbisFontHandle default_font) {
    if (!writing.character_storage || index >= writing.character_storage->characters.size()) {
        return false;
    }

    HleFontString transient{};
    transient.default_font = default_font;
    transient.character_storage = writing.character_storage;
    return PopulateWritingStep(writing, transient, index);
}

static std::string formatParams(
    std::initializer_list<Libraries::Font::Internal::NamedParam> params) {
    return Libraries::Font::Internal::FormatNamedParams(params);
}

static std::string LowerAscii(std::string s) {
    for (auto& c : s) {
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }
    return s;
}

static std::filesystem::path ResolveServedPath(const std::filesystem::path& p) {
    if (p.empty()) {
        return {};
    }
    std::error_code ec;
    if (std::filesystem::is_regular_file(p, ec) && !ec) {
        return p;
    }
    const auto parent = p.parent_path();
    const auto parent_name = parent.filename().string();
    const auto file_name = p.filename();
    if (!file_name.empty() && (parent_name == "font" || parent_name == "font2")) {
        const auto container = parent.parent_path();
        const auto sibling = container / ((parent_name == "font") ? "font2" : "font") / file_name;
        if (std::filesystem::is_regular_file(sibling, ec) && !ec) {
            return sibling;
        }
    } else {
        const auto in_font2_dir = parent / "font2" / file_name;
        if (std::filesystem::is_regular_file(in_font2_dir, ec) && !ec) {
            return in_font2_dir;
        }
        const auto in_font_dir = parent / "font" / file_name;
        if (std::filesystem::is_regular_file(in_font_dir, ec) && !ec) {
            return in_font_dir;
        }
    }
    return p;
}

static s32 StableUniqueIdFor(std::string_view s) {
    std::uint32_t h = 2166136261u;
    for (unsigned char c : s) {
        const unsigned char lower = static_cast<unsigned char>(std::tolower(c));
        h ^= static_cast<std::uint32_t>(lower);
        h *= 16777619u;
    }
    h &= 0x7fffffffu;
    if (h == 0u) {
        h = 1u;
    }
    return static_cast<s32>(h);
}

static u32 OpenDriverModeFor(u32 mode) {
    if (mode == 1) {
        return 5;
    }
    if (mode == 2) {
        return 6;
    }
    return 7;
}

} // namespace

namespace Internal = Libraries::Font::Internal;

namespace Libraries::Font {

using Internal::AcquireCachedStyleLock;
using Internal::AcquireFontLock;
using Internal::AcquireLibraryLock;
using Internal::CachedStyleCacheFlags;
using Internal::CachedStyleGetScalar;
using Internal::CachedStyleSetCacheFlags;
using Internal::CachedStyleSetDirectionWord;
using Internal::CachedStyleSetScalar;
using Internal::ClampToU16;
using Internal::ClearRenderOutputs;
using Internal::GetLibState;
using Internal::GetNativeFont;
using Internal::kPointsPerInch;
using Internal::kStyleFrameMagic;
using Internal::LoadGuestFileBytes;
using Internal::LoadGuestPathBytes;
using Internal::LogCachedStyleOnce;
using Internal::LogFontOpenError;
using Internal::LogRenderResultSample;
using Internal::ReleaseCachedStyleLock;
using Internal::ReleaseFontLock;
using Internal::ReleaseLibraryLock;
using Internal::RemoveLibState;
using Internal::ResolveGuestPath;
using Internal::ResolveKnownSysFontAlias;

constexpr std::uintptr_t kFtRendererCreateFnAddr = 0x0100f6d0u;
constexpr std::uintptr_t kFtRendererDestroyFnAddr = 0x0100f790u;

s32 PS4_SYSV_ABI sceFontAttachDeviceCacheBuffer(OrbisFontLib library, void* buffer, u32 size) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("library", library),
                  Param("buffer", buffer),
                  Param("size", size),
              }));

    if (!library) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    auto* lib = static_cast<Internal::FontLibOpaque*>(library);
    if (lib->magic != 0x0F01) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    u32 prev_lock_word = 0;
    if (!AcquireLibraryLock(lib, prev_lock_word)) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    const auto kBusy = reinterpret_cast<u32*>(
        static_cast<std::uintptr_t>(std::numeric_limits<std::uintptr_t>::max()));

    u32* current_cache = nullptr;
    for (;;) {
        current_cache = lib->device_cache_buf;
        if (current_cache != kBusy) {
            std::atomic_ref<u32*> ref(lib->device_cache_buf);
            u32* expected = current_cache;
            if (ref.compare_exchange_weak(expected, kBusy, std::memory_order_acq_rel)) {
                current_cache = expected;
                break;
            }
        }
        Libraries::Kernel::sceKernelUsleep(0x1e);
    }

    const auto alloc_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontAllocFn>(lib->alloc_vtbl[0]) : nullptr;
    const auto free_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontFreeFn>(lib->alloc_vtbl[1]) : nullptr;
    (void)alloc_fn;
    (void)free_fn;

    s32 rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
    u32* cache_to_store = current_cache;
    u32 owned = 0;

    if (current_cache != nullptr) {
        rc = ORBIS_FONT_ERROR_ALREADY_ATTACHED;
    } else if (size < 0x1020) {
        cache_to_store = nullptr;
        rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
    } else {
        u32* header = static_cast<u32*>(buffer);
        if (!header) {
            header = static_cast<u32*>(alloc_fn(lib->alloc_ctx, size));
            if (!header) {
                cache_to_store = nullptr;
                rc = ORBIS_FONT_ERROR_ALLOCATION_FAILED;
            } else {
                owned = 1;
            }
        }

        if (rc == ORBIS_FONT_ERROR_INVALID_PARAMETER) {
            header[0] = size;
            const u32 page_count = ((size - 0x1000) >> 12);
            header[1] = page_count;
            header[3] = page_count;
            header[2] = 0;
            *reinterpret_cast<std::uint64_t*>(header + 4) = 0x0FF800001000ULL;

            if (0x0FFF < (size - 0x1000)) {
                lib->flags |= owned;
                rc = ORBIS_OK;
                cache_to_store = header;
                if (owned) {
                    auto& state = GetLibState(library);
                    state.alloc_ctx = lib->alloc_ctx;
                    state.alloc_fn = alloc_fn;
                    state.free_fn = free_fn;
                    state.owned_device_cache = header;
                    state.owned_device_cache_size = size;
                }
            } else {
                if (!buffer) {
                    free_fn(lib->alloc_ctx, header);
                }
                cache_to_store = nullptr;
                rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
            }
        }
    }

    lib->device_cache_buf = cache_to_store;
    ReleaseLibraryLock(lib, prev_lock_word);
    if (rc != ORBIS_OK) {
        LOG_ERROR(Lib_Font, "FAILED");
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontBindRenderer(OrbisFontHandle fontHandle, OrbisFontRenderer renderer) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("renderer", renderer),
              }));

    auto* font = GetNativeFont(fontHandle);
    if (!font) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_font_lock = 0;
    if (!AcquireFontLock(font, prev_font_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_cached_lock = 0;
    if (!AcquireCachedStyleLock(font, prev_cached_lock)) {
        ReleaseFontLock(font, prev_font_lock);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    s32 rc = ORBIS_FONT_ERROR_ALREADY_BOUND_RENDERER;
    if (font->renderer_binding.renderer == nullptr) {
        rc = ORBIS_FONT_ERROR_INVALID_RENDERER;
        if (renderer && *reinterpret_cast<const u16*>(renderer) == 0x0F07) {
            rc = ORBIS_OK;

            std::memcpy(&font->cached_style.effectWeightY, &font->style_tail.slant_ratio,
                        sizeof(u64));

            std::memcpy(&font->cached_style, &font->style_frame[0], sizeof(u32));

            const u32 dpi_y = font->style_frame[1];
            const u32 scale_unit = font->style_tail.scale_unit;
            const u32 reserved_0x0c = font->style_tail.reserved_0x0c;
            const float scale_w = font->style_tail.scale_w;
            const float scale_h = font->style_tail.scale_h;
            const float effect_weight_x = font->style_tail.effect_weight_x;
            const float effect_weight_y = font->style_tail.effect_weight_y;

            font->cached_style.hDpi = dpi_y;
            font->cached_style.vDpi = scale_unit;
            font->cached_style.scaleUnit = reserved_0x0c;
            font->cached_style.baseScale = scale_w;
            font->cached_style.scalePixelW = scale_h;
            font->cached_style.scalePixelH = effect_weight_x;
            font->cached_style.effectWeightX = effect_weight_y;

            font->renderer_binding.renderer = renderer;
        }
    }

    ReleaseCachedStyleLock(font, prev_cached_lock);
    ReleaseFontLock(font, prev_font_lock);
    if (rc != ORBIS_OK) {
        if (rc == ORBIS_FONT_ERROR_ALREADY_BOUND_RENDERER) {
            LOG_ERROR(Lib_Font, "ALREADY_BOUND");
        } else if (rc == ORBIS_FONT_ERROR_INVALID_RENDERER) {
            LOG_ERROR(Lib_Font, "INVALID_RENDERER");
        } else {
            LOG_ERROR(Lib_Font, "FAILED");
        }
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontCharacterGetBidiLevel(OrbisFontTextCharacter* textCharacter,
                                              int* bidiLevel) {
    if (!textCharacter || !bidiLevel) {
        LOG_ERROR(Lib_Font, "invalid parameter");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    *bidiLevel = static_cast<int>((textCharacter->flags >> 24) & 0xFFu);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCharacterGetSyllableStringState() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCharacterGetTextFontCode(OrbisFontTextCharacter* textCharacter,
                                                 OrbisFontHandle* pFontHandle, u32* textCode) {
    if (!textCharacter) {
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        if (textCode) {
            *textCode = 0;
        }
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (!pFontHandle || !textCode) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    *pFontHandle = textCharacter->font;
    *textCode = textCharacter->characterCode;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCharacterGetTextOrder(OrbisFontTextCharacter* textCharacter,
                                              void** pTextOrder) {
    if (!pTextOrder) {
        LOG_ERROR(Lib_Font, "invalid parameter (pTextOrder)");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    if (!textCharacter) {
        LOG_ERROR(Lib_Font, "invalid parameter (textCharacter)");
        *pTextOrder = NULL;
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    *pTextOrder = textCharacter->textOrder;
    return ORBIS_OK;
}

u32 PS4_SYSV_ABI sceFontCharacterLooksFormatCharacters(OrbisFontTextCharacter* textCharacter) {
    if (!textCharacter) {
        return 0;
    }

    return (textCharacter->flags & kCharacterFlagFormat) != 0 ? textCharacter->characterCode : 0;
}

u32 PS4_SYSV_ABI sceFontCharacterLooksWhiteSpace(OrbisFontTextCharacter* textCharacter) {
    if (!textCharacter) {
        return 0;
    }

    return ((textCharacter->flags >> 8) & 0xFFu) == 0x0E ? textCharacter->characterCode : 0;
}

OrbisFontTextCharacter* PS4_SYSV_ABI
sceFontCharacterRefersTextBack(OrbisFontTextCharacter* textCharacter) {
    if (!textCharacter)
        return NULL;

    OrbisFontTextCharacter* current = textCharacter->prev;
    while (current) {
        if (current->synthetic == 0 && current->clusterIndex == 0) {
            return current;
        }
        current = current->prev;
    }

    return NULL;
}

OrbisFontTextCharacter* PS4_SYSV_ABI
sceFontCharacterRefersTextNext(OrbisFontTextCharacter* textCharacter) {
    if (!textCharacter)
        return NULL;

    OrbisFontTextCharacter* current = textCharacter->next;
    while (current) {
        if (current->synthetic == 0 && current->clusterIndex == 0) {
            return current;
        }
        current = current->next;
    }

    return NULL;
}

s32 PS4_SYSV_ABI sceFontCharactersRefersTextCodes() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontClearDeviceCache(OrbisFontLib library) {
    if (!library) {
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    auto* lib = static_cast<Internal::FontLibOpaque*>(library);
    if (lib->magic != 0x0F01) {
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    u32 prev_lock_word = 0;
    if (!AcquireLibraryLock(lib, prev_lock_word)) {
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    const auto kBusy = reinterpret_cast<u32*>(
        static_cast<std::uintptr_t>(std::numeric_limits<std::uintptr_t>::max()));

    u32* current_cache = nullptr;
    for (;;) {
        current_cache = lib->device_cache_buf;
        if (current_cache != kBusy) {
            std::atomic_ref<u32*> ref(lib->device_cache_buf);
            u32* expected = current_cache;
            if (ref.compare_exchange_weak(expected, kBusy, std::memory_order_acq_rel)) {
                current_cache = expected;
                break;
            }
        }
        Libraries::Kernel::sceKernelUsleep(0x1e);
    }

    s32 rc = ORBIS_FONT_ERROR_NOT_ATTACHED_CACHE_BUFFER;
    if (current_cache != nullptr) {
        current_cache[3] = current_cache[1];
        current_cache[2] = 0;
        rc = ORBIS_OK;
    }

    lib->device_cache_buf = current_cache;
    ReleaseLibraryLock(lib, prev_lock_word);
    return rc;
}

s32 PS4_SYSV_ABI sceFontCloseFont() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontControl() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCreateGraphicsDevice() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCreateGraphicsService() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCreateGraphicsServiceWithEdition() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCreateLibrary(const OrbisFontMem* memory,
                                      OrbisFontLibCreateParams create_params,
                                      OrbisFontLib* pLibrary) {
    return sceFontCreateLibraryWithEdition(memory, create_params, 0, pLibrary);
}

s32 PS4_SYSV_ABI sceFontCreateLibraryWithEdition(const OrbisFontMem* memory,
                                                 OrbisFontLibCreateParams create_params,
                                                 u64 edition, OrbisFontLib* pLibrary) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("memory", memory),
                  Param("create_params", create_params),
                  Param("edition", edition),
                  Param("pLibrary", pLibrary),
              }));

    if (pLibrary) {
        *pLibrary = nullptr;
    }
    if (!memory) {
        LOG_ERROR(Lib_Font, "NULL_POINTER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (memory->mem_kind != 0x0F00 || !memory->iface || !memory->iface->alloc ||
        !memory->iface->dealloc) {
        LOG_ERROR(Lib_Font, "INVALID_MEMORY");
        return ORBIS_FONT_ERROR_INVALID_MEMORY;
    }
    if (!create_params || !pLibrary) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    const auto malloc_fn = reinterpret_cast<Internal::FontAllocFn>(memory->iface->alloc);
    const auto free_fn = reinterpret_cast<Internal::FontFreeFn>(memory->iface->dealloc);
    if (!malloc_fn || !free_fn) {
        LOG_ERROR(Lib_Font, "INVALID_MEMORY");
        return ORBIS_FONT_ERROR_INVALID_MEMORY;
    }

    void* lib_mem = malloc_fn(memory->mspace_handle, 0x100);
    if (!lib_mem) {
        LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
        return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
    }

    void* mspace = malloc_fn(memory->mspace_handle, 0x4000);
    if (!mspace) {
        free_fn(memory->mspace_handle, lib_mem);
        LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
        return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
    }

    auto* lib_bytes = static_cast<u8*>(lib_mem);
    auto clear_20 = [&](std::size_t offset) { std::memset(lib_bytes + offset, 0, 0x20); };
    clear_20(0x00);
    clear_20(sizeof(Internal::FontLibOpaque) + offsetof(Internal::FontLibOpaque, alloc_vtbl));
    clear_20(sizeof(Internal::FontLibOpaque) + offsetof(Internal::FontLibOpaque, flags));
    clear_20(offsetof(Internal::FontLibOpaque, sysfonts_ctx));
    clear_20(offsetof(Internal::FontLibOpaque, sys_driver));
    clear_20(offsetof(Internal::FontLibOpaque, reserved2) + 0x30);
    clear_20(offsetof(Internal::FontLibOpaque, reserved2) + 0x10);
    clear_20(offsetof(Internal::FontLibOpaque, alloc_ctx));
    clear_20(offsetof(Internal::FontLibOpaque, reserved3) + 0x0C);
    clear_20(offsetof(Internal::FontLibOpaque, fontset_registry));

    auto* lib = static_cast<Internal::FontLibOpaque*>(lib_mem);

    auto* reserved1 = reinterpret_cast<Internal::FontLibReserved1Main*>(lib->reserved1);
    if (reserved1) {
        reserved1->mem_kind = 0x0F00;
        reserved1->region_size = memory->region_size;
        reserved1->region_base = memory->region_base;
    }

    lib->alloc_ctx = memory->mspace_handle;
    lib->alloc_vtbl = reinterpret_cast<void**>(const_cast<OrbisFontMemInterface*>(memory->iface));

    auto* reserved2 = reinterpret_cast<Internal::FontLibReserved2Iface*>(lib->reserved2);
    if (reserved2) {
        reserved2->alloc_fn = reinterpret_cast<std::uintptr_t>(memory->iface->alloc);
        reserved2->dealloc_fn = reinterpret_cast<std::uintptr_t>(memory->iface->dealloc);
        reserved2->realloc_fn = reinterpret_cast<std::uintptr_t>(memory->iface->realloc_fn);
        reserved2->calloc_fn = reinterpret_cast<std::uintptr_t>(memory->iface->calloc_fn);
    }

    lib->sys_driver = const_cast<void*>(create_params);

    auto* tail = reinterpret_cast<Internal::FontLibTail*>(lib + 1);
    if (tail) {
        tail->workspace_size = 0x4000;
        tail->workspace = mspace;
        tail->list_head_ptr = &tail->list_head;
        tail->list_head = nullptr;
    }

    const auto* sys_driver = reinterpret_cast<const Internal::SysDriver*>(create_params);
    const auto init_fn = sys_driver ? sys_driver->init : nullptr;
    if (!init_fn) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    const s32 init_rc = init_fn(memory, lib);
    if (init_rc != ORBIS_OK) {
        free_fn(memory->mspace_handle, mspace);
        free_fn(memory->mspace_handle, lib_mem);
        LOG_ERROR(Lib_Font, "INIT_FAILED");
        return init_rc;
    }

    s32 sdk_version = 0;
    u32 sdk_version_u32 = 0;
    if (Libraries::Kernel::sceKernelGetCompiledSdkVersion(&sdk_version) == ORBIS_OK) {
        sdk_version_u32 = static_cast<u32>(sdk_version);
    }
    const u32 edition_hi = static_cast<u32>(edition >> 32);
    u32 v = edition_hi;
    if (sdk_version_u32 != 0) {
        v = sdk_version_u32;
        if (edition_hi <= sdk_version_u32) {
            v = edition_hi;
        }
    }
    if (0x92ffffu < v) {
        auto* pad_00A_01E = lib->reserved1;
        auto* feature_word = reinterpret_cast<u32*>(pad_00A_01E);
        if (v < 0x1500000u) {
            u32 tmp = (*feature_word) | 1u;
            *feature_word = tmp;
            tmp |= 2u;
            *feature_word = tmp;
            *feature_word = tmp | 4u;
        } else if (v < 0x2000000u) {
            u32 tmp = *feature_word;
            tmp |= 2u;
            *feature_word = tmp;
            *feature_word = tmp | 4u;
        } else if (v <= 0x2000070u) {
            u32 tmp = *feature_word;
            *feature_word = tmp | 4u;
        }
    }

    lib->magic = 0x0F01;

    *pLibrary = lib;
    auto& state = GetLibState(lib);
    state = Internal::LibraryState{};
    state.backing_memory = memory;
    state.create_params = create_params;
    state.edition = edition;
    state.alloc_ctx = lib->alloc_ctx;
    state.alloc_fn = reinterpret_cast<Internal::FontAllocFn>(lib->alloc_vtbl[0]);
    state.free_fn = reinterpret_cast<Internal::FontFreeFn>(lib->alloc_vtbl[1]);
    state.owned_mspace = mspace;
    state.owned_mspace_size = 0x4000;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDestroyLibrary(OrbisFontLib* pLibrary) {
    if (!pLibrary) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    auto lib = *pLibrary;
    if (!lib) {
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    LOG_INFO(Lib_Font, "library destroy requested");
    LOG_DEBUG(Lib_Font,
              "library destroy params:\n"
              " library_handle_ptr={}\n"
              " library_handle={}\n",
              static_cast<const void*>(pLibrary), static_cast<const void*>(lib));
    auto* native = static_cast<Internal::FontLibOpaque*>(lib);
    if (native->magic != 0x0F01) {
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    RemoveLibState(lib);

    const auto free_fn = native->alloc_vtbl
                             ? reinterpret_cast<Internal::FontFreeFn>(native->alloc_vtbl[1])
                             : nullptr;
    if (free_fn) {
        free_fn(native->alloc_ctx, native);
    } else {
        std::free(native);
    }
    *pLibrary = nullptr;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCreateRenderer(const OrbisFontMem* memory,
                                       OrbisFontRendererCreateParams create_params,
                                       OrbisFontRenderer* pRenderer) {
    return sceFontCreateRendererWithEdition(memory, create_params, 0, pRenderer);
}

s32 PS4_SYSV_ABI sceFontCreateRendererWithEdition(const OrbisFontMem* memory,
                                                  OrbisFontRendererCreateParams create_params,
                                                  u64 edition, OrbisFontRenderer* pRenderer) {
    LOG_INFO(Lib_Font, "called");

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("memory", memory),
                  Param("create_params", create_params),
                  Param("edition", edition),
                  Param("pRenderer", pRenderer),
              }));

    s32 rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
    if (!memory) {
        if (!pRenderer) {
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
            return rc;
        }
        *pRenderer = nullptr;
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return rc;
    }

    rc = ORBIS_FONT_ERROR_INVALID_MEMORY;
    if (memory->mem_kind == 0x0F00 && memory->iface && memory->iface->alloc &&
        memory->iface->dealloc) {
        if (!create_params) {
            rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
        } else {
            rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
            if (pRenderer) {
                const auto alloc_fn = reinterpret_cast<Internal::FontAllocFn>(memory->iface->alloc);
                const auto free_fn = reinterpret_cast<Internal::FontFreeFn>(memory->iface->dealloc);

                const auto* selection =
                    static_cast<const Libraries::FontFt::OrbisFontRendererSelection*>(
                        create_params);
                const u32 render_size = selection ? selection->size : 0u;
                void* renderer_mem = alloc_fn(memory->mspace_handle, render_size);
                void* workspace = alloc_fn(memory->mspace_handle, 0x4000);

                rc = ORBIS_FONT_ERROR_ALLOCATION_FAILED;
                if (renderer_mem && workspace) {
                    auto* renderer = static_cast<Internal::RendererOpaque*>(renderer_mem);

                    std::memset(renderer, 0, offsetof(Internal::RendererOpaque, mem_kind));
                    renderer->magic = 0x0F07;
                    renderer->mem_kind = 0x0F00;
                    renderer->region_size = memory->region_size;
                    renderer->region_base = memory->region_base;
                    renderer->alloc_ctx = memory->mspace_handle;

                    renderer->mem_iface = memory->iface;
                    renderer->alloc_fn = reinterpret_cast<std::uintptr_t>(memory->iface->alloc);
                    renderer->free_fn = reinterpret_cast<std::uintptr_t>(memory->iface->dealloc);
                    renderer->realloc_fn =
                        reinterpret_cast<std::uintptr_t>(memory->iface->realloc_fn);
                    renderer->calloc_fn =
                        reinterpret_cast<std::uintptr_t>(memory->iface->calloc_fn);

                    renderer->selection =
                        const_cast<void*>(static_cast<const void*>(create_params));
                    renderer->outline_magic_0x90 = 0x400000000000ull;
                    renderer->workspace = workspace;
                    renderer->workspace_size = 0x4000;
                    renderer->reserved_a8 = 0;
                    renderer->outline_policy_flag = 0;

                    const uintptr_t create_fn_ptr =
                        selection ? selection->create_fn : static_cast<std::uintptr_t>(0);
                    auto create_fn =
                        reinterpret_cast<s32(PS4_SYSV_ABI*)(void* renderer)>(create_fn_ptr);
                    if (create_fn_ptr == kFtRendererCreateFnAddr) {
                        create_fn = &Libraries::FontFt::Internal::FtRendererCreate;
                    }
                    if (!create_fn) {
                        rc = ORBIS_FONT_ERROR_FATAL;
                    } else {
                        rc = create_fn(renderer_mem);
                        if (rc == ORBIS_OK) {
                            s32 sdk_version = 0;
                            u32 sdk_version_u32 = 0;
                            if (Libraries::Kernel::sceKernelGetCompiledSdkVersion(&sdk_version) ==
                                ORBIS_OK) {
                                sdk_version_u32 = static_cast<u32>(sdk_version);
                            }
                            const u32 edition_hi = static_cast<u32>(edition >> 32);
                            u32 v = edition_hi;
                            if (sdk_version_u32 != 0) {
                                v = sdk_version_u32;
                                if (edition_hi <= sdk_version_u32) {
                                    v = edition_hi;
                                }
                            }
                            if ((v - 0x930000u) < 0x1bd0000u) {
                                renderer->feature_byte_0x0c |= 1u;
                                renderer->outline_policy_flag = 1;
                            }

                            *pRenderer = renderer_mem;
                            return ORBIS_OK;
                        }
                    }
                }

                if (workspace) {
                    free_fn(memory->mspace_handle, workspace);
                }
                if (renderer_mem) {
                    free_fn(memory->mspace_handle, renderer_mem);
                }
            }
        }
    }

    if (!pRenderer) {
        LOG_ERROR(Lib_Font, "FAILED");
        return rc;
    }
    *pRenderer = nullptr;
    if (rc == ORBIS_FONT_ERROR_INVALID_PARAMETER) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
    } else if (rc == ORBIS_FONT_ERROR_INVALID_MEMORY) {
        LOG_ERROR(Lib_Font, "INVALID_MEMORY");
    } else if (rc == ORBIS_FONT_ERROR_ALLOCATION_FAILED) {
        LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
    } else if (rc == ORBIS_FONT_ERROR_FATAL) {
        LOG_ERROR(Lib_Font, "FATAL");
    } else {
        LOG_ERROR(Lib_Font, "FAILED");
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontCreateString(const OrbisFontMem* fontMemory,
                                     OrbisFontTextSource* fontTextSource,
                                     const OrbisFontCreateStringDetail* stringDetail,
                                     OrbisFontString* pFontString) {
    LOG_INFO(Lib_Font, "called fontMemory={} fontTextSource={} stringDetail={} pFontString={}",
             static_cast<const void*>(fontMemory), static_cast<const void*>(fontTextSource),
             static_cast<const void*>(stringDetail), static_cast<const void*>(pFontString));

    if (!fontMemory || !fontTextSource || !pFontString) {
        if (pFontString) {
            *pFontString = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER null argument");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    LOG_INFO(Lib_Font,
             "probe textSource: systemUse0=0x{:016x} start={} end={} current={} parser={} "
             "object={} defaultFont={}",
             fontTextSource->systemUse0, fontTextSource->start, fontTextSource->end,
             fontTextSource->current, reinterpret_cast<const void*>(fontTextSource->textParser),
             fontTextSource->textObject, static_cast<void*>(fontTextSource->defaultFont));

    LOG_INFO(Lib_Font,
             "probe memory: mem_kind=0x{:04x} attr_bits=0x{:04x} region_size=0x{:x} base={} "
             "mspace={} iface={}",
             fontMemory->mem_kind, fontMemory->attr_bits, fontMemory->region_size,
             fontMemory->region_base, fontMemory->mspace_handle,
             static_cast<const void*>(fontMemory->iface));

    if (!fontTextSource->textParser) {
        if (pFontString) {
            *pFontString = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    if (TextSourceMagic(fontTextSource) != kTextSourceMagic) {
        *pFontString = nullptr;
        LOG_ERROR(Lib_Font, "INVALID_TEXT_SOURCE");
        return ORBIS_FONT_ERROR_INVALID_TEXT_SOURCE;
    }

    if (fontMemory->mem_kind != 0x0F00 || !fontMemory->iface || !fontMemory->iface->alloc ||
        !fontMemory->iface->dealloc) {
        *pFontString = nullptr;
        LOG_ERROR(Lib_Font, "INVALID_MEMORY");
        return ORBIS_FONT_ERROR_INVALID_MEMORY;
    }

    if (stringDetail) {
        const u32 valid_orders_mask = (1u << 0) | (1u << 1) | (1u << 2) | (1u << 31);
        constexpr u8 kValidDetectionsMask = 0x07;

        if (stringDetail->detailId != kCreateStringDetailMagic || stringDetail->detailType > 1 ||
            (stringDetail->detections & ~kValidDetectionsMask) != 0 ||
            (stringDetail->ordersOption & ~valid_orders_mask) != 0) {
            *pFontString = nullptr;
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
            return ORBIS_FONT_ERROR_INVALID_PARAMETER;
        }
    }

    const auto alloc_fn = reinterpret_cast<Internal::FontAllocFn>(fontMemory->iface->alloc);
    const auto free_fn = reinterpret_cast<Internal::FontFreeFn>(fontMemory->iface->dealloc);
    LOG_INFO(Lib_Font, "sceFontCreateString allocator probe: alloc_fn={} free_fn={} mspace={}",
             reinterpret_cast<const void*>(alloc_fn), reinterpret_cast<const void*>(free_fn),
             fontMemory->mspace_handle);

    auto* raw = alloc_fn(fontMemory->mspace_handle, sizeof(HleFontString));
    LOG_INFO(Lib_Font, "sceFontCreateString allocator returned {}", raw);
    if (!raw) {
        *pFontString = nullptr;
        LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
        return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
    }

    auto* s = new (raw) HleFontString{};
    s->memory = fontMemory;
    s->source = fontTextSource;
    s->default_font = fontTextSource->defaultFont;
    s->character_storage = new HleFontCharacterStorage{};

    if (!s->default_font && stringDetail) {
        s->default_font = stringDetail->defaultFont;
    }

    s->writing_form = static_cast<u32>((fontTextSource->systemUse0 >> 32) & 0xffffffffu);
    s->terminate_order = nullptr;
    s->terminate_code = 0;

    auto parser_state = ORBIS_FONT_ERROR_INVALID_TEXT_SOURCE;
    void* text_order = nullptr;
    OrbisFontTextParseResult parse_result{};

    for (size_t parsed = 0; parsed < kMaxParsedStringCharacters; ++parsed) {
        std::memset(&parse_result, 0, sizeof(parse_result));
        parser_state = fontTextSource->textParser(fontTextSource, &text_order, &parse_result);

        if (parser_state == kTextParserResultFontCode) {
            auto char_font =
                parse_result.FontCode.font ? parse_result.FontCode.font : s->default_font;
            if (!char_font) {
                LOG_ERROR(Lib_Font, "INVALID_TEXT_SOURCE parser returned code={} without a font",
                          parse_result.FontCode.code);
                parser_state = ORBIS_FONT_ERROR_INVALID_TEXT_SOURCE;
                break;
            }

            OrbisFontTextCharacter character{};
            InitializeCharacterNode(character, char_font, parse_result.FontCode.code, text_order);
            s->character_storage->characters.push_back(character);
            continue;
        }

        if (parser_state == kTextParserResultTerminate) {
            s->terminate_order = text_order;
            s->terminate_code = parse_result.Terminate.terminateCode;
            parser_state = ORBIS_OK;
            break;
        }

        if (parser_state == kTextParserResultError) {
            parser_state = (parse_result.Error.errorCode < 0)
                               ? parse_result.Error.errorCode
                               : ORBIS_FONT_ERROR_INVALID_TEXT_SOURCE;
            LOG_ERROR(Lib_Font, "sceFontCreateString parser reported error rc={}", parser_state);
            break;
        }

        LOG_ERROR(Lib_Font, "sceFontCreateString parser returned unexpected state {}",
                  parser_state);
        parser_state = ORBIS_FONT_ERROR_INVALID_TEXT_SOURCE;
        break;
    }

    if (s->character_storage->characters.size() == kMaxParsedStringCharacters &&
        parser_state == kTextParserResultFontCode) {
        parser_state = ORBIS_FONT_ERROR_INVALID_TEXT_SOURCE;
    }

    if (s->character_storage->characters.size() == kMaxParsedStringCharacters &&
        parser_state != ORBIS_OK) {
        LOG_ERROR(Lib_Font, "sceFontCreateString exceeded parser safety limit ({})",
                  kMaxParsedStringCharacters);
    }

    if (parser_state != ORBIS_OK) {
        ReleaseCharacterStorage(s->character_storage);
        s->~HleFontString();
        free_fn(fontMemory->mspace_handle, raw);
        *pFontString = nullptr;
        return parser_state;
    }

    LinkCharacterNodes(s->character_storage->characters);
    s->text_count = static_cast<u32>(s->character_storage->characters.size());
    s->render_count = s->text_count;

    const std::string ascii_text = ExtractAsciiText(*s);
    if (!ascii_text.empty() && ascii_text.size() <= 160) {
        LOG_INFO(Lib_Font, "AsciiString: len={} text=\"{}\"", ascii_text.size(), ascii_text);
    }

    *pFontString = reinterpret_cast<OrbisFontString>(s);
    LOG_INFO(Lib_Font,
             "created HleFontString at {} (memory iface={} default_font={} text_count={} "
             "first_code={} terminate_code={})",
             static_cast<const void*>(*pFontString), static_cast<const void*>(fontMemory->iface),
             static_cast<const void*>(s->default_font), s->text_count,
             s->text_count != 0 ? s->character_storage->characters.front().characterCode : 0,
             s->terminate_code);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCreateWords() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontCreateWritingLine() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDefineAttribute() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDeleteGlyph(const OrbisFontMem* memory, OrbisFontGlyph* glyph) {
    LOG_INFO(Lib_Font, "glyph delete requested");
    LOG_DEBUG(Lib_Font,
              "glyph delete params:\n"
              " memory={}\n"
              " glyph_ptr={}\n",
              static_cast<const void*>(memory),
              glyph ? static_cast<const void*>(*glyph) : static_cast<const void*>(nullptr));

    if (!glyph) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    OrbisFontGlyph handle = *glyph;
    if (!handle) {
        return ORBIS_FONT_ERROR_INVALID_GLYPH;
    }

    if (handle->magic != 0x0F03) {
        return ORBIS_FONT_ERROR_INVALID_GLYPH;
    }

    (void)memory;
    if (!Internal::ForgetGeneratedGlyph(handle)) {
        return ORBIS_FONT_ERROR_INVALID_GLYPH;
    }

    auto* boxed = reinterpret_cast<Libraries::Font::Internal::GeneratedGlyph*>(handle);
    delete boxed;
    *glyph = nullptr;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDestroyGraphicsDevice() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDestroyGraphicsService() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDestroyRenderer(OrbisFontRenderer* pRenderer) {
    if (!pRenderer) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    auto* renderer = static_cast<Internal::RendererOpaque*>(*pRenderer);
    s32 rc = ORBIS_FONT_ERROR_INVALID_RENDERER;
    if (renderer && renderer->magic == 0x0F07) {
        const auto kBusy = static_cast<std::uintptr_t>(std::numeric_limits<std::uintptr_t>::max());

        std::uintptr_t selection_value = 0;
        for (;;) {
            selection_value = reinterpret_cast<std::uintptr_t>(renderer->selection);
            if (selection_value != kBusy) {
                std::atomic_ref<std::uintptr_t> ref(
                    *reinterpret_cast<std::uintptr_t*>(&renderer->selection));
                std::uintptr_t expected = selection_value;
                if (ref.compare_exchange_weak(expected, kBusy, std::memory_order_acq_rel)) {
                    selection_value = expected;
                    break;
                }
            }
            Libraries::Kernel::sceKernelUsleep(0x1e);
        }

        if (selection_value == 0) {
            rc = ORBIS_FONT_ERROR_FATAL;
        } else {
            const auto* selection =
                reinterpret_cast<const Libraries::FontFt::OrbisFontRendererSelection*>(
                    selection_value);
            const auto destroy_fn_ptr =
                selection ? selection->destroy_fn : static_cast<std::uintptr_t>(0);
            auto destroy_fn = reinterpret_cast<s32(PS4_SYSV_ABI*)(void* renderer)>(destroy_fn_ptr);
            if (destroy_fn_ptr == kFtRendererDestroyFnAddr) {
                destroy_fn = &Libraries::FontFt::Internal::FtRendererDestroy;
            }
            rc = destroy_fn ? destroy_fn(renderer) : ORBIS_FONT_ERROR_FATAL;
        }

        renderer->selection = nullptr;

        const auto free_fn = reinterpret_cast<Internal::FontFreeFn>(renderer->free_fn);
        void* alloc_ctx = renderer->alloc_ctx;
        void* workspace = renderer->workspace;
        if (workspace) {
            free_fn(alloc_ctx, workspace);
        }
        free_fn(alloc_ctx, renderer);

        *pRenderer = nullptr;
        return rc;
    }

    return rc;
}

s32 PS4_SYSV_ABI sceFontDestroyString(OrbisFontString* pFontString) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}", formatParams({Param("pFontString", pFontString)}));

    if (!pFontString) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    auto* s = GetHleFontString(*pFontString);
    if (!s) {
        *pFontString = nullptr;
        LOG_ERROR(Lib_Font, "INVALID_STRING");
        return ORBIS_FONT_ERROR_INVALID_STRING;
    }

    const auto free_fn = reinterpret_cast<Internal::FontFreeFn>(s->memory->iface->dealloc);
    void* alloc_ctx = s->memory->mspace_handle;
    void* raw = s;
    ReleaseCharacterStorage(s->character_storage);
    LOG_DEBUG(Lib_Font, "destroying HleFontString {} (memory iface={})",
              static_cast<const void*>(s), static_cast<const void*>(s->memory->iface));
    s->~HleFontString();
    free_fn(alloc_ctx, raw);
    *pFontString = nullptr;

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDestroyWords() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDestroyWritingLine() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontDettachDeviceCacheBuffer() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGenerateCharGlyph(OrbisFontHandle glyph_handle, u32 codepoint,
                                          const OrbisFontGenerateGlyphParams* gen_params,
                                          OrbisFontGlyph* glyph_out) {
    LOG_INFO(Lib_Font, "glyph generation requested");
    LOG_DEBUG(Lib_Font,
              "glyph generation params:\n"
              " handle={}\n"
              " codepoint={}\n"
              " id=0x{:04X}\n"
              " glyph_form={}\n"
              " metrics_form={}\n"
              " form_options=0x{:X}\n"
              " mem={}\n",
              static_cast<const void*>(glyph_handle), codepoint,
              gen_params ? static_cast<u32>(gen_params->id) : 0u,
              gen_params ? static_cast<u32>(gen_params->glyph_form) : 0u,
              gen_params ? static_cast<u32>(gen_params->metrics_form) : 0u,
              gen_params ? static_cast<u32>(gen_params->form_options) : 0u,
              gen_params ? static_cast<const void*>(gen_params->mem)
                         : static_cast<const void*>(nullptr));

    if (!glyph_out) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    *glyph_out = nullptr;

    if (!glyph_handle) {
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }
    if (codepoint == 0) {
        return ORBIS_FONT_ERROR_NO_SUPPORT_CODE;
    }

    auto* st = Internal::TryGetState(glyph_handle);
    if (!st) {
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    const u8 glyph_form = gen_params ? gen_params->glyph_form : 0;
    const u8 metrics_form = gen_params ? gen_params->metrics_form : 0;
    const u16 form_options = gen_params ? gen_params->form_options : 0;
    const OrbisFontMem* glyph_memory = gen_params ? gen_params->mem : nullptr;

    if (gen_params && gen_params->id != 0x0FD3) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if ((form_options & static_cast<u16>(~0x11)) != 0) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (glyph_form == 0 && metrics_form != 0) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if ((glyph_form != 0 && metrics_form == 0) || glyph_form > 1 || metrics_form > 4) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (glyph_memory && glyph_memory->mem_kind != 0xF00) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    OrbisFontGlyphMetrics metrics{};
    const s32 metrics_res = sceFontGetCharGlyphMetrics(glyph_handle, codepoint, &metrics);
    if (metrics_res != ORBIS_OK) {
        return metrics_res;
    }

    auto* boxed = new (std::nothrow) Libraries::Font::Internal::GeneratedGlyph();
    if (!boxed) {
        return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
    }

    boxed->codepoint = codepoint;
    boxed->metrics = metrics;
    boxed->glyph.magic = 0x0F03;
    boxed->glyph.flags = form_options;
    boxed->glyph.glyph_form = glyph_form;
    boxed->glyph.metrics_form = metrics_form;
    boxed->glyph.em_size = ClampToU16(st->scale_h);
    boxed->glyph.baseline = ClampToU16(metrics.Horizontal.bearingY);
    boxed->glyph.height_px = ClampToU16(metrics.height);
    boxed->glyph.origin_x = 0;
    boxed->glyph.origin_y = boxed->glyph.baseline;
    boxed->glyph.scale_x = st->scale_w;
    boxed->glyph.base_scale = st->scale_h;
    boxed->glyph.memory = glyph_memory;
    boxed->owner_handle = glyph_handle;
    boxed->outline = {};
    boxed->outline.outline_flags = boxed->glyph.flags;
    boxed->outline.points_ptr = nullptr;
    boxed->outline.tags_ptr = nullptr;
    boxed->outline.contour_end_idx = nullptr;
    boxed->outline.contours_cnt = 0;
    boxed->outline.points_cnt = 0;
    boxed->outline_initialized = false;

    Internal::TrackGeneratedGlyph(&boxed->glyph);
    *glyph_out = &boxed->glyph;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetAttribute() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetCharGlyphCode() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetCharGlyphMetrics(OrbisFontHandle fontHandle, u32 code,
                                            OrbisFontGlyphMetrics* metrics) {
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("code", code),
                  Param("metrics", metrics),
              }));

    const s32 rc = Internal::GetCharGlyphMetrics(fontHandle, code, metrics, false);
    if (rc != ORBIS_OK) {
        if (rc == ORBIS_FONT_ERROR_INVALID_FONT_HANDLE) {
            LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        } else if (rc == ORBIS_FONT_ERROR_INVALID_PARAMETER) {
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        }
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetEffectSlant(OrbisFontHandle fontHandle, float* slantRatio) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("slantRatio", slantRatio),
              }));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        if (slantRatio) {
            *slantRatio = 0.0f;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_lock = 0;
    if (!AcquireFontLock(font, prev_lock)) {
        if (slantRatio) {
            *slantRatio = 0.0f;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    const s32 rc = Internal::StyleStateGetSlantRatio(font->style_frame, slantRatio);
    ReleaseFontLock(font, prev_lock);

    if (rc != ORBIS_OK) {
        if (slantRatio) {
            *slantRatio = 0.0f;
        }
        LOG_ERROR(Lib_Font, "FAILED");
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetEffectWeight(OrbisFontHandle fontHandle, float* weightXScale,
                                        float* weightYScale, u32* mode) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("weightXScale", weightXScale),
                  Param("weightYScale", weightYScale),
                  Param("mode", mode),
              }));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        if (weightXScale) {
            *weightXScale = 1.0f;
        }
        if (weightYScale) {
            *weightYScale = 1.0f;
        }
        if (mode) {
            *mode = 0;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_lock = 0;
    if (!AcquireFontLock(font, prev_lock)) {
        if (weightXScale) {
            *weightXScale = 1.0f;
        }
        if (weightYScale) {
            *weightYScale = 1.0f;
        }
        if (mode) {
            *mode = 0;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    const s32 rc =
        Internal::StyleStateGetWeightScale(font->style_frame, weightXScale, weightYScale, mode);
    ReleaseFontLock(font, prev_lock);

    if (rc != ORBIS_OK) {
        if (weightXScale) {
            *weightXScale = 1.0f;
        }
        if (weightYScale) {
            *weightYScale = 1.0f;
        }
        if (mode) {
            *mode = 0;
        }
        LOG_ERROR(Lib_Font, "FAILED");
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetFontGlyphsCount() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetFontGlyphsOutlineProfile() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetFontMetrics() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetFontResolution() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetFontStyleInformation() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetGlyphExpandBufferState() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetHorizontalLayout(OrbisFontHandle fontHandle,
                                            OrbisFontHorizontalLayout* layout) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        if (layout) {
            *layout = {};
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        if (layout) {
            *layout = {};
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_lock = 0;
    if (!AcquireFontLock(font, prev_lock)) {
        if (layout) {
            *layout = {};
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (!layout) {
        font->lock_word = prev_lock;
        LOG_ERROR(Lib_Font, "NULL_POINTER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("layout", layout),
              }));

    Internal::HorizontalLayoutBlocks layout_blocks{};
    const s32 rc =
        Internal::ComputeHorizontalLayoutBlocksTyped(fontHandle, font->style_frame, &layout_blocks);
    font->lock_word = prev_lock;

    if (rc == ORBIS_OK) {
        layout->baselineOffset = layout_blocks.baseline();
        layout->lineAdvance = layout_blocks.line_advance();
        layout->decorationExtent = layout_blocks.effect_height();
        const auto* style_frame = reinterpret_cast<const OrbisFontStyleFrame*>(font->style_frame);
        if (style_frame) {
            static std::atomic<int> s_layout_trace_budget{120};
            const int remaining = s_layout_trace_budget.fetch_sub(1, std::memory_order_relaxed);
            if (remaining > 0) {
                LOG_INFO(Lib_Font,
                         "GetHorizontalLayoutTrace: handle={} flags=0x{:02X} unit={} dpi=({}, {}) "
                         "scalePx=({}, {}) weight=({}, {}) slant={} out baseline={} "
                         "lineAdvance={} decoration={}",
                         static_cast<const void*>(fontHandle),
                         static_cast<u32>(style_frame->flags1), style_frame->scaleUnit,
                         style_frame->hDpi, style_frame->vDpi, style_frame->scalePixelW,
                         style_frame->scalePixelH, style_frame->effectWeightX,
                         style_frame->effectWeightY, style_frame->slantRatio,
                         layout->baselineOffset, layout->lineAdvance, layout->decorationExtent);
            }
        }
        LOG_DEBUG(Lib_Font, "GetHorizontalLayout: out baseLineY={} lineHeight={} effectHeight={}",
                  layout->baselineOffset, layout->lineAdvance, layout->decorationExtent);
        return ORBIS_OK;
    }

    *layout = {};
    if (const auto* rec =
            static_cast<const Internal::FontSetRecordHeader*>(font->open_info.fontset_record)) {
        LOG_DEBUG(Lib_Font,
                  "GetHorizontalLayout: fail detail rc={} fontset_record={} magic=0x{:08X} "
                  "entry_count={} ctx_entry_index={} sub_font_index={}",
                  rc, static_cast<const void*>(font->open_info.fontset_record), rec->magic,
                  rec->entry_count, font->open_info.ctx_entry_index,
                  font->open_info.sub_font_index);
        const u32 entry_count = rec->entry_count;
        const auto* entries = reinterpret_cast<const u32*>(rec + 1);
        for (u32 i = 0; i < entry_count; ++i) {
            LOG_DEBUG(Lib_Font, "GetHorizontalLayout: fail detail fontset_entry[{}]={}", i,
                      entries[i]);
        }
    } else {
        LOG_DEBUG(Lib_Font,
                  "GetHorizontalLayout: fail detail rc={} fontset_record=null ctx_entry_index={} "
                  "sub_font_index={}",
                  rc, font->open_info.ctx_entry_index, font->open_info.sub_font_index);
    }
    LOG_ERROR(Lib_Font, "FAILED");
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetKerning(OrbisFontHandle fontHandle, u32 preCode, u32 code,
                                   OrbisFontKerning* kerning) {
    if (!kerning) {
        LOG_DEBUG(Lib_Font, "invalid parameters");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    auto& st = Internal::GetState(fontHandle);
    if (!st.ext_face_ready || !st.ext_ft_face) {
        bool system_attached = false;
        const std::string sys_log =
            Internal::ReportSystemFaceRequest(st, fontHandle, system_attached);
        if (!sys_log.empty()) {
            LOG_ERROR(Lib_Font, "{}", sys_log);
        }
    }

    FT_Face resolved_face = st.ext_ft_face;
    float resolved_scale_factor = st.system_font_scale_factor;
    FT_UInt g1 =
        resolved_face ? FT_Get_Char_Index(resolved_face, static_cast<FT_ULong>(preCode)) : 0;
    FT_UInt g2 = resolved_face ? FT_Get_Char_Index(resolved_face, static_cast<FT_ULong>(code)) : 0;
    if (g1 == 0 || g2 == 0) {
        for (const auto& fb : st.system_fallback_faces) {
            if (!fb.ready || !fb.ft_face) {
                continue;
            }
            const FT_UInt fb_g1 = FT_Get_Char_Index(fb.ft_face, static_cast<FT_ULong>(preCode));
            const FT_UInt fb_g2 = FT_Get_Char_Index(fb.ft_face, static_cast<FT_ULong>(code));
            if (fb_g1 == 0 || fb_g2 == 0) {
                continue;
            }
            resolved_face = fb.ft_face;
            resolved_scale_factor = fb.scale_factor;
            g1 = fb_g1;
            g2 = fb_g2;
            break;
        }
    }

    if (resolved_face && g1 != 0 && g2 != 0) {
        const float scaled_w = st.scale_w * resolved_scale_factor;
        const float scaled_h = st.scale_h * resolved_scale_factor;
        const auto char_w = static_cast<FT_F26Dot6>(static_cast<s32>(scaled_w * 64.0f));
        const auto char_h = static_cast<FT_F26Dot6>(static_cast<s32>(scaled_h * 64.0f));
        (void)FT_Set_Char_Size(resolved_face, char_w, char_h, 72, 72);

        FT_Vector delta{};
        FT_Get_Kerning(resolved_face, g1, g2, FT_KERNING_DEFAULT, &delta);
        const float kx = static_cast<float>(delta.x) / 64.0f;
        kerning->offsetX = kx;
        kerning->offsetY = 0.0f;
        kerning->positionX = 0.0f;
        kerning->positionY = 0.0f;
        return ORBIS_OK;
    }
    kerning->offsetX = 0.0f;
    kerning->offsetY = 0.0f;
    kerning->positionX = 0.0f;
    kerning->positionY = 0.0f;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetLibrary(OrbisFontHandle fontHandle, OrbisFontLib* pLibrary) {
    if (!pLibrary) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    const auto& st = Internal::GetState(fontHandle);
    *pLibrary = st.library;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetPixelResolution() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetRenderCharGlyphMetrics(OrbisFontHandle fontHandle, u32 codepoint,
                                                  OrbisFontGlyphMetrics* out_metrics) {
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("codepoint", codepoint),
                  Param("out_metrics", out_metrics),
              }));

    const s32 rc = Internal::GetCharGlyphMetrics(fontHandle, codepoint, out_metrics, true);
    if (rc != ORBIS_OK) {
        if (rc == ORBIS_FONT_ERROR_INVALID_FONT_HANDLE) {
            LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        } else if (rc == ORBIS_FONT_ERROR_INVALID_PARAMETER) {
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        }
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetRenderEffectSlant(OrbisFontHandle fontHandle, float* slantRatio) {
    s32 rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    auto* font = GetNativeFont(fontHandle);
    if (font && font->magic == 0x0F02) {
        u32 prev_cached_lock = 0;
        if (AcquireCachedStyleLock(font, prev_cached_lock)) {
            if (font->renderer_binding.renderer == nullptr) {
                rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
                font->cached_style.cache_lock_word = prev_cached_lock;
            } else {
                rc = Internal::StyleStateGetSlantRatio(&font->cached_style, slantRatio);
                font->cached_style.cache_lock_word = prev_cached_lock;
                if (rc == ORBIS_OK) {
                    return ORBIS_OK;
                }
            }
        }
    }
    if (slantRatio) {
        *slantRatio = 0.0f;
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetRenderEffectWeight(OrbisFontHandle fontHandle, float* weightXScale,
                                              float* weightYScale, u32* mode) {
    s32 rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    auto* font = GetNativeFont(fontHandle);
    if (font && font->magic == 0x0F02) {
        u32 prev_cached_lock = 0;
        if (AcquireCachedStyleLock(font, prev_cached_lock)) {
            if (font->renderer_binding.renderer == nullptr) {
                rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
                font->cached_style.cache_lock_word = prev_cached_lock;
            } else {
                rc = Internal::StyleStateGetWeightScale(&font->cached_style, weightXScale,
                                                        weightYScale, mode);
                font->cached_style.cache_lock_word = prev_cached_lock;
                if (rc == ORBIS_OK) {
                    return ORBIS_OK;
                }
            }
        }
    }
    if (weightXScale) {
        *weightXScale = 1.0f;
    }
    if (weightYScale) {
        *weightYScale = 1.0f;
    }
    if (mode) {
        *mode = 0;
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetRenderScaledKerning() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetRenderScalePixel(OrbisFontHandle fontHandle, float* out_w,
                                            float* out_h) {
    s32 rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    auto* font = GetNativeFont(fontHandle);
    if (font) {
        u32 prev_cached_lock = 0;
        if (AcquireCachedStyleLock(font, prev_cached_lock)) {
            if (font->renderer_binding.renderer == nullptr) {
                rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
            } else {
                rc = Internal::StyleStateGetScalePixel(&font->cached_style, out_w, out_h);
            }
            ReleaseCachedStyleLock(font, prev_cached_lock);
            if (rc == ORBIS_OK) {
                return rc;
            }
        }
    }
    if (out_w) {
        *out_w = 0.0f;
    }
    if (out_h) {
        *out_h = 0.0f;
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetRenderScalePoint(OrbisFontHandle fontHandle, float* out_w,
                                            float* out_h) {
    s32 rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    auto* font = GetNativeFont(fontHandle);
    if (font) {
        u32 prev_cached_lock = 0;
        if (AcquireCachedStyleLock(font, prev_cached_lock)) {
            if (font->renderer_binding.renderer == nullptr) {
                rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
            } else {
                rc = Internal::StyleStateGetScalePoint(&font->cached_style, out_w, out_h);
            }
            ReleaseCachedStyleLock(font, prev_cached_lock);
            if (rc == ORBIS_OK) {
                return rc;
            }
        }
    }
    if (out_w) {
        *out_w = 0.0f;
    }
    if (out_h) {
        *out_h = 0.0f;
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetResolutionDpi() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetScalePixel(OrbisFontHandle fontHandle, float* out_w, float* out_h) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        if (out_w) {
            *out_w = 0.0f;
        }
        if (out_h) {
            *out_h = 0.0f;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("out_w", out_w),
                  Param("out_h", out_h),
              }));

    s32 rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    auto* font = GetNativeFont(fontHandle);
    if (font && font->magic == 0x0F02) {
        u32 prev_font_lock = 0;
        if (AcquireFontLock(font, prev_font_lock)) {
            rc = Internal::StyleStateGetScalePixel(
                reinterpret_cast<const OrbisFontStyleFrame*>(font->style_frame), out_w, out_h);
            ReleaseFontLock(font, prev_font_lock);
            if (rc == ORBIS_OK) {
                return rc;
            }
        }
    }
    if (out_w) {
        *out_w = 0.0f;
    }
    if (out_h) {
        *out_h = 0.0f;
    }
    if (rc == ORBIS_FONT_ERROR_INVALID_PARAMETER) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
    } else if (rc == ORBIS_FONT_ERROR_INVALID_FONT_HANDLE) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
    } else {
        LOG_ERROR(Lib_Font, "FAILED");
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetScalePoint(OrbisFontHandle fontHandle, float* out_w, float* out_h) {
    s32 rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    auto* font = GetNativeFont(fontHandle);
    if (font) {
        u32 prev_font_lock = 0;
        if (AcquireFontLock(font, prev_font_lock)) {
            rc = Internal::StyleStateGetScalePoint(
                reinterpret_cast<const OrbisFontStyleFrame*>(font->style_frame), out_w, out_h);
            ReleaseFontLock(font, prev_font_lock);
            if (rc == ORBIS_OK) {
                return rc;
            }
        }
    }
    if (out_w) {
        *out_w = 0.0f;
    }
    if (out_h) {
        *out_h = 0.0f;
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGetScriptLanguage() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetTypographicDesign() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGetVerticalLayout(OrbisFontHandle fontHandle,
                                          OrbisFontVerticalLayout* layout) {
    s32 rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    auto* font = GetNativeFont(fontHandle);
    if (font && font->magic == 0x0F02) {
        u32 prev_font_lock = 0;
        if (AcquireFontLock(font, prev_font_lock)) {
            if (!layout) {
                font->lock_word = prev_font_lock;
                rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
            } else {
                Internal::VerticalLayoutBlocks layout_words{};
                rc = Internal::ComputeVerticalLayoutBlocksTyped(fontHandle, font->style_frame,
                                                                &layout_words);
                font->lock_word = prev_font_lock;
                if (rc == ORBIS_OK) {
                    layout->baselineOffsetX = layout_words.baseline_offset_x();
                    layout->columnAdvance = layout_words.column_advance();
                    layout->decorationSpan = layout_words.decoration_span();
                    return ORBIS_OK;
                }
            }
        }
    }

    if (layout) {
        layout->decorationSpan = 0.0f;
        *reinterpret_cast<std::uint64_t*>(layout) = 0;
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontGlyphDefineAttribute() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGlyphGetAttribute() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGlyphGetGlyphForm(OrbisFontGlyph fontGlyph) {
    if (!fontGlyph || fontGlyph->magic != 0x0F03) {
        return ORBIS_FONT_ERROR_INVALID_GLYPH;
    }
    return static_cast<s32>(fontGlyph->glyph_form);
}

s32 PS4_SYSV_ABI sceFontGlyphGetMetricsForm(OrbisFontGlyph fontGlyph) {
    if (!fontGlyph || fontGlyph->magic != 0x0F03) {
        return ORBIS_FONT_ERROR_INVALID_GLYPH;
    }
    return static_cast<s32>(fontGlyph->metrics_form);
}

s32 PS4_SYSV_ABI sceFontGlyphGetScalePixel(OrbisFontGlyph fontGlyph, float* w, float* h) {
    if (!fontGlyph || fontGlyph->magic != 0x0F03 || (!w && !h)) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    if (w) {
        *w = fontGlyph->scale_x;
    }
    if (h) {
        *h = fontGlyph->base_scale;
    }
    return ORBIS_OK;
}

const OrbisFontGlyphMetrics* PS4_SYSV_ABI sceFontGlyphRefersMetrics(OrbisFontGlyph fontGlyph) {
    auto* boxed = Internal::TryGetGeneratedGlyph(fontGlyph);
    return boxed ? &boxed->metrics : nullptr;
}

const OrbisFontGlyphMetricsHorizontal* PS4_SYSV_ABI
sceFontGlyphRefersMetricsHorizontal(OrbisFontGlyph fontGlyph) {
    auto* boxed = Internal::TryGetGeneratedGlyph(fontGlyph);
    if (!boxed) {
        return nullptr;
    }
    Internal::PopulateGlyphMetricVariants(*boxed);
    return &boxed->metrics_horizontal;
}

const OrbisFontGlyphMetricsHorizontalAdvance* PS4_SYSV_ABI
sceFontGlyphRefersMetricsHorizontalAdvance(OrbisFontGlyph fontGlyph) {
    auto* boxed = Internal::TryGetGeneratedGlyph(fontGlyph);
    if (!boxed) {
        return nullptr;
    }
    Internal::PopulateGlyphMetricVariants(*boxed);
    return &boxed->metrics_horizontal_adv;
}

const OrbisFontGlyphMetricsHorizontalX* PS4_SYSV_ABI
sceFontGlyphRefersMetricsHorizontalX(OrbisFontGlyph fontGlyph) {
    auto* boxed = Internal::TryGetGeneratedGlyph(fontGlyph);
    if (!boxed) {
        return nullptr;
    }
    Internal::PopulateGlyphMetricVariants(*boxed);
    return &boxed->metrics_horizontal_x;
}

OrbisFontGlyphOutline* PS4_SYSV_ABI sceFontGlyphRefersOutline(OrbisFontGlyph glyph) {
    if (!glyph || glyph->magic != 0x0F03 || glyph->glyph_form != 1) {
        return nullptr;
    }
    auto* boxed = Internal::TryGetGeneratedGlyph(glyph);
    if (!boxed) {
        return nullptr;
    }
    if (!boxed->outline_initialized) {
        if (!Internal::BuildTrueOutline(*boxed)) {
            Internal::BuildBoundingOutline(*boxed);
        }
    }
    return &boxed->outline;
}

s32 PS4_SYSV_ABI sceFontGlyphRenderImage() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGlyphRenderImageHorizontal() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGlyphRenderImageVertical() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsBeginFrame() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsDrawingCancel() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsDrawingFinish() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsEndFrame() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsExchangeResource() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsFillMethodInit() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsFillPlotInit() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsFillPlotSetLayout() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsFillPlotSetMapping() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsFillRatesInit() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsFillRatesSetFillEffect() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsFillRatesSetLayout() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsFillRatesSetMapping() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsGetDeviceUsage() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsRegionInit() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsRegionInitCircular() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsRegionInitRoundish() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsRelease() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsRenderResource() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetFramePolicy() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupClipping() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupColorRates() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupFillMethod() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupFillRates() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupGlyphFill() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupGlyphFillPlot() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupHandleDefault() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupLocation() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupPositioning() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupRotation() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupScaling() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupShapeFill() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsSetupShapeFillPlot() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsStructureCanvas() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsStructureCanvasSequence() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsStructureDesign() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsStructureDesignResource() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsStructureSurfaceTexture() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateClipping() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateColorRates() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateFillMethod() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateFillRates() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateGlyphFill() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateGlyphFillPlot() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateLocation() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdatePositioning() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateRotation() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateScaling() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateShapeFill() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontGraphicsUpdateShapeFillPlot() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontMemoryInit(OrbisFontMem* mem_desc, void* region_addr, u32 region_size,
                                   const OrbisFontMemInterface* iface, void* mspace_obj,
                                   OrbisFontMemDestroyCb destroy_cb, void* destroy_ctx) {
    LOG_INFO(Lib_Font, "called");

    if (!mem_desc) {
        LOG_ERROR(Lib_Font, "NULL_POINTER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("mem_desc", mem_desc),
                  Param("region_addr", region_addr),
                  Param("region_size", region_size),
                  Param("iface", iface),
                  Param("mspace_obj", mspace_obj),
                  Param("destroy_cb", reinterpret_cast<const void*>(destroy_cb)),
                  Param("destroy_ctx", destroy_ctx),
              }));

    if (!iface) {
        mem_desc->mem_kind = 0;
        if (!region_addr || region_size == 0) {
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
            return ORBIS_FONT_ERROR_INVALID_PARAMETER;
        }
    }

    mem_desc->mem_kind = 0x0F00;
    mem_desc->attr_bits = 0;
    mem_desc->region_size = region_size;
    mem_desc->region_base = region_addr;
    mem_desc->mspace_handle = mspace_obj;
    mem_desc->iface = iface;
    mem_desc->on_destroy = destroy_cb;
    mem_desc->destroy_ctx = destroy_ctx;
    mem_desc->some_ctx1 = nullptr;
    mem_desc->some_ctx2 = mspace_obj;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontMemoryTerm(OrbisFontMem* mem_desc) {
    if (!mem_desc) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (mem_desc->mem_kind != 0x0F00) {
        return ORBIS_FONT_ERROR_INVALID_MEMORY;
    }

    if (static_cast<s8>(mem_desc->attr_bits & 0xFF) < 0) {
        if (mem_desc->iface && mem_desc->iface->mspace_destroy) {
            const auto destroy_fn =
                reinterpret_cast<void(PS4_SYSV_ABI*)(void* parent, void* mspace)>(
                    mem_desc->iface->mspace_destroy);
            if (destroy_fn) {
                destroy_fn(mem_desc->some_ctx2, mem_desc->mspace_handle);
            }
        }
        std::memset(mem_desc, 0, sizeof(*mem_desc));
        return ORBIS_OK;
    }

    if (mem_desc->on_destroy) {
        mem_desc->mem_kind = 0;
        const auto destroy_fn = reinterpret_cast<void(PS4_SYSV_ABI*)(
            OrbisFontMem * fontMemory, void* object, void* destroyArg)>(mem_desc->on_destroy);
        destroy_fn(mem_desc, mem_desc->mspace_handle, mem_desc->destroy_ctx);
        return ORBIS_OK;
    }

    std::memset(mem_desc, 0, sizeof(*mem_desc));
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontOpenFontFile(OrbisFontLib library, const char* guest_path, u32 open_mode,
                                     const OrbisFontOpenParams* open_detail,
                                     OrbisFontHandle* out_handle) {
    LOG_INFO(Lib_Font, "called");

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("library", library),
                  Param("guest_path", guest_path),
                  Param("open_mode", open_mode),
                  Param("open_detail", open_detail),
                  Param("out_handle", out_handle),
              }));

    if (!library) {
        if (out_handle) {
            *out_handle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    if (!out_handle) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    auto* lib = static_cast<Internal::FontLibOpaque*>(library);
    if (lib->magic != 0x0F01) {
        *out_handle = nullptr;
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    u32 prev_lib_lock = 0;
    if (!AcquireLibraryLock(lib, prev_lib_lock)) {
        *out_handle = nullptr;
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    const auto release_library_and_clear_out = [&] {
        ReleaseLibraryLock(lib, prev_lib_lock);
        *out_handle = nullptr;
    };

    if (!lib->fontset_registry || !lib->sys_driver) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    const u32 sub_font_index = open_detail ? open_detail->subfont_index : 0u;
    const s32 unique_id = open_detail ? open_detail->unique_id : -1;

    const auto alloc_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontAllocFn>(lib->alloc_vtbl[0]) : nullptr;
    const auto free_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontFreeFn>(lib->alloc_vtbl[1]) : nullptr;
    if (!alloc_fn || !free_fn) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    auto* ext_ctx = static_cast<u8*>(lib->external_fonts_ctx);
    if (!ext_ctx) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "NO_SUPPORT_FUNCTION");
        return ORBIS_FONT_ERROR_NO_SUPPORT_FUNCTION;
    }

    if (!guest_path || unique_id < -1) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    const auto host_path = ResolveGuestPath(guest_path);
    const std::filesystem::path path_to_open =
        host_path.empty() ? std::filesystem::path(guest_path) : host_path;
    const std::string host_path_str = path_to_open.string();
    if (host_path_str.empty()) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    const std::string guest_name = std::filesystem::path(guest_path).filename().string();

    OrbisFontHandle handle = *out_handle;
    if (handle) {
        if (auto* h = GetNativeFont(handle)) {
            h->flags = 0;
        }
        Internal::RemoveState(handle);
    } else {
        handle = static_cast<OrbisFontHandle>(alloc_fn(lib->alloc_ctx, 0x100));
        if (!handle) {
            release_library_and_clear_out();
            LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
            return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
        }
        std::memset(handle, 0, 0x100);
        if (auto* h = GetNativeFont(handle)) {
            h->flags = 0x10;
        }
    }

    auto cleanup_handle_for_error = [&](s32 err) {
        auto* h = GetNativeFont(handle);
        if (!h) {
            ReleaseLibraryLock(lib, prev_lib_lock);
            *out_handle = nullptr;
            return err;
        }
        h->magic = 0;
        h->open_info.unique_id_packed = 0;
        h->open_info.ctx_entry_index = 0;
        h->open_info.sub_font_index = 0;
        h->open_info.fontset_flags = 0;
        h->open_info.fontset_record = nullptr;
        h->open_info.reserved_0x18 = 0;
        h->library = library;
        const u16 prev_flags = h->flags;
        h->flags = 0;
        if ((prev_flags & 0x10) != 0) {
            free_fn(lib->alloc_ctx, handle);
        }
        Internal::RemoveState(handle);
        ReleaseLibraryLock(lib, prev_lib_lock);
        *out_handle = nullptr;
        return err;
    };

    auto* ext_header = reinterpret_cast<Internal::FontCtxHeader*>(ext_ctx);

    auto* ctx_lock_word = &ext_header->lock_word;
    for (;;) {
        const u32 lw = *ctx_lock_word;
        if (static_cast<s32>(lw) >= 0) {
            std::atomic_ref<u32> ref(*ctx_lock_word);
            u32 expected = lw;
            if (ref.compare_exchange_weak(expected, lw | 0x80000000u, std::memory_order_acq_rel)) {
                break;
            }
        }
        Libraries::Kernel::sceKernelUsleep(0x1e);
    }

    const u32 font_max = ext_header->max_entries;
    auto* entries_base = static_cast<Internal::FontCtxEntry*>(ext_header->base);
    if (font_max == 0 || !entries_base) {
        *ctx_lock_word = 0;
        const s32 err = cleanup_handle_for_error(ORBIS_FONT_ERROR_FONT_OPEN_MAX);
        LogFontOpenError(err);
        return err;
    }

    u32 entry_index = 0xffffffffu;
    u32 first_free = 0xffffffffu;
    for (u32 i = 0; i < font_max; i++) {
        auto* entry = &entries_base[i];
        const u32 active = entry->active;
        const u32 stored_id = entry->unique_id;
        if (active != 0 && stored_id == static_cast<u32>(unique_id)) {
            entry_index = i;
            break;
        }
        if (first_free == 0xffffffffu && active == 0) {
            first_free = i;
        }
    }

    if (entry_index == 0xffffffffu) {
        entry_index = first_free;
        if (entry_index == 0xffffffffu) {
            *ctx_lock_word = 0;
            const s32 err = cleanup_handle_for_error(ORBIS_FONT_ERROR_FONT_OPEN_MAX);
            LogFontOpenError(err);
            return err;
        }

        auto* entry = &entries_base[entry_index];
        const u32 stored_id =
            (unique_id != -1) ? static_cast<u32>(unique_id) : (entry_index ^ 0x80000000u);
        entry->reserved_0x00 = 0;
        entry->active = 1;
        entry->font_address = 0;
        entry->unique_id = stored_id;
        entry->lock_mode1 = 0;
        entry->lock_mode3 = 0;
        entry->lock_mode2 = 0;
        entry->obj_mode1 = nullptr;
        entry->obj_mode3 = nullptr;
        entry->obj_mode2 = nullptr;
        std::memset(entry->reserved_0x38, 0, sizeof(entry->reserved_0x38));
    }

    *ctx_lock_word = 0;

    const u32 packed_unique_id = (unique_id == -1) ? (entry_index + 0x40000000u)
                                                   : (static_cast<u32>(unique_id) | 0x80000000u);

    void* font_obj = nullptr;
    u32 entry_lock_word = 0;
    u8* entry_base =
        Internal::AcquireFontCtxEntry(ext_ctx, entry_index, open_mode, &font_obj, &entry_lock_word);
    auto* entry = entry_base ? reinterpret_cast<Internal::FontCtxEntry*>(entry_base) : nullptr;
    if (!entry_base) {
        const s32 err = cleanup_handle_for_error(ORBIS_FONT_ERROR_FONT_OPEN_MAX);
        LogFontOpenError(err);
        return err;
    }

    const u32 mode_low = open_mode & 0xF;

    const auto* driver =
        lib->sys_driver ? reinterpret_cast<const Internal::SysDriver*>(lib->sys_driver) : nullptr;
    const auto open_fn = driver ? driver->open : nullptr;
    const auto metric_fn = driver ? driver->metric : nullptr;
    const auto scale_fn = driver ? driver->scale : nullptr;
    if (!open_fn || !metric_fn || !scale_fn) {
        const s32 err = cleanup_handle_for_error(ORBIS_FONT_ERROR_INVALID_LIBRARY);
        LogFontOpenError(err);
        return err;
    }

    s32 rc = ORBIS_OK;
    u32 updated_lock = entry_lock_word;
    void* used_font_obj = font_obj;

    const auto open_driver_mode_for = [&](u32 m) -> u32 {
        if (m == 1) {
            return 5;
        }
        if (m == 2) {
            return 6;
        }
        return 7;
    };

    if ((entry_lock_word & 0x40000000u) == 0) {
        auto* tail = lib + 1;
        auto* tail_reserved1 =
            tail ? reinterpret_cast<Internal::FontLibReserved1SysfontTail*>(tail->reserved1)
                 : nullptr;
        const u32 lib_flags = lib->flags;
        if (mode_low == 2) {
            if ((lib_flags & 0x100000u) != 0) {
                tail_reserved1->sysfont_flags |= 1;
            }
            if ((lib_flags & 0x10000u) != 0) {
                tail_reserved1->sysfont_flags |= 2;
            }
        } else {
            if ((lib_flags & 0x200000u) != 0) {
                tail_reserved1->sysfont_flags |= 1;
            }
            if ((lib_flags & 0x20000u) != 0) {
                tail_reserved1->sysfont_flags |= 2;
            }
        }

        if (mode_low != 1 && mode_low != 2 && mode_low != 3) {
            rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
        } else {
            used_font_obj = font_obj;
            rc = open_fn(library, open_driver_mode_for(mode_low), host_path_str.c_str(), 0,
                         sub_font_index, packed_unique_id, &used_font_obj);
        }

        if (tail_reserved1) {
            tail_reserved1->sysfont_flags = 0;
        }

        if (rc == ORBIS_OK) {
            if (mode_low == 3) {
                entry->obj_mode3 = used_font_obj;
            } else if (mode_low == 2) {
                entry->obj_mode2 = used_font_obj;
            } else {
                entry->obj_mode1 = used_font_obj;
            }
            updated_lock = entry_lock_word | 0x40000000u;
        }
    } else {
        rc = ORBIS_FONT_ERROR_FONT_OPEN_MAX;
        if ((entry_lock_word & 0x0FFFFFFFu) != 0x0FFFFFFFu) {
            for (auto* node = static_cast<Internal::FontObj*>(font_obj); node != nullptr;
                 node = node->next) {
                if (node->sub_font_index == sub_font_index) {
                    node->refcount++;
                    used_font_obj = node;
                    rc = ORBIS_OK;
                    break;
                }
            }
            if (rc != ORBIS_OK) {
                auto* tail = lib + 1;
                auto* tail_reserved1 =
                    tail ? reinterpret_cast<Internal::FontLibReserved1SysfontTail*>(tail->reserved1)
                         : nullptr;
                const u32 lib_flags = lib->flags;
                if (mode_low == 2) {
                    if ((lib_flags & 0x100000u) != 0) {
                        tail_reserved1->sysfont_flags |= 1;
                    }
                    if ((lib_flags & 0x10000u) != 0) {
                        tail_reserved1->sysfont_flags |= 2;
                    }
                } else {
                    if ((lib_flags & 0x200000u) != 0) {
                        tail_reserved1->sysfont_flags |= 1;
                    }
                    if ((lib_flags & 0x20000u) != 0) {
                        tail_reserved1->sysfont_flags |= 2;
                    }
                }

                used_font_obj = font_obj;
                rc = open_fn(library, open_driver_mode_for(mode_low), host_path_str.c_str(), 0,
                             sub_font_index, packed_unique_id, &used_font_obj);
                if (tail_reserved1) {
                    tail_reserved1->sysfont_flags = 0;
                }

                if (rc == ORBIS_OK) {
                    if (mode_low == 3) {
                        entry->obj_mode3 = used_font_obj;
                    } else if (mode_low == 2) {
                        entry->obj_mode2 = used_font_obj;
                    } else {
                        entry->obj_mode1 = used_font_obj;
                    }
                }
            }
        }
    }

    if (rc == ORBIS_OK) {
        LOG_WARNING(Lib_Font, "font file served: requested=\"{}\" served=\"{}\"", guest_name,
                    host_path_str);
        const u32 next_lock = updated_lock + 1;
        updated_lock = next_lock;

        auto* h = GetNativeFont(handle);
        if (!h) {
            const s32 err = cleanup_handle_for_error(ORBIS_FONT_ERROR_FATAL);
            LogFontOpenError(err);
            return err;
        }
        h->magic = 0x0F02;
        h->flags = static_cast<u16>(h->flags | static_cast<u16>(mode_low));
        h->open_info.unique_id_packed = packed_unique_id;
        h->open_info.ctx_entry_index = entry_index;
        h->open_info.fontset_flags = 0;
        h->open_info.fontset_record = nullptr;
        h->open_info.reserved_0x18 = 0;
        h->open_info.sub_font_index = sub_font_index;
        h->library = library;
        std::memset(&h->cached_style, 0, sizeof(h->cached_style));
        std::memset(h->reserved_0xcc, 0, sizeof(h->reserved_0xcc));
        std::memset(h->reserved_0x30, 0, sizeof(h->reserved_0x30));
        std::memset(h->reserved_0xe8, 0, sizeof(h->reserved_0xe8));
        h->prevFont = nullptr;
        h->nextFont = nullptr;

        u16 metric_buf[2] = {};
        (void)metric_fn(used_font_obj, 0x0e00, metric_buf);
        h->metricA = metric_buf[0];
        (void)metric_fn(used_font_obj, 0xea00, metric_buf);
        h->metricB = metric_buf[0];
        h->style_frame[0] = 0x48;
        h->style_frame[1] = 0x48;

        float scale = 0.0f;
        (void)scale_fn(used_font_obj, metric_buf, &scale);
        h->style_tail.scale_unit = 0;
        h->style_tail.reserved_0x0c = 0;
        h->style_tail.scale_w = scale;
        h->style_tail.scale_h = scale;
        h->style_tail.effect_weight_x = 0.0f;
        h->style_tail.effect_weight_y = 0.0f;
        h->style_tail.slant_ratio = 0.0f;
        h->style_tail.reserved_0x24 = 0.0f;

        *out_handle = handle;
    }

    {
        const u32 count = updated_lock & 0x0FFFFFFFu;
        if (mode_low == 3) {
            if (count == 0) {
                entry->obj_mode3 = nullptr;
            }
            entry->lock_mode3 = updated_lock & 0x7fffffffu;
        } else if (mode_low == 1) {
            if (count == 0) {
                entry->obj_mode1 = nullptr;
            }
            entry->lock_mode1 = updated_lock & 0x7fffffffu;
        } else {
            if (count == 0) {
                entry->obj_mode2 = nullptr;
            }
            entry->lock_mode2 = updated_lock & 0x7fffffffu;
        }

        if (count == 0 && entry->obj_mode1 == nullptr && entry->obj_mode3 == nullptr &&
            entry->obj_mode2 == nullptr) {
            entry->unique_id = 0;
            entry->active = 0;
        }
    }

    if (rc != ORBIS_OK) {
        const s32 err = cleanup_handle_for_error(rc);
        LogFontOpenError(err);
        return err;
    }

    const auto* handle_native = GetNativeFont(handle);
    if (handle_native && (handle_native->flags & 0x10) != 0) {
        auto* tail = reinterpret_cast<Internal::FontLibTail*>(lib + 1);
        auto* list_lock = &tail->list_head_ptr;
        void* list_ptr = nullptr;
        for (;;) {
            list_ptr = *list_lock;
            if (list_ptr != reinterpret_cast<void*>(std::numeric_limits<std::uintptr_t>::max())) {
                std::atomic_ref<void*> ref(*list_lock);
                void* expected = list_ptr;
                if (ref.compare_exchange_weak(
                        expected,
                        reinterpret_cast<void*>(std::numeric_limits<std::uintptr_t>::max()),
                        std::memory_order_acq_rel)) {
                    break;
                }
            }
            Libraries::Kernel::sceKernelUsleep(0x1e);
        }

        auto* head_ptr = reinterpret_cast<OrbisFontHandle*>(list_ptr);
        if (head_ptr) {
            const OrbisFontHandle old_head = *head_ptr;
            if (auto* h = GetNativeFont(handle)) {
                h->prevFont = nullptr;
                h->nextFont = old_head;
            }
            if (old_head) {
                if (auto* old_native = GetNativeFont(old_head)) {
                    old_native->prevFont = handle;
                }
            }
            *head_ptr = handle;
        }
        *list_lock = list_ptr;
    }

    ReleaseLibraryLock(lib, prev_lib_lock);

    std::vector<unsigned char> file_bytes;
    if (LoadGuestPathBytes(guest_path, file_bytes) &&
        file_bytes.size() <= std::numeric_limits<u32>::max()) {
        auto& st = Internal::GetState(handle);
        Internal::DestroyFreeTypeFace(st.ext_ft_face);
        for (auto& fb : st.system_fallback_faces) {
            Internal::DestroyFreeTypeFace(fb.ft_face);
        }
        st = {};
        st.library = library;
        st.font_set_type = 0;
        st.system_font_path.clear();
        st.ext_face_data = std::move(file_bytes);

        const u32 chosen_index = open_detail ? open_detail->subfont_index : 0u;
        st.ext_ft_face = Internal::CreateFreeTypeFaceFromBytes(
            st.ext_face_data.data(), st.ext_face_data.size(), chosen_index);
        if (st.ext_ft_face) {
            st.ext_cache.clear();
            st.scratch.clear();
            st.logged_ext_use = false;
            st.ext_scale_for_height = 0.0f;
            st.layout_cached = false;
            const Internal::FaceMetrics m = Internal::LoadFaceMetrics(st.ext_ft_face);
            Internal::PopulateStateMetrics(st, m);
            st.ext_face_ready = true;
        } else {
            st.ext_face_ready = false;
        }
    }

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontOpenFontInstance(OrbisFontHandle fontHandle, OrbisFontHandle setupFont,
                                         OrbisFontHandle* pFontHandle) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (!setupFont && !pFontHandle) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("setupFont", setupFont),
                  Param("pFontHandle", pFontHandle),
              }));

    auto* src = GetNativeFont(fontHandle);
    if (!src || src->magic != 0x0F02) {
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_font_lock = 0;
    if (!AcquireFontLock(src, prev_font_lock)) {
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    auto release_src_lock = [&] { ReleaseFontLock(src, prev_font_lock); };

    auto* lib = static_cast<Internal::FontLibOpaque*>(src->library);
    if (!lib || lib->magic != 0x0F01) {
        release_src_lock();
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    const auto alloc_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontAllocFn>(lib->alloc_vtbl[0]) : nullptr;
    const auto free_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontFreeFn>(lib->alloc_vtbl[1]) : nullptr;

    const u32 open_mode_low = static_cast<u32>(src->flags) & 0x0Fu;
    const u32 src_sub_font_index = src->open_info.sub_font_index;

    const bool publishable_sysfont_instance = false;

    const auto* fontset_record =
        static_cast<const Internal::FontSetRecordHeader*>(src->open_info.fontset_record);
    const u32* entry_indices = nullptr;
    u32 entry_count = 0;
    u8* ctx = nullptr;

    if (!fontset_record) {
        entry_count = 1;
        entry_indices = &src->open_info.ctx_entry_index;
        ctx = static_cast<u8*>(lib->external_fonts_ctx);
    } else {
        entry_count = fontset_record->entry_count;
        entry_indices = reinterpret_cast<const u32*>(fontset_record + 1);
        ctx = static_cast<u8*>(lib->sysfonts_ctx);
    }

    if (!publishable_sysfont_instance && (!ctx || !entry_indices || entry_count == 0)) {
        release_src_lock();
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    OrbisFontHandle out_handle = setupFont;
    bool owned = false;
    if (!out_handle) {
        if (!alloc_fn || !free_fn) {
            release_src_lock();
            if (pFontHandle) {
                *pFontHandle = nullptr;
            }
            LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
            return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
        }
        out_handle = static_cast<OrbisFontHandle>(alloc_fn(lib->alloc_ctx, 0x100));
        if (!out_handle) {
            release_src_lock();
            if (pFontHandle) {
                *pFontHandle = nullptr;
            }
            LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
            return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
        }
        std::memset(out_handle, 0, 0x100);
        if (auto* out_native = GetNativeFont(out_handle)) {
            out_native->flags = 0x10;
        }
        owned = true;
    } else {
        if (auto* out_native = GetNativeFont(out_handle)) {
            out_native->flags = 0;
        }
        Internal::RemoveState(out_handle);
    }

    std::memcpy(out_handle, fontHandle, 0x100);
    auto* dst = GetNativeFont(out_handle);
    dst->lock_word = 0;
    dst->cached_style.cache_lock_word = 0;
    dst->flags = static_cast<u16>((dst->flags & 0xFF0Fu) | (owned ? 0x10u : 0u));

    if (!publishable_sysfont_instance) {
        auto* ctx_header = reinterpret_cast<Internal::FontCtxHeader*>(ctx);
        auto* entries_base = ctx_header ? static_cast<u8*>(ctx_header->base) : nullptr;
        const u32 max_entries = ctx_header ? ctx_header->max_entries : 0u;
        if (!entries_base || entry_count > max_entries) {
            dst->magic = 0;
            if (owned && free_fn) {
                free_fn(lib->alloc_ctx, out_handle);
            }
            release_src_lock();
            if (pFontHandle) {
                *pFontHandle = nullptr;
            }
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
            return ORBIS_FONT_ERROR_INVALID_PARAMETER;
        }

        std::vector<std::pair<u32, Internal::FontObj*>> increments;
        increments.reserve(entry_count);

        auto lock_word_ptr_for_mode = [&](Internal::FontCtxEntry* entry, u32 m) -> u32* {
            if (!entry) {
                return nullptr;
            }
            if (m == 3) {
                return &entry->lock_mode3;
            }
            if (m == 1) {
                return &entry->lock_mode1;
            }
            if (m == 2) {
                return &entry->lock_mode2;
            }
            return nullptr;
        };
        auto obj_slot_for_mode = [&](Internal::FontCtxEntry* entry, u32 m) -> void** {
            if (!entry) {
                return nullptr;
            }
            if (m == 3) {
                return &entry->obj_mode3;
            }
            if (m == 1) {
                return &entry->obj_mode1;
            }
            if (m == 2) {
                return &entry->obj_mode2;
            }
            return nullptr;
        };

        s32 rc = ORBIS_OK;
        for (u32 i = 0; i < entry_count; i++) {
            const u32 entry_index = entry_indices[i];
            if (static_cast<s32>(entry_index) < 0) {
                continue;
            }
            if (entry_index >= max_entries) {
                rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
                break;
            }

            auto* entry = reinterpret_cast<Internal::FontCtxEntry*>(
                entries_base + entry_index * sizeof(Internal::FontCtxEntry));
            auto* lock_word_ptr = lock_word_ptr_for_mode(entry, open_mode_low);
            auto** obj_slot = obj_slot_for_mode(entry, open_mode_low);
            if (!lock_word_ptr || !obj_slot) {
                rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
                break;
            }

            u32 prev_lock = 0;
            for (;;) {
                const u32 lw = *lock_word_ptr;
                if (static_cast<s32>(lw) >= 0) {
                    std::atomic_ref<u32> ref(*lock_word_ptr);
                    u32 expected = lw;
                    if (ref.compare_exchange_weak(expected, lw | 0x80000000u,
                                                  std::memory_order_acq_rel)) {
                        prev_lock = lw;
                        break;
                    }
                }
                Libraries::Kernel::sceKernelUsleep(0x1e);
            }

            auto unlock_entry = [&](u32 updated) { *lock_word_ptr = updated & 0x7fffffffu; };

            if ((prev_lock & 0x40000000u) == 0) {
                unlock_entry(prev_lock);
                rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
                break;
            }
            if ((prev_lock & 0x0FFFFFFFu) == 0x0FFFFFFFu) {
                unlock_entry(prev_lock);
                rc = ORBIS_FONT_ERROR_FONT_OPEN_MAX;
                break;
            }

            auto* node = static_cast<Internal::FontObj*>(*obj_slot);
            for (; node != nullptr; node = node->next) {
                if (node->sub_font_index == src_sub_font_index) {
                    break;
                }
            }
            if (!node) {
                unlock_entry(prev_lock);
                rc = ORBIS_FONT_ERROR_FATAL;
                break;
            }

            node->refcount++;
            unlock_entry(prev_lock + 1);
            increments.push_back({entry_index, node});
        }

        if (rc != ORBIS_OK) {
            for (const auto& inc : increments) {
                if (inc.first >= max_entries || !inc.second) {
                    continue;
                }
                auto* entry = reinterpret_cast<Internal::FontCtxEntry*>(
                    entries_base + inc.first * sizeof(Internal::FontCtxEntry));
                auto* lock_word_ptr = lock_word_ptr_for_mode(entry, open_mode_low);
                if (!lock_word_ptr) {
                    continue;
                }
                u32 prev_lock = 0;
                for (;;) {
                    const u32 lw = *lock_word_ptr;
                    if (static_cast<s32>(lw) >= 0) {
                        std::atomic_ref<u32> ref(*lock_word_ptr);
                        u32 expected = lw;
                        if (ref.compare_exchange_weak(expected, lw | 0x80000000u,
                                                      std::memory_order_acq_rel)) {
                            prev_lock = lw;
                            break;
                        }
                    }
                    Libraries::Kernel::sceKernelUsleep(0x1e);
                }
                if ((prev_lock & 0x0FFFFFFFu) != 0) {
                    inc.second->refcount--;
                    *lock_word_ptr = (prev_lock - 1) & 0x7fffffffu;
                } else {
                    *lock_word_ptr = prev_lock & 0x7fffffffu;
                }
            }

            dst->magic = 0;
            dst->open_info.unique_id_packed = 0;
            dst->open_info.ctx_entry_index = 0;
            dst->open_info.sub_font_index = 0;
            dst->open_info.fontset_flags = 0;
            dst->open_info.fontset_record = nullptr;
            dst->open_info.reserved_0x18 = 0;
            dst->library = lib;
            const u16 prev_flags = dst->flags;
            dst->flags = 0;
            if ((prev_flags & 0x10) != 0 && free_fn) {
                free_fn(lib->alloc_ctx, out_handle);
            }
            Internal::RemoveState(out_handle);

            release_src_lock();
            if (pFontHandle) {
                *pFontHandle = nullptr;
            }
            LOG_ERROR(Lib_Font, "FAILED");
            return rc;
        }
    }

    if (owned) {
        auto* tail = reinterpret_cast<Internal::FontLibTail*>(lib + 1);
        auto* list_lock = tail ? &tail->list_head_ptr : nullptr;
        void* list_ptr = nullptr;
        for (;;) {
            list_ptr = list_lock ? *list_lock : nullptr;
            if (list_ptr != reinterpret_cast<void*>(std::numeric_limits<std::uintptr_t>::max())) {
                std::atomic_ref<void*> ref(*list_lock);
                void* expected = list_ptr;
                if (ref.compare_exchange_weak(
                        expected,
                        reinterpret_cast<void*>(std::numeric_limits<std::uintptr_t>::max()),
                        std::memory_order_acq_rel)) {
                    break;
                }
            }
            Libraries::Kernel::sceKernelUsleep(0x1e);
        }

        auto* head_ptr = reinterpret_cast<OrbisFontHandle*>(list_ptr);
        if (head_ptr) {
            const OrbisFontHandle old_head = *head_ptr;
            if (auto* out_native = GetNativeFont(out_handle)) {
                out_native->prevFont = nullptr;
                out_native->nextFont = old_head;
            }
            if (old_head) {
                if (auto* old_native = GetNativeFont(old_head)) {
                    old_native->prevFont = out_handle;
                }
            }
            *head_ptr = out_handle;
        }
        *list_lock = list_ptr;
    }

    release_src_lock();

    if (auto* src_state = Internal::TryGetState(fontHandle)) {
        auto& dst_state = Internal::GetState(out_handle);
        dst_state = *src_state;
        dst_state.ext_cache.clear();
        dst_state.scratch.clear();
        dst_state.logged_ext_use = false;

        const u32 subfont_index = out_handle && GetNativeFont(out_handle)
                                      ? GetNativeFont(out_handle)->open_info.sub_font_index
                                      : 0u;

        dst_state.ext_scale_for_height = 0.0f;
        dst_state.layout_cached = false;
        dst_state.ext_face_ready = false;
        dst_state.ext_ft_face = nullptr;

        if (!dst_state.ext_face_data.empty()) {
            dst_state.ext_ft_face = Internal::CreateFreeTypeFaceFromBytes(
                dst_state.ext_face_data.data(), dst_state.ext_face_data.size(), subfont_index);
        }
        if (dst_state.ext_ft_face) {
            const Internal::FaceMetrics m = Internal::LoadFaceMetrics(dst_state.ext_ft_face);
            Internal::PopulateStateMetrics(dst_state, m);
            dst_state.ext_face_ready = true;
        }

        for (auto& fb : dst_state.system_fallback_faces) {
            fb.ft_face = nullptr;
            fb.ready = false;
            if (!fb.bytes || fb.bytes->empty()) {
                continue;
            }
            fb.ft_face = Internal::CreateFreeTypeFaceFromBytes(fb.bytes->data(), fb.bytes->size(),
                                                               subfont_index);
            fb.ready = (fb.ft_face != nullptr);
        }
    } else {
        auto& dst_state = Internal::GetState(out_handle);
        Internal::DestroyFreeTypeFace(dst_state.ext_ft_face);
        for (auto& fb : dst_state.system_fallback_faces) {
            Internal::DestroyFreeTypeFace(fb.ft_face);
        }
        dst_state = {};
        dst_state.library = static_cast<OrbisFontLib>(src->library);
        if (fontset_record) {
            dst_state.font_set_type = fontset_record->font_set_type;
            dst_state.system_requested = true;
        }
    }

    if (pFontHandle) {
        *pFontHandle = out_handle;
    }
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontOpenFontMemory(OrbisFontLib library, const void* fontAddress, u32 fontSize,
                                       const OrbisFontOpenParams* open_params,
                                       OrbisFontHandle* pFontHandle) {
    LOG_INFO(Lib_Font, "called");

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("library", library),
                  Param("fontAddress", fontAddress),
                  Param("fontSize", fontSize),
                  Param("open_params", open_params),
                  Param("pFontHandle", pFontHandle),
              }));

    s32 rc = ORBIS_FONT_ERROR_INVALID_LIBRARY;
    if (!library) {
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return rc;
    }

    auto* lib = static_cast<Internal::FontLibOpaque*>(library);
    if (lib->magic != 0x0F01) {
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return rc;
    }

    u32 prev_lib_lock = 0;
    if (!AcquireLibraryLock(lib, prev_lib_lock)) {
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    auto release_library_and_clear_out = [&] {
        ReleaseLibraryLock(lib, prev_lib_lock);
        if (pFontHandle) {
            *pFontHandle = nullptr;
        }
    };

    if (!lib->fontset_registry || !lib->sys_driver) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    const auto alloc_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontAllocFn>(lib->alloc_vtbl[0]) : nullptr;
    const auto free_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontFreeFn>(lib->alloc_vtbl[1]) : nullptr;
    if (!alloc_fn || !free_fn) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    auto* ext_ctx = static_cast<u8*>(lib->external_fonts_ctx);
    if (!ext_ctx) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "NO_SUPPORT_FUNCTION");
        return ORBIS_FONT_ERROR_NO_SUPPORT_FUNCTION;
    }

    const u32 sub_font_index = open_params ? open_params->subfont_index : 0u;
    const s32 unique_id = open_params ? open_params->unique_id : -1;
    if (!fontAddress || fontSize == 0 || unique_id < -1 || !pFontHandle) {
        release_library_and_clear_out();
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    LOG_WARNING(Lib_Font, "font memory requested: addr={} size={} subfont_index={} unique_id={}",
                static_cast<const void*>(fontAddress), fontSize, sub_font_index, unique_id);

    OrbisFontHandle handle = *pFontHandle;
    if (handle) {
        if (auto* h = GetNativeFont(handle)) {
            h->flags = 0;
        }
        Internal::RemoveState(handle);
    } else {
        handle = static_cast<OrbisFontHandle>(alloc_fn(lib->alloc_ctx, 0x100));
        if (!handle) {
            release_library_and_clear_out();
            LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
            return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
        }
        std::memset(handle, 0, 0x100);
        if (auto* h = GetNativeFont(handle)) {
            h->flags = 0x10;
        }
    }

    auto cleanup_handle_for_error = [&](s32 err) {
        auto* h = GetNativeFont(handle);
        if (!h) {
            ReleaseLibraryLock(lib, prev_lib_lock);
            *pFontHandle = nullptr;
            return err;
        }
        h->magic = 0;
        h->open_info.unique_id_packed = 0;
        h->open_info.ctx_entry_index = 0;
        h->open_info.sub_font_index = 0;
        h->open_info.fontset_flags = 0;
        h->open_info.fontset_record = nullptr;
        h->open_info.reserved_0x18 = 0;
        h->library = library;
        const u16 prev_flags = h->flags;
        h->flags = 0;
        if ((prev_flags & 0x10) != 0) {
            free_fn(lib->alloc_ctx, handle);
        }
        Internal::RemoveState(handle);
        ReleaseLibraryLock(lib, prev_lib_lock);
        *pFontHandle = nullptr;
        return err;
    };

    auto* ext_header = reinterpret_cast<Internal::FontCtxHeader*>(ext_ctx);

    auto* ctx_lock_word = &ext_header->lock_word;
    for (;;) {
        const u32 lw = *ctx_lock_word;
        if (static_cast<s32>(lw) >= 0) {
            std::atomic_ref<u32> ref(*ctx_lock_word);
            u32 expected = lw;
            if (ref.compare_exchange_weak(expected, lw | 0x80000000u, std::memory_order_acq_rel)) {
                break;
            }
        }
        Libraries::Kernel::sceKernelUsleep(0x1e);
    }

    const u32 font_max = ext_header->max_entries;
    auto* entries_base = static_cast<Internal::FontCtxEntry*>(ext_header->base);

    u32 entry_index = 0xffffffffu;
    if (font_max != 0 && entries_base) {
        const u32 unique_u32 = static_cast<u32>(unique_id);
        u32 first_free = 0xffffffffu;
        for (u32 i = 0; i < font_max; i++) {
            const auto* entry = &entries_base[i];
            const u32 active = entry->active;
            const u32 stored_id = entry->unique_id;
            const u64 stored_addr = entry->font_address;

            if (((active != 0) && (stored_id == unique_u32)) ||
                stored_addr == reinterpret_cast<u64>(fontAddress)) {
                entry_index = i;
                break;
            }
            if (first_free == 0xffffffffu && active == 0) {
                first_free = i;
            }
        }

        if (entry_index == 0xffffffffu) {
            entry_index = first_free;
            if (entry_index != 0xffffffffu) {
                auto* entry = &entries_base[entry_index];
                const u32 stored_id =
                    (unique_u32 != 0xffffffffu) ? unique_u32 : (entry_index ^ 0x80000000u);
                entry->reserved_0x00 = 0;
                entry->active = 1;
                entry->font_address = reinterpret_cast<u64>(fontAddress);
                entry->unique_id = stored_id;
                entry->lock_mode1 = 0;
                entry->lock_mode3 = 0;
                entry->lock_mode2 = 0;
                entry->obj_mode1 = nullptr;
                entry->obj_mode3 = nullptr;
                entry->obj_mode2 = nullptr;
                std::memset(entry->reserved_0x38, 0, sizeof(entry->reserved_0x38));
            }
        }
    }

    *ctx_lock_word = 0;

    if (entry_index == 0xffffffffu) {
        const s32 err = cleanup_handle_for_error(ORBIS_FONT_ERROR_FONT_OPEN_MAX);
        LogFontOpenError(err);
        return err;
    }

    const u32 uvar15 = (unique_id == -1) ? (entry_index + 0x40000000u)
                                         : (static_cast<u32>(unique_id) | 0x80000000u);

    auto* entry = &entries_base[entry_index];
    auto* entry_lock_word = &entry->lock_mode1;
    u32 entry_prev = 0;
    u32 entry_locked = 0;
    for (;;) {
        entry_prev = *entry_lock_word;
        if (static_cast<s32>(entry_prev) >= 0) {
            std::atomic_ref<u32> ref(*entry_lock_word);
            u32 expected = entry_prev;
            const u32 desired = entry_prev | 0x80000000u;
            if (ref.compare_exchange_weak(expected, desired, std::memory_order_acq_rel)) {
                entry_locked = desired;
                break;
            }
        }
        Libraries::Kernel::sceKernelUsleep(0x1e);
    }

    auto release_entry_lock = [&] {
        if ((entry_locked & 0x0FFFFFFFu) == 0) {
            entry->obj_mode1 = nullptr;
            if (entry->obj_mode3 == nullptr && entry->obj_mode2 == nullptr) {
                entry->unique_id = 0;
                entry->active = 0;
            }
        }
        *entry_lock_word = entry_locked & 0x7fffffffu;
    };

    void* font_obj = entry->obj_mode1;

    const auto* driver =
        lib->sys_driver ? reinterpret_cast<const Internal::SysDriver*>(lib->sys_driver) : nullptr;
    const auto open_fn = driver ? driver->open : nullptr;
    const auto metric_fn = driver ? driver->metric : nullptr;
    const auto scale_fn = driver ? driver->scale : nullptr;
    if (!open_fn || !metric_fn || !scale_fn) {
        release_entry_lock();
        const s32 err = cleanup_handle_for_error(ORBIS_FONT_ERROR_INVALID_LIBRARY);
        LogFontOpenError(err);
        return err;
    }

    rc = ORBIS_OK;
    bool need_open = (entry_prev & 0x40000000u) == 0;

    if (!need_open) {
        rc = ORBIS_FONT_ERROR_FONT_OPEN_MAX;
        if ((entry_prev & 0x0FFFFFFFu) != 0x0FFFFFFFu) {
            for (auto* node = static_cast<Internal::FontObj*>(font_obj); node != nullptr;
                 node = node->next) {
                if (node->sub_font_index == sub_font_index) {
                    node->refcount++;
                    font_obj = node;
                    rc = ORBIS_OK;
                    break;
                }
            }
            if (rc != ORBIS_OK) {
                need_open = true;
            }
        }
    }

    if (need_open) {
        auto* tail = lib + 1;
        auto* tail_reserved1 =
            tail ? reinterpret_cast<Internal::FontLibReserved1SysfontTail*>(tail->reserved1)
                 : nullptr;
        const u32 lib_flags = lib->flags;
        if ((lib_flags & 0x200000u) != 0) {
            tail_reserved1->sysfont_flags |= 1;
        }
        if ((lib_flags & 0x20000u) != 0) {
            tail_reserved1->sysfont_flags |= 2;
        }

        rc = open_fn(library, 1, fontAddress, fontSize, sub_font_index, uvar15, &font_obj);
        if (tail_reserved1) {
            tail_reserved1->sysfont_flags = 0;
        }

        if (rc == ORBIS_OK) {
            entry->obj_mode1 = font_obj;
            entry_locked = entry_prev | 0xC0000000u;
        }
    }

    if (rc == ORBIS_OK) {
        auto* h = GetNativeFont(handle);
        if (!h) {
            release_entry_lock();
            const s32 err = cleanup_handle_for_error(ORBIS_FONT_ERROR_FATAL);
            LogFontOpenError(err);
            return err;
        }
        h->magic = 0x0F02;
        h->flags = static_cast<u16>(h->flags | 1);
        entry_locked = entry_locked + 1;
        h->open_info.unique_id_packed = uvar15;
        h->open_info.ctx_entry_index = entry_index;
        h->open_info.fontset_flags = 0;
        h->open_info.fontset_record = nullptr;
        h->open_info.reserved_0x18 = 0;
        h->open_info.sub_font_index = sub_font_index;
        h->library = library;
        std::memset(&h->cached_style, 0, sizeof(h->cached_style));
        std::memset(h->reserved_0xcc, 0, sizeof(h->reserved_0xcc));
        std::memset(h->reserved_0x30, 0, sizeof(h->reserved_0x30));
        std::memset(h->reserved_0xe8, 0, sizeof(h->reserved_0xe8));
        h->prevFont = nullptr;
        h->nextFont = nullptr;

        u16 metric_buf[2] = {};
        (void)metric_fn(font_obj, 0x0e00, metric_buf);
        h->metricA = metric_buf[0];
        (void)metric_fn(font_obj, 0xea00, metric_buf);
        h->metricB = metric_buf[0];
        h->style_frame[0] = 0x48;
        h->style_frame[1] = 0x48;

        float scale = 0.0f;
        (void)scale_fn(font_obj, metric_buf, &scale);
        h->style_tail.scale_unit = 0;
        h->style_tail.reserved_0x0c = 0;
        h->style_tail.scale_w = scale;
        h->style_tail.scale_h = scale;
        h->style_tail.effect_weight_x = 0.0f;
        h->style_tail.effect_weight_y = 0.0f;
        h->style_tail.slant_ratio = 0.0f;
        h->style_tail.reserved_0x24 = 0.0f;

        *pFontHandle = handle;
    }

    release_entry_lock();

    if (rc != ORBIS_OK) {
        const s32 err = cleanup_handle_for_error(rc);
        LogFontOpenError(err);
        return err;
    }

    const auto* handle_native = GetNativeFont(handle);
    if (handle_native && (handle_native->flags & 0x10) != 0) {
        auto* tail = reinterpret_cast<Internal::FontLibTail*>(lib + 1);
        auto* list_lock = &tail->list_head_ptr;
        void* list_ptr = nullptr;
        for (;;) {
            list_ptr = *list_lock;
            if (list_ptr != reinterpret_cast<void*>(std::numeric_limits<std::uintptr_t>::max())) {
                std::atomic_ref<void*> ref(*list_lock);
                void* expected = list_ptr;
                if (ref.compare_exchange_weak(
                        expected,
                        reinterpret_cast<void*>(std::numeric_limits<std::uintptr_t>::max()),
                        std::memory_order_acq_rel)) {
                    break;
                }
            }
            Libraries::Kernel::sceKernelUsleep(0x1e);
        }

        auto* head_ptr = reinterpret_cast<OrbisFontHandle*>(list_ptr);
        if (head_ptr) {
            const OrbisFontHandle old_head = *head_ptr;
            if (auto* h = GetNativeFont(handle)) {
                h->prevFont = nullptr;
                h->nextFont = old_head;
            }
            if (old_head) {
                if (auto* old_native = GetNativeFont(old_head)) {
                    old_native->prevFont = handle;
                }
            }
            *head_ptr = handle;
        }
        *list_lock = list_ptr;
    }

    ReleaseLibraryLock(lib, prev_lib_lock);

    auto& st = Internal::GetState(handle);
    Internal::DestroyFreeTypeFace(st.ext_ft_face);
    for (auto& fb : st.system_fallback_faces) {
        Internal::DestroyFreeTypeFace(fb.ft_face);
    }
    st = {};
    st.library = library;
    st.font_set_type = 0;
    st.system_font_path.clear();
    {
        const u8* src = static_cast<const u8*>(fontAddress);
        st.ext_face_data.assign(src, src + fontSize);
    }

    const u32 chosen_index = open_params ? open_params->subfont_index : 0u;
    st.ext_ft_face = Internal::CreateFreeTypeFaceFromBytes(st.ext_face_data.data(),
                                                           st.ext_face_data.size(), chosen_index);

    if (st.ext_ft_face) {
        st.ext_cache.clear();
        st.scratch.clear();
        st.logged_ext_use = false;
        st.ext_scale_for_height = 0.0f;
        st.layout_cached = false;
        const Internal::FaceMetrics m = Internal::LoadFaceMetrics(st.ext_ft_face);
        Internal::PopulateStateMetrics(st, m);
        st.ext_face_ready = true;
    } else {
        st.ext_face_ready = false;
    }

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontOpenFontSet(OrbisFontLib library, u32 fontSetType, u32 openMode,
                                    const OrbisFontOpenParams* open_params,
                                    OrbisFontHandle* pFontHandle) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("library", library),
                  Param("fontSetType", fontSetType),
                  Param("openMode", openMode),
                  Param("open_params", open_params),
                  Param("pFontHandle", pFontHandle),
              }));

    {
        auto* lib_local = static_cast<Internal::FontLibOpaque*>(library);
        if (!lib_local || lib_local->magic != 0x0F01) {
            if (pFontHandle) {
                *pFontHandle = nullptr;
            }
            LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
            return ORBIS_FONT_ERROR_INVALID_LIBRARY;
        }
        if (!pFontHandle) {
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
            return ORBIS_FONT_ERROR_INVALID_PARAMETER;
        }

        u32 prev_lib_lock = 0;
        if (!AcquireLibraryLock(lib_local, prev_lib_lock)) {
            *pFontHandle = nullptr;
            LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
            return ORBIS_FONT_ERROR_INVALID_LIBRARY;
        }
        const auto release_library_and_clear_out = [&](s32 err) -> s32 {
            ReleaseLibraryLock(lib_local, prev_lib_lock);
            *pFontHandle = nullptr;
            return err;
        };

        if (openMode != 1 && openMode != 2 && openMode != 3) {
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
            return release_library_and_clear_out(ORBIS_FONT_ERROR_INVALID_PARAMETER);
        }
        const u32 mode_low = openMode & 0x0Fu;
        if (!lib_local->fontset_registry || !lib_local->sys_driver) {
            LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
            return release_library_and_clear_out(ORBIS_FONT_ERROR_INVALID_LIBRARY);
        }

        const auto alloc_fn =
            lib_local->alloc_vtbl
                ? reinterpret_cast<Internal::FontAllocFn>(lib_local->alloc_vtbl[0])
                : nullptr;
        const auto free_fn = lib_local->alloc_vtbl
                                 ? reinterpret_cast<Internal::FontFreeFn>(lib_local->alloc_vtbl[1])
                                 : nullptr;
        if (!alloc_fn || !free_fn) {
            LOG_ERROR(Lib_Font, "INVALID_MEMORY");
            return release_library_and_clear_out(ORBIS_FONT_ERROR_INVALID_MEMORY);
        }

        // System font sets always use sub-font-index 0.
        const u32 sub_font_index = 0u;

        if (!lib_local->sysfonts_ctx) {
            LOG_ERROR(Lib_Font, "NO_SUPPORT_FUNCTION");
            return release_library_and_clear_out(ORBIS_FONT_ERROR_NO_SUPPORT_FUNCTION);
        }

        const auto builtin_selection = Internal::BuildBuiltinSystemFontSelection(fontSetType);
        std::filesystem::path primary_path = Internal::ResolveSystemFontPath(fontSetType);
        bool using_builtin_primary = false;
        if (primary_path.empty()) {
            primary_path = builtin_selection.primary_path;
            using_builtin_primary = !primary_path.empty();
        }
        if (primary_path.empty()) {
            LOG_ERROR(Lib_Font, "NO_SUPPORT_FONTSET");
            return release_library_and_clear_out(ORBIS_FONT_ERROR_NO_SUPPORT_FONTSET);
        }
        LOG_INFO(Lib_Font, "OpenFontSet: stage=resolved_primary_path");

        std::vector<unsigned char> primary_bytes;
        u32 primary_face_index = sub_font_index;
        if (!Internal::LoadFontFileWithSubfont(primary_path, primary_bytes, primary_face_index)) {
            if (!using_builtin_primary && !builtin_selection.primary_path.empty() &&
                Internal::LoadFontFileWithSubfont(builtin_selection.primary_path, primary_bytes,
                                                  primary_face_index)) {
                primary_path = builtin_selection.primary_path;
                using_builtin_primary = true;
            } else {
                LOG_ERROR(Lib_Font, "FONT_OPEN_FAILED path='{}' fontsPath='{}'",
                          primary_path.string(), EmulatorSettings.GetFontsDir().string());
                return release_library_and_clear_out(ORBIS_FONT_ERROR_FONT_OPEN_FAILED);
            }
        }
        if (using_builtin_primary) {
            LOG_WARNING(Lib_Font, "SystemFonts: using bundled Noto fallback for set type=0x{:08X}",
                        fontSetType);
            Internal::NotifyBuiltinFontFallbackOnce();
        }
        LOG_INFO(Lib_Font, "OpenFontSet: stage=loaded_primary_bytes");

        OrbisFontHandle handle = *pFontHandle;
        const bool had_existing_handle = (handle != nullptr);
        if (handle) {
            if (auto* h = GetNativeFont(handle)) {
                h->flags = 0;
            }
            Internal::RemoveState(handle);
        } else {
            handle = static_cast<OrbisFontHandle>(alloc_fn(lib_local->alloc_ctx, 0x100));
            if (!handle) {
                LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
                return release_library_and_clear_out(ORBIS_FONT_ERROR_ALLOCATION_FAILED);
            }
            std::memset(handle, 0, 0x100);
            if (auto* h = GetNativeFont(handle)) {
                h->flags = 0x10;
            }
        }
        LOG_INFO(Lib_Font, "OpenFontSet: stage=handle_ready");

        auto cleanup_handle_for_error = [&](s32 rc) -> s32 {
            auto* h = GetNativeFont(handle);
            if (!h) {
                return release_library_and_clear_out(rc);
            }
            const u16 prev_flags = h->flags;
            h->magic = 0;
            h->open_info.unique_id_packed = 0;
            h->open_info.ctx_entry_index = 0;
            h->open_info.sub_font_index = 0;
            h->open_info.fontset_flags = 0;
            h->open_info.fontset_record = nullptr;
            h->open_info.reserved_0x18 = 0;
            h->library = library;
            h->flags = 0;
            if ((prev_flags & 0x10) != 0) {
                free_fn(lib_local->alloc_ctx, handle);
            }
            Internal::RemoveState(handle);
            return release_library_and_clear_out(rc);
        };

        auto* h = GetNativeFont(handle);
        if (!h) {
            return cleanup_handle_for_error(ORBIS_FONT_ERROR_FATAL);
        }

        h->magic = 0;
        h->flags = static_cast<u16>(h->flags & 0x10);
        h->open_info.unique_id_packed = 0;
        h->open_info.ctx_entry_index = 0;
        h->open_info.fontset_flags = 0;
        h->open_info.fontset_record = nullptr;
        h->open_info.reserved_0x18 = 0;
        h->open_info.sub_font_index = sub_font_index;
        h->library = library;
        std::memset(&h->cached_style, 0, sizeof(h->cached_style));
        std::memset(h->reserved_0xcc, 0, sizeof(h->reserved_0xcc));
        std::memset(h->reserved_0x30, 0, sizeof(h->reserved_0x30));
        std::memset(h->reserved_0xe8, 0, sizeof(h->reserved_0xe8));
        h->prevFont = nullptr;
        h->nextFont = nullptr;
        h->style_frame[0] = 0x48;
        h->style_frame[1] = 0x48;
        h->style_tail.scale_unit = 0;
        h->style_tail.reserved_0x0c = 0;
        {
            const auto* driver =
                reinterpret_cast<const Internal::SysDriver*>(lib_local->sys_driver);
            const auto pixel_res_fn = driver ? driver->pixel_resolution : nullptr;
            const u32 pixel_res = pixel_res_fn ? pixel_res_fn() : 0;
            const float scale = (pixel_res != 0) ? (1000.0f / static_cast<float>(pixel_res)) : 0.0f;
            h->style_tail.scale_w = scale;
            h->style_tail.scale_h = scale;
        }
        h->style_tail.effect_weight_x = 0.0f;
        h->style_tail.effect_weight_y = 0.0f;
        h->style_tail.slant_ratio = 0.0f;
        h->style_tail.reserved_0x24 = 0.0f;

        auto& st = Internal::GetState(handle);
        Internal::DestroyFreeTypeFace(st.ext_ft_face);
        for (auto& fb : st.system_fallback_faces) {
            Internal::DestroyFreeTypeFace(fb.ft_face);
        }
        st = {};
        st.library = library;
        st.font_set_type = fontSetType;
        st.system_font_path = primary_path;
        st.system_requested = true;
        st.system_font_id = 0;
        st.system_font_scale_factor = 1.0f;
        st.system_font_shift_value = 0;
        st.ext_face_data = std::move(primary_bytes);
        st.ext_ft_face = Internal::CreateFreeTypeFaceFromBytes(
            st.ext_face_data.data(), st.ext_face_data.size(), primary_face_index);
        if (!st.ext_ft_face) {
            LOG_ERROR(Lib_Font, "FONT_OPEN_FAILED");
            return cleanup_handle_for_error(ORBIS_FONT_ERROR_FONT_OPEN_FAILED);
        }
        LOG_INFO(Lib_Font, "OpenFontSet: stage=created_primary_face");
        const Internal::FaceMetrics m = Internal::LoadFaceMetrics(st.ext_ft_face);
        Internal::PopulateStateMetrics(st, m);
        st.ext_face_ready = true;

        {
            const u16 units = static_cast<u16>(st.ext_ft_face->units_per_EM);
            h->metricA = units;
            u16 ascender = units;
            if (const TT_OS2* os2 =
                    static_cast<const TT_OS2*>(FT_Get_Sfnt_Table(st.ext_ft_face, ft_sfnt_os2))) {
                ascender = static_cast<u16>(os2->sTypoAscender);
            }
            h->metricB = ascender;

            const auto* driver =
                reinterpret_cast<const Internal::SysDriver*>(lib_local->sys_driver);
            const auto pixel_res_fn = driver ? driver->pixel_resolution : nullptr;
            const u32 pixel_res = pixel_res_fn ? pixel_res_fn() : 0;
            const float scale = (pixel_res != 0)
                                    ? (static_cast<float>(units) / static_cast<float>(pixel_res))
                                    : 0.0f;
            h->style_tail.scale_w = scale;
            h->style_tail.scale_h = scale;
        }

        st.system_font_scale_factor =
            Internal::ComputeSysfontScaleFactor(st.ext_ft_face, st.ext_units_per_em);
        st.system_font_shift_value = Internal::ComputeSysfontShiftValue(st.ext_ft_face);
        LOG_DEBUG(Lib_Font, "SystemFonts: primary='{}' unitsPerEm={} scaleFactor={} shiftValue={}",
                  primary_path.filename().string(), st.ext_units_per_em,
                  st.system_font_scale_factor, st.system_font_shift_value);

        std::string preferred_latin_name_lower;
        const auto base_dir = Internal::GetSysFontBaseDir();
        if (!base_dir.empty()) {
            auto resolve_existing =
                [&](std::string_view filename) -> std::optional<std::filesystem::path> {
                const std::filesystem::path file_path{std::string(filename)};
                std::error_code ec;
                {
                    const auto candidate = base_dir / file_path;
                    if (std::filesystem::exists(candidate, ec)) {
                        return candidate;
                    }
                }
                {
                    const auto candidate = base_dir / "font" / file_path;
                    if (std::filesystem::exists(candidate, ec)) {
                        return candidate;
                    }
                }
                {
                    const auto candidate = base_dir / "font2" / file_path;
                    if (std::filesystem::exists(candidate, ec)) {
                        return candidate;
                    }
                }
                return std::nullopt;
            };

            auto resolve_sysfont_path = [&](const std::filesystem::path& candidate)
                -> std::optional<std::filesystem::path> {
                if (candidate.empty()) {
                    return std::nullopt;
                }
                std::error_code ec;
                if (std::filesystem::exists(candidate, ec)) {
                    return candidate;
                }

                const auto filename = candidate.filename().string();
                if (filename.empty()) {
                    return std::nullopt;
                }

                if (auto direct = resolve_existing(filename)) {
                    return direct;
                }
                if (auto alias = ResolveKnownSysFontAlias(base_dir, filename)) {
                    return alias;
                }
                return std::nullopt;
            };

            const std::string primary_name_lower = LowerAscii(primary_path.filename().string());

            auto has_fallback_name_lower = [&](const std::string& candidate_lower) -> bool {
                if (candidate_lower.empty() || candidate_lower == primary_name_lower) {
                    return true;
                }
                for (const auto& fb : st.system_fallback_faces) {
                    if (LowerAscii(fb.path.filename().string()) == candidate_lower) {
                        return true;
                    }
                }
                return false;
            };

            auto add_fallback_face = [&](const std::filesystem::path& p) {
                (void)Internal::AddSystemFallbackFace(st, p, sub_font_index);
            };

            {
                const u32 tag = (fontSetType >> 8) & 0xFFu;
                const u32 variant = (fontSetType >> 20) & 0x0Fu;
                u32 style_suffix = fontSetType & 0xFFu;

                switch (style_suffix) {
                case 0xC3:
                    style_suffix = 0x43;
                    break;
                case 0xC4:
                    style_suffix = 0x44;
                    break;
                case 0xC5:
                    style_suffix = 0x45;
                    break;
                case 0xC7:
                    style_suffix = 0x47;
                    break;
                default:
                    break;
                }

                const char* latin_file = nullptr;
                if (tag != 0x00u && tag != 0x10u) {
                    if (variant == 0x3u) {
                        switch (style_suffix) {
                        case 0x44:
                            latin_file = "SSTTypewriter-Roman.otf";
                            break;
                        case 0x47:
                            latin_file = "SSTTypewriter-Bd.otf";
                            break;
                        default:
                            break;
                        }
                    } else if (variant == 0x1u) {
                        switch (style_suffix) {
                        case 0x43:
                            latin_file = "SST-LightItalic.otf";
                            break;
                        case 0x44:
                            latin_file = "SST-Italic.otf";
                            break;
                        case 0x45:
                            latin_file = "SST-MediumItalic.otf";
                            break;
                        case 0x47:
                            latin_file = "SST-BoldItalic.otf";
                            break;
                        default:
                            break;
                        }
                    } else {
                        switch (style_suffix) {
                        case 0x43:
                            latin_file = "SST-Light.otf";
                            break;
                        case 0x44:
                            latin_file = "SST-Roman.otf";
                            break;
                        case 0x45:
                            latin_file = "SST-Medium.otf";
                            break;
                        case 0x47:
                            latin_file = "SST-Bold.otf";
                            break;
                        default:
                            break;
                        }
                    }
                }

                if (latin_file) {
                    if (auto latin_path = resolve_sysfont_path(base_dir / latin_file)) {
                        preferred_latin_name_lower = LowerAscii(latin_path->filename().string());
                        if (!has_fallback_name_lower(preferred_latin_name_lower)) {
                            add_fallback_face(*latin_path);
                        }
                    }
                }
            }

            {
                const u32 style_suffix = fontSetType & 0xFFu;
                const char* arabic_file = nullptr;
                switch (style_suffix) {
                case 0xC3:
                    arabic_file = "SSTArabic-Light.otf";
                    break;
                case 0xC4:
                    arabic_file = "SSTArabic-Roman.otf";
                    break;
                case 0xC5:
                    arabic_file = "SSTArabic-Medium.otf";
                    break;
                case 0xC7:
                    arabic_file = "SSTArabic-Bold.otf";
                    break;
                case 0xD3:
                    arabic_file = "SSTArabic-Light.otf";
                    break;
                case 0xD4:
                    arabic_file = "SSTArabic-Roman.otf";
                    break;
                case 0xD5:
                    arabic_file = "SSTArabic-Medium.otf";
                    break;
                case 0xD7:
                    arabic_file = "SSTArabic-Bold.otf";
                    break;
                default:
                    break;
                }
                if (arabic_file) {
                    if (auto arabic_path = resolve_sysfont_path(base_dir / arabic_file)) {
                        const std::string arabic_lower =
                            LowerAscii(arabic_path->filename().string());
                        if (!has_fallback_name_lower(arabic_lower)) {
                            add_fallback_face(*arabic_path);
                        }
                    }
                }
            }

            {
                const u32 tag = (fontSetType >> 8) & 0xFFu;
                const u32 style_suffix = fontSetType & 0xFFu;

                auto add_named_fallback = [&](std::string_view filename) {
                    if (filename.empty()) {
                        return;
                    }
                    if (auto p = resolve_sysfont_path(base_dir / std::filesystem::path{filename})) {
                        const std::string lower = LowerAscii(p->filename().string());
                        if (!has_fallback_name_lower(lower)) {
                            add_fallback_face(*p);
                        }
                    }
                };

                const bool is_bold_like = (style_suffix == 0x47u) || (style_suffix == 0x57u) ||
                                          (style_suffix == 0xC7u) || (style_suffix == 0xD7u);

                const bool needs_jppro = (tag == 0x04u) || (tag == 0x24u) || (tag == 0x34u) ||
                                         (tag == 0x84u) || (tag == 0xA4u) || (tag == 0xACu) ||
                                         (tag == 0xB4u) || (tag == 0xBCu);
                const bool needs_cngb = (tag == 0x80u) || (tag == 0x84u) || (tag == 0x90u) ||
                                        (tag == 0xA0u) || (tag == 0xA4u) || (tag == 0xACu) ||
                                        (tag == 0xB0u) || (tag == 0xB4u) || (tag == 0xBCu);
                const bool needs_hangul = (tag == 0x24u) || (tag == 0x34u) || (tag == 0xA0u) ||
                                          (tag == 0xA4u) || (tag == 0xACu) || (tag == 0xB0u) ||
                                          (tag == 0xB4u) || (tag == 0xBCu);

                u32 sea_weight_code = style_suffix;
                switch (sea_weight_code) {
                case 0xD3u:
                    sea_weight_code = 0x53u;
                    break;
                case 0xD4u:
                    sea_weight_code = 0x54u;
                    break;
                case 0xD5u:
                    sea_weight_code = 0x55u;
                    break;
                case 0xD7u:
                    sea_weight_code = 0x57u;
                    break;
                default:
                    break;
                }
                const bool is_sea_weight = (sea_weight_code == 0x53u) ||
                                           (sea_weight_code == 0x54u) ||
                                           (sea_weight_code == 0x55u) || (sea_weight_code == 0x57u);

                if (is_sea_weight && primary_name_lower.rfind("sstvietnamese-", 0) != 0) {
                    const char* vn_file = nullptr;
                    switch (sea_weight_code) {
                    case 0x53:
                        vn_file = "SSTVietnamese-Light.otf";
                        break;
                    case 0x54:
                        vn_file = "SSTVietnamese-Roman.otf";
                        break;
                    case 0x55:
                        vn_file = "SSTVietnamese-Medium.otf";
                        break;
                    case 0x57:
                        vn_file = "SSTVietnamese-Bold.otf";
                        break;
                    default:
                        break;
                    }
                    if (vn_file) {
                        add_named_fallback(vn_file);
                    }
                }

                if (is_sea_weight &&
                    ((tag == 0x10u) || (tag == 0x14u) || (tag == 0x34u) || (tag == 0x90u) ||
                     (tag == 0x94u) || (tag == 0xB0u) || (tag == 0xB4u) || (tag == 0xBCu))) {
                    const char* th_file = nullptr;
                    switch (sea_weight_code) {
                    case 0x53:
                        th_file = "SSTThai-Light.otf";
                        break;
                    case 0x54:
                        th_file = "SSTThai-Roman.otf";
                        break;
                    case 0x55:
                        th_file = "SSTThai-Medium.otf";
                        break;
                    case 0x57:
                        th_file = "SSTThai-Bold.otf";
                        break;
                    default:
                        break;
                    }
                    if (th_file) {
                        add_named_fallback(th_file);
                    }
                }

                if (needs_jppro && primary_name_lower.rfind("sstjppro-", 0) != 0) {
                    add_named_fallback(is_bold_like ? "SSTJpPro-Bold.otf" : "SSTJpPro-Regular.otf");
                }
                if (needs_cngb && primary_name_lower != "dfhei5-sony.ttf") {
                    add_named_fallback("DFHEI5-SONY.ttf");
                }
                if (needs_hangul && primary_name_lower.rfind("sceps4yoongd-", 0) != 0) {
                    add_named_fallback(is_bold_like ? "SCEPS4Yoongd-Bold.otf"
                                                    : "SCEPS4Yoongd-Medium.otf");
                }
            }
        }

        if (using_builtin_primary || Internal::IsBuiltinFontPath(primary_path)) {
            preferred_latin_name_lower = builtin_selection.preferred_latin_name_lower;
            Internal::AddBuiltinFallbackFaces(st, fontSetType, sub_font_index,
                                              &preferred_latin_name_lower);
        }

        {
            const auto* driver =
                lib_local->sys_driver
                    ? reinterpret_cast<const Internal::SysDriver*>(lib_local->sys_driver)
                    : nullptr;
            const auto open_fn = driver ? driver->open : nullptr;
            if (!open_fn) {
                return cleanup_handle_for_error(ORBIS_FONT_ERROR_INVALID_LIBRARY);
            }

            LOG_INFO(Lib_Font, "OpenFontSet: stage=open_sysfonts_begin");
            auto open_sysfonts_entry =
                [&](const std::filesystem::path& requested_path) -> std::optional<u32> {
                const std::filesystem::path served_path = ResolveServedPath(requested_path);
                if (served_path.empty()) {
                    return std::nullopt;
                }
                const std::string host_path_str = served_path.string();
                if (host_path_str.empty()) {
                    return std::nullopt;
                }
                u32 open_arg4 = 0;
                {
                    std::error_code ec;
                    const auto sz = std::filesystem::file_size(served_path, ec);
                    if (!ec && sz <= static_cast<std::uintmax_t>(std::numeric_limits<u32>::max())) {
                        open_arg4 = static_cast<u32>(sz);
                    }
                }
                LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_entry_begin");
                const s32 unique_id = StableUniqueIdFor(host_path_str);

                auto* sys_ctx = static_cast<u8*>(lib_local->sysfonts_ctx);
                auto* sys_header =
                    sys_ctx ? reinterpret_cast<Internal::FontCtxHeader*>(sys_ctx) : nullptr;
                auto* entries_base =
                    sys_header ? static_cast<Internal::FontCtxEntry*>(sys_header->base) : nullptr;
                const u32 max_entries = sys_header ? sys_header->max_entries : 0u;
                if (!sys_header || !entries_base || max_entries == 0) {
                    return std::nullopt;
                }

                u32* ctx_lock_word = &sys_header->lock_word;
                for (;;) {
                    const u32 lw = *ctx_lock_word;
                    if (static_cast<s32>(lw) >= 0) {
                        std::atomic_ref<u32> ref(*ctx_lock_word);
                        u32 expected = lw;
                        if (ref.compare_exchange_weak(expected, lw | 0x80000000u,
                                                      std::memory_order_acq_rel)) {
                            break;
                        }
                    }
                    Libraries::Kernel::sceKernelUsleep(0x1e);
                }

                u32 entry_index = 0xffffffffu;
                u32 first_free = 0xffffffffu;
                for (u32 i = 0; i < max_entries; i++) {
                    auto* entry = &entries_base[i];
                    const u32 active = entry->active;
                    const u32 stored_id = entry->unique_id;
                    if (active != 0 && stored_id == static_cast<u32>(unique_id)) {
                        entry_index = i;
                        break;
                    }
                    if (first_free == 0xffffffffu && active == 0) {
                        first_free = i;
                    }
                }

                if (entry_index == 0xffffffffu) {
                    entry_index = first_free;
                    if (entry_index == 0xffffffffu) {
                        *ctx_lock_word = 0;
                        return std::nullopt;
                    }

                    auto* entry = &entries_base[entry_index];
                    entry->reserved_0x00 = 0;
                    entry->active = 1;
                    entry->font_address = 0;
                    entry->unique_id = static_cast<u32>(unique_id);
                    entry->lock_mode1 = 0;
                    entry->lock_mode3 = 0;
                    entry->lock_mode2 = 0;
                    entry->obj_mode1 = nullptr;
                    entry->obj_mode3 = nullptr;
                    entry->obj_mode2 = nullptr;
                    std::memset(entry->reserved_0x38, 0, sizeof(entry->reserved_0x38));
                }

                *ctx_lock_word = 0;

                LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_entry_lock_begin");
                void* font_obj = nullptr;
                u32 entry_lock_word = 0;
                u8* entry_u8 = Internal::AcquireFontCtxEntry(sys_ctx, entry_index, mode_low,
                                                             &font_obj, &entry_lock_word);
                auto* entry =
                    entry_u8 ? reinterpret_cast<Internal::FontCtxEntry*>(entry_u8) : nullptr;
                if (!entry) {
                    return std::nullopt;
                }
                LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_entry_lock_ok");

                void* used_font_obj = font_obj;
                u32 updated_lock = entry_lock_word;
                s32 rc = ORBIS_FONT_ERROR_FONT_OPEN_MAX;

                if ((entry_lock_word & 0x40000000u) == 0) {
                    used_font_obj = font_obj;
                    auto* tail = lib_local + 1;
                    auto* tail_reserved1 =
                        tail ? reinterpret_cast<Internal::FontLibReserved1SysfontTail*>(
                                   tail->reserved1)
                             : nullptr;
                    if (tail_reserved1) {
                        const u32 lib_flags = lib_local->flags;
                        if (mode_low == 2) {
                            if ((lib_flags & 0x100000u) != 0) {
                                tail_reserved1->sysfont_flags |= 1;
                            }
                            if ((lib_flags & 0x10000u) != 0) {
                                tail_reserved1->sysfont_flags |= 2;
                            }
                        } else {
                            if ((lib_flags & 0x200000u) != 0) {
                                tail_reserved1->sysfont_flags |= 1;
                            }
                            if ((lib_flags & 0x20000u) != 0) {
                                tail_reserved1->sysfont_flags |= 2;
                            }
                        }
                    }
                    LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_driver_open_call");
                    rc = open_fn(library, OpenDriverModeFor(mode_low), host_path_str.c_str(),
                                 open_arg4, sub_font_index, entry_index, &used_font_obj);
                    if (tail_reserved1) {
                        tail_reserved1->sysfont_flags = 0;
                    }
                    if (rc == ORBIS_OK) {
                        LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_driver_open_ok");
                        if (mode_low == 3) {
                            entry->obj_mode3 = used_font_obj;
                        } else if (mode_low == 2) {
                            entry->obj_mode2 = used_font_obj;
                        } else {
                            entry->obj_mode1 = used_font_obj;
                        }
                        updated_lock = entry_lock_word | 0x40000000u;
                    }
                } else {
                    rc = ORBIS_FONT_ERROR_FONT_OPEN_MAX;
                    if ((entry_lock_word & 0x0FFFFFFFu) != 0x0FFFFFFFu) {
                        for (auto* node = static_cast<Internal::FontObj*>(font_obj);
                             node != nullptr; node = node->next) {
                            if (node->sub_font_index == sub_font_index) {
                                node->refcount++;
                                used_font_obj = node;
                                rc = ORBIS_OK;
                                break;
                            }
                        }
                        if (rc != ORBIS_OK) {
                            used_font_obj = font_obj;
                            auto* tail = lib_local + 1;
                            auto* tail_reserved1 =
                                tail ? reinterpret_cast<Internal::FontLibReserved1SysfontTail*>(
                                           tail->reserved1)
                                     : nullptr;
                            if (tail_reserved1) {
                                const u32 lib_flags = lib_local->flags;
                                if (mode_low == 2) {
                                    if ((lib_flags & 0x100000u) != 0) {
                                        tail_reserved1->sysfont_flags |= 1;
                                    }
                                    if ((lib_flags & 0x10000u) != 0) {
                                        tail_reserved1->sysfont_flags |= 2;
                                    }
                                } else {
                                    if ((lib_flags & 0x200000u) != 0) {
                                        tail_reserved1->sysfont_flags |= 1;
                                    }
                                    if ((lib_flags & 0x20000u) != 0) {
                                        tail_reserved1->sysfont_flags |= 2;
                                    }
                                }
                            }
                            rc =
                                open_fn(library, OpenDriverModeFor(mode_low), host_path_str.c_str(),
                                        open_arg4, sub_font_index, entry_index, &used_font_obj);
                            if (tail_reserved1) {
                                tail_reserved1->sysfont_flags = 0;
                            }
                            if (rc == ORBIS_OK) {
                                if (mode_low == 3) {
                                    entry->obj_mode3 = used_font_obj;
                                } else if (mode_low == 2) {
                                    entry->obj_mode2 = used_font_obj;
                                } else {
                                    entry->obj_mode1 = used_font_obj;
                                }
                            }
                        }
                    }
                }

                if (rc == ORBIS_OK) {
                    updated_lock = updated_lock + 1;
                }

                const u32 count = updated_lock & 0x0FFFFFFFu;
                if (mode_low == 3) {
                    if (count == 0) {
                        entry->obj_mode3 = nullptr;
                    }
                    entry->lock_mode3 = updated_lock & 0x7fffffffu;
                } else if (mode_low == 1) {
                    if (count == 0) {
                        entry->obj_mode1 = nullptr;
                    }
                    entry->lock_mode1 = updated_lock & 0x7fffffffu;
                } else {
                    if (count == 0) {
                        entry->obj_mode2 = nullptr;
                    }
                    entry->lock_mode2 = updated_lock & 0x7fffffffu;
                }

                if (count == 0 && entry->obj_mode1 == nullptr && entry->obj_mode3 == nullptr &&
                    entry->obj_mode2 == nullptr) {
                    entry->unique_id = 0;
                    entry->active = 0;
                }

                if (rc != ORBIS_OK) {
                    return std::nullopt;
                }
                LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_entry_done");
                return entry_index;
            };

            std::vector<u32> font_ids;
            font_ids.reserve(1 + st.system_fallback_faces.size());

            const auto primary_entry = open_sysfonts_entry(primary_path);
            if (!primary_entry) {
                return cleanup_handle_for_error(ORBIS_FONT_ERROR_FONT_OPEN_FAILED);
            }
            st.system_font_id = *primary_entry;
            font_ids.push_back(st.system_font_id);
            LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_primary_opened");
            u32 opened_fallbacks = 0;
            for (auto& fb : st.system_fallback_faces) {
                if (!fb.ready || !fb.ft_face) {
                    continue;
                }
                const auto fb_entry = open_sysfonts_entry(fb.path);
                if (!fb_entry) {
                    continue;
                }
                fb.font_id = *fb_entry;
                font_ids.push_back(fb.font_id);
                LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_fallback_opened");
                ++opened_fallbacks;
            }
            LOG_INFO(Lib_Font, "OpenFontSet: stage=sysfonts_fallbacks_opened");

            LOG_INFO(Lib_Font, "OpenFontSet: stage=before_make_shared_selector");
            st.fontset_selector = std::make_shared<Internal::FontSetSelector>();
            LOG_INFO(Lib_Font, "OpenFontSet: stage=after_make_shared_selector");
            st.fontset_selector->magic = Internal::FontSetSelector::kMagic;
            st.fontset_selector->font_set_type = fontSetType;
            st.fontset_selector->library = lib_local;
            st.fontset_selector->mode_low = mode_low;
            st.fontset_selector->sub_font_index = sub_font_index;
            st.fontset_selector->primary_font_id = st.system_font_id;
            const auto select_preferred_latin_id = [&](const std::string& name_lower) -> bool {
                if (name_lower.empty()) {
                    return false;
                }
                for (const auto& fb : st.system_fallback_faces) {
                    const auto candidate = LowerAscii(fb.path.filename().string());
                    if (candidate == name_lower && fb.font_id != 0xffffffffu) {
                        st.fontset_selector->roman_font_id = fb.font_id;
                        return true;
                    }
                }
                return false;
            };
            if (!select_preferred_latin_id(preferred_latin_name_lower)) {
                (void)select_preferred_latin_id("sst-roman.otf");
            }
            for (const auto& fb : st.system_fallback_faces) {
                const auto name = LowerAscii(fb.path.filename().string());
                if ((name.rfind("sstarabic-", 0) == 0 || name.rfind("notosansarabic-", 0) == 0) &&
                    fb.font_id != 0xffffffffu) {
                    st.fontset_selector->arabic_font_id = fb.font_id;
                    break;
                }
            }
            for (const auto& fb : st.system_fallback_faces) {
                const auto name = LowerAscii(fb.path.filename().string());
                if ((name.rfind("sstthai-", 0) == 0 || name.rfind("notosansthai-", 0) == 0) &&
                    fb.font_id != 0xffffffffu) {
                    st.fontset_selector->thai_font_id = fb.font_id;
                    break;
                }
            }
            for (const auto& fb : st.system_fallback_faces) {
                const auto name = LowerAscii(fb.path.filename().string());
                if ((name.rfind("notosanssymbols2-", 0) == 0 || name.rfind("symbols2-", 0) == 0) &&
                    fb.font_id != 0xffffffffu) {
                    st.fontset_selector->symbol_font_id = fb.font_id;
                    break;
                }
            }
            st.fontset_selector->candidates.clear();
            st.fontset_selector->candidates.reserve(font_ids.size());
            for (u32 id : font_ids) {
                st.fontset_selector->candidates.push_back({id, nullptr});
            }

            const u32 entry_count = static_cast<u32>(font_ids.size());
            const std::size_t indices_bytes = static_cast<std::size_t>(entry_count) * sizeof(u32);
            const std::size_t ptr_off_unaligned =
                sizeof(Internal::FontSetRecordHeader) + indices_bytes;
            const std::size_t ptr_align = alignof(const Internal::FontSetSelector*);
            const std::size_t ptr_off = (ptr_off_unaligned + (ptr_align - 1u)) & ~(ptr_align - 1u);
            const std::size_t rec_size = ptr_off + sizeof(const Internal::FontSetSelector*);

            LOG_INFO(Lib_Font, "OpenFontSet: stage=before_make_shared_record");
            st.fontset_record_storage = std::make_shared<std::vector<u8>>(rec_size);
            LOG_INFO(Lib_Font, "OpenFontSet: stage=after_make_shared_record");
            std::memset(st.fontset_record_storage->data(), 0, st.fontset_record_storage->size());

            auto* header = std::construct_at(reinterpret_cast<Internal::FontSetRecordHeader*>(
                st.fontset_record_storage->data()));
            header->font_set_type = fontSetType;
            header->magic = Internal::FontSetSelector::kMagic;
            header->entry_count = entry_count;

            auto* entries = reinterpret_cast<u32*>(st.fontset_record_storage->data() +
                                                   sizeof(Internal::FontSetRecordHeader));
            for (u32 i = 0; i < entry_count; ++i) {
                std::construct_at(entries + i, font_ids[i]);
            }

            std::construct_at(reinterpret_cast<const Internal::FontSetSelector**>(
                                  st.fontset_record_storage->data() + ptr_off),
                              st.fontset_selector.get());

            h->open_info.fontset_record = header;
        }

        h->magic = 0x0F02;
        h->flags = static_cast<u16>(h->flags | static_cast<u16>(mode_low));
        if (!had_existing_handle) {
            *pFontHandle = handle;
        }
        LOG_INFO(Lib_Font, "OpenFontSet: stage=published_handle");
        if ((h->flags & 0x10) != 0) {
            auto* tail = reinterpret_cast<Internal::FontLibTail*>(lib_local + 1);
            auto* list_lock = &tail->list_head_ptr;
            void* list_ptr = nullptr;
            for (;;) {
                list_ptr = *list_lock;
                if (list_ptr !=
                    reinterpret_cast<void*>(std::numeric_limits<std::uintptr_t>::max())) {
                    std::atomic_ref<void*> ref(*list_lock);
                    void* expected = list_ptr;
                    if (ref.compare_exchange_weak(
                            expected,
                            reinterpret_cast<void*>(std::numeric_limits<std::uintptr_t>::max()),
                            std::memory_order_acq_rel)) {
                        break;
                    }
                }
                Libraries::Kernel::sceKernelUsleep(0x1e);
            }

            auto* head_ptr = reinterpret_cast<OrbisFontHandle*>(list_ptr);
            if (head_ptr) {
                const OrbisFontHandle old_head = *head_ptr;
                if (auto* hn = GetNativeFont(handle)) {
                    hn->prevFont = nullptr;
                    hn->nextFont = old_head;
                }
                if (old_head) {
                    if (auto* old_native = GetNativeFont(old_head)) {
                        old_native->prevFont = handle;
                    }
                }
                *head_ptr = handle;
            }
            *list_lock = list_ptr;
        }

        ReleaseLibraryLock(lib_local, prev_lib_lock);
        LOG_INFO(Lib_Font, "OpenFontSet: stage=done");
        return ORBIS_OK;
    }
}

s32 PS4_SYSV_ABI sceFontRebindRenderer(OrbisFontHandle fontHandle) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        LOG_ERROR(Lib_Font, "NULL_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    LOG_DEBUG(Lib_Font, "{}", formatParams({Param("fontHandle", fontHandle)}));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_font_lock = 0;
    if (!AcquireFontLock(font, prev_font_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_cached_lock = 0;
    if (!AcquireCachedStyleLock(font, prev_cached_lock)) {
        ReleaseFontLock(font, prev_font_lock);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    s32 rc = ORBIS_FONT_ERROR_FATAL;
    void* renderer = font->renderer_binding.renderer;
    if (!renderer) {
        rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
    } else if (*reinterpret_cast<const u16*>(renderer) != 0x0F07) {
        rc = ORBIS_FONT_ERROR_FATAL;
    } else {
        std::memcpy(&font->cached_style.effectWeightY, &font->style_tail.slant_ratio, sizeof(u64));

        std::memcpy(&font->cached_style, &font->style_frame[0], sizeof(u32));

        const u32 dpi_y = font->style_frame[1];
        const u32 scale_unit = font->style_tail.scale_unit;
        const u32 reserved_0x0c = font->style_tail.reserved_0x0c;
        const float scale_w = font->style_tail.scale_w;
        const float scale_h = font->style_tail.scale_h;
        const float effect_weight_x = font->style_tail.effect_weight_x;
        const float effect_weight_y = font->style_tail.effect_weight_y;

        font->cached_style.hDpi = dpi_y;
        font->cached_style.vDpi = scale_unit;
        font->cached_style.scaleUnit = reserved_0x0c;
        font->cached_style.baseScale = scale_w;
        font->cached_style.scalePixelW = scale_h;
        font->cached_style.scalePixelH = effect_weight_x;
        font->cached_style.effectWeightX = effect_weight_y;
        rc = ORBIS_OK;
    }

    ReleaseCachedStyleLock(font, prev_cached_lock);
    ReleaseFontLock(font, prev_font_lock);

    if (rc != ORBIS_OK) {
        if (rc == ORBIS_FONT_ERROR_NOT_BOUND_RENDERER) {
            LOG_ERROR(Lib_Font, "NOT_BOUND_RENDERER");
        } else {
            LOG_ERROR(Lib_Font, "FAILED");
        }
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontRenderCharGlyphImage(OrbisFontHandle fontHandle, u32 code,
                                             OrbisFontRenderSurface* surf, float x, float y,
                                             OrbisFontGlyphMetrics* metrics,
                                             OrbisFontRenderOutput* result) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("code", code),
                  Param("surf", surf),
                  Param("x", x),
                  Param("y", y),
                  Param("metrics", metrics),
                  Param("result", result),
              }));

    u32 prev_lock_word = 0;
    if (!AcquireFontLock(font, prev_lock_word)) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    s32 rc = ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    if (static_cast<s16>(font->flags) >= 0) {
        s32 pre_rc = ORBIS_OK;
        float baseline_add = 0.0f;

        auto cache_cachedstyle_baseline = [&]() -> s32 {
            const u8 cached_flags = CachedStyleCacheFlags(font->cached_style);
            if ((cached_flags & 0x1) == 0) {
                pre_rc = Internal::ComputeHorizontalLayoutBlocksToBytes(
                    fontHandle, &font->cached_style, font->cached_style.layout_cache_bytes);
                if (pre_rc == ORBIS_OK) {
                    CachedStyleSetCacheFlags(font->cached_style,
                                             static_cast<u8>(cached_flags | 0x1));
                    pre_rc = ORBIS_OK;
                }
            }
            if (pre_rc == ORBIS_OK) {
                const auto layout_words =
                    Internal::HorizontalLayoutBlocksIo{
                        Internal::LayoutWordsBytes(font->cached_style.layout_cache_bytes)}
                        .fields();
                baseline_add = layout_words.baseline.value();
            }
            return pre_rc;
        };

        if (!surf || (surf->styleFlag & 0x1) == 0) {
            (void)cache_cachedstyle_baseline();
        } else {
            auto* sys = reinterpret_cast<Internal::RenderSurfaceSystemUse*>(surf->reserved_q);
            auto* styleframe = sys ? sys->styleframe : nullptr;

            if (!styleframe || (styleframe->flags1 & 1) == 0) {
                (void)cache_cachedstyle_baseline();
            } else {
                Internal::StyleStateBlock state{};
                state.dpi_x = styleframe->hDpi;
                state.dpi_y = styleframe->vDpi;
                state.scale_unit = 0;
                state.reserved_0x0c = 0;
                state.effect_weight_x = 0.0f;
                state.effect_weight_y = 0.0f;
                state.slant_ratio = 0.0f;
                if ((styleframe->flags1 & 2) != 0) {
                    state.slant_ratio = styleframe->slantRatio;
                }
                if ((styleframe->flags1 & 4) != 0) {
                    state.effect_weight_x = styleframe->effectWeightX;
                    state.effect_weight_y = styleframe->effectWeightY;
                }

                pre_rc = Internal::StyleStateGetScalePixel(&styleframe->hDpi, &state.scale_w,
                                                           &state.scale_h);
                Internal::HorizontalLayoutBlocks layout_words{};
                if (pre_rc == ORBIS_OK) {
                    pre_rc = Internal::ComputeHorizontalLayoutBlocksTyped(fontHandle, &state,
                                                                          &layout_words);
                }
                if (pre_rc == ORBIS_OK) {
                    baseline_add = layout_words.baseline();
                    if (sys) {
                        sys->catchedScale = baseline_add;
                    }
                }
            }
        }

        const float y_used = y + baseline_add;
        {
            static std::mutex s_baseline_log_mutex;
            static std::unordered_map<OrbisFontHandle, int> s_baseline_log_counts;
            std::lock_guard<std::mutex> lock(s_baseline_log_mutex);
            int& count = s_baseline_log_counts[fontHandle];
            if (count < 5) {
                LOG_DEBUG(Lib_Font,
                          "RenderBaseline: handle={} code=U+{:04X} y_in={} baseline_add={} "
                          "y_used={} pre_rc={}",
                          static_cast<const void*>(fontHandle), code, y, baseline_add, y_used,
                          pre_rc);
                ++count;
            }
        }

        CachedStyleSetDirectionWord(font->cached_style, 1);

        if (code == 0) {
            rc = ORBIS_FONT_ERROR_NO_SUPPORT_CODE;
        } else if (!surf || !metrics || !result) {
            rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
        } else if (pre_rc != ORBIS_OK) {
            rc = pre_rc;
        } else {
            rc = Internal::RenderCharGlyphImageCore(fontHandle, code, surf, x, y_used, metrics,
                                                    result);
        }
    } else {
        s32 pre_rc = ORBIS_OK;
        float scalar_add = 0.0f;

        auto cache_cachedstyle_scalar = [&]() -> s32 {
            const u8 cached_flags = CachedStyleCacheFlags(font->cached_style);
            if ((cached_flags & 0x2) == 0) {
                Internal::VerticalLayoutBlocks layout_words{};
                pre_rc = Internal::ComputeVerticalLayoutBlocksTyped(fontHandle, &font->cached_style,
                                                                    &layout_words);
                if (pre_rc == ORBIS_OK) {
                    scalar_add = layout_words.baseline_offset_x();
                    CachedStyleSetScalar(font->cached_style, scalar_add);
                    CachedStyleSetCacheFlags(font->cached_style,
                                             static_cast<u8>(cached_flags | 0x2));
                }
            }
            if (pre_rc == ORBIS_OK && (CachedStyleCacheFlags(font->cached_style) & 0x2) != 0) {
                scalar_add = CachedStyleGetScalar(font->cached_style);
            }
            return pre_rc;
        };

        if (!surf || (surf->styleFlag & 0x1) == 0) {
            (void)cache_cachedstyle_scalar();
        } else {
            auto* sys = reinterpret_cast<Internal::RenderSurfaceSystemUse*>(surf->reserved_q);
            auto* styleframe = sys ? sys->styleframe : nullptr;
            if (!styleframe || (styleframe->flags1 & 1) == 0) {
                (void)cache_cachedstyle_scalar();
            } else {
                Internal::StyleStateBlock state{};
                state.dpi_x = styleframe->hDpi;
                state.dpi_y = styleframe->vDpi;
                state.scale_unit = 0;
                state.reserved_0x0c = 0;
                state.effect_weight_x = 0.0f;
                state.effect_weight_y = 0.0f;
                state.slant_ratio = 0.0f;
                if ((styleframe->flags1 & 2) != 0) {
                    state.slant_ratio = styleframe->slantRatio;
                }
                if ((styleframe->flags1 & 4) != 0) {
                    state.effect_weight_x = styleframe->effectWeightX;
                    state.effect_weight_y = styleframe->effectWeightY;
                }

                pre_rc = Internal::StyleStateGetScalePixel(&styleframe->hDpi, &state.scale_w,
                                                           &state.scale_h);
                Internal::VerticalLayoutBlocks layout_words{};
                if (pre_rc == ORBIS_OK) {
                    pre_rc = Internal::ComputeVerticalLayoutBlocksTyped(fontHandle, &state,
                                                                        &layout_words);
                }
                if (pre_rc == ORBIS_OK) {
                    scalar_add = layout_words.baseline_offset_x();
                    if (sys) {
                        sys->catchedScale = scalar_add;
                    }
                } else {
                    (void)cache_cachedstyle_scalar();
                }
            }
        }

        const float x_used = x + scalar_add;
        CachedStyleSetDirectionWord(font->cached_style, 2);

        if (code == 0) {
            rc = ORBIS_FONT_ERROR_NO_SUPPORT_CODE;
        } else if (!surf || !metrics || !result) {
            rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
        } else if (pre_rc != ORBIS_OK) {
            rc = pre_rc;
        } else {
            rc = Internal::RenderCharGlyphImageCore(fontHandle, code, surf, x_used, y, metrics,
                                                    result);
        }
    }

    font->lock_word = prev_lock_word;

    if (rc != ORBIS_OK) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "FAILED");
        return rc;
    }
    LogRenderResultSample(fontHandle, code, *metrics, *result);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontRenderCharGlyphImageHorizontal(OrbisFontHandle fontHandle, u32 code,
                                                       OrbisFontRenderSurface* surf, float x,
                                                       float y, OrbisFontGlyphMetrics* metrics,
                                                       OrbisFontRenderOutput* result) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (code == 0) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "NO_SUPPORT_CODE");
        return ORBIS_FONT_ERROR_NO_SUPPORT_CODE;
    }

    if (!surf || !metrics || !result) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("code", code),
                  Param("surf", surf),
                  Param("x", x),
                  Param("y", y),
                  Param("metrics", metrics),
                  Param("result", result),
              }));

    u32 prev_lock_word = 0;
    if (!AcquireFontLock(font, prev_lock_word)) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    CachedStyleSetDirectionWord(font->cached_style, 1);

    const s32 rc =
        Internal::RenderCharGlyphImageCore(fontHandle, code, surf, x, y, metrics, result);
    font->lock_word = prev_lock_word;

    if (rc != ORBIS_OK) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font,
                  "FAILED rc={} code={} surf(buffer={}, widthByte={}, pixelSizeByte={}, width={}, "
                  "height={}, styleFlag={})",
                  rc, code, surf->buffer, surf->widthByte, surf->pixelSizeByte, surf->width,
                  surf->height, surf->styleFlag);
        return rc;
    }
    if (g_prompt_render_trace.active && g_prompt_render_trace.glyph_code == code) {
        u32 coverage_nonzero = 0;
        u32 coverage_sum = 0;
        u8 coverage_max = 0;
        const auto* surf_bytes = static_cast<const u8*>(surf->buffer);
        const u32 update_x = result->UpdateRect.x;
        const u32 update_y = result->UpdateRect.y;
        const u32 update_w = result->UpdateRect.w;
        const u32 update_h = result->UpdateRect.h;
        const u32 surface_w = static_cast<u32>(std::max(surf->width, 0));
        const u32 surface_h = static_cast<u32>(std::max(surf->height, 0));
        if (surf_bytes && surf->pixelSizeByte == 1 && update_x < surface_w &&
            update_y < surface_h) {
            const u32 sample_w = std::min(update_w, surface_w - update_x);
            const u32 sample_h = std::min(update_h, surface_h - update_y);
            for (u32 row = 0; row < sample_h; ++row) {
                const auto* row_ptr =
                    surf_bytes +
                    static_cast<size_t>(update_y + row) * static_cast<size_t>(surf->widthByte) +
                    static_cast<size_t>(update_x);
                for (u32 col = 0; col < sample_w; ++col) {
                    const u8 cov = row_ptr[col];
                    coverage_sum += cov;
                    coverage_nonzero += cov != 0;
                    coverage_max = std::max(coverage_max, cov);
                }
            }
        }
        LOG_INFO(Lib_Font,
                 "TextRender[{}]: index={} code=U+{:04X} call_xy=({}, {}) step_xy=({}, {}) "
                 "surf=[buffer={} widthByte={} pixelSizeByte={} width={} height={} scissor=({}, "
                 "{})-({}, {})] "
                 "surfaceImage.address={} "
                 "update=[{},{} {}x{}] img=[bx={} by={} adv={} stride={} w={} h={}] "
                 "coverage=[nz={} sum={} max={}]",
                 g_prompt_render_trace.label ? g_prompt_render_trace.label : "Text",
                 g_prompt_render_trace.index, code, x, y, g_prompt_render_trace.step_x,
                 g_prompt_render_trace.step_y, surf->buffer, surf->widthByte, surf->pixelSizeByte,
                 surf->width, surf->height, surf->sc_x0, surf->sc_y0, surf->sc_x1, surf->sc_y1,
                 static_cast<const void*>(result->SurfaceImage.address), result->UpdateRect.x,
                 result->UpdateRect.y, result->UpdateRect.w, result->UpdateRect.h,
                 result->ImageMetrics.bearingX, result->ImageMetrics.bearingY,
                 result->ImageMetrics.advance, result->ImageMetrics.stride,
                 result->ImageMetrics.width, result->ImageMetrics.height, coverage_nonzero,
                 coverage_sum, coverage_max);
        g_prompt_render_trace = {};
    }
    LogRenderResultSample(fontHandle, code, *metrics, *result);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontRenderCharGlyphImageVertical(OrbisFontHandle fontHandle, u32 code,
                                                     OrbisFontRenderSurface* surf, float x, float y,
                                                     OrbisFontGlyphMetrics* metrics,
                                                     OrbisFontRenderOutput* result) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (code == 0) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "NO_SUPPORT_CODE");
        return ORBIS_FONT_ERROR_NO_SUPPORT_CODE;
    }

    if (!surf || !metrics || !result) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("code", code),
                  Param("surf", surf),
                  Param("x", x),
                  Param("y", y),
                  Param("metrics", metrics),
                  Param("result", result),
              }));

    u32 prev_lock_word = 0;
    if (!AcquireFontLock(font, prev_lock_word)) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    CachedStyleSetDirectionWord(font->cached_style, 2);

    const s32 rc =
        Internal::RenderCharGlyphImageCore(fontHandle, code, surf, x, y, metrics, result);
    font->lock_word = prev_lock_word;

    if (rc != ORBIS_OK) {
        ClearRenderOutputs(metrics, result);
        LOG_ERROR(Lib_Font, "FAILED");
        return rc;
    }
    LogRenderResultSample(fontHandle, code, *metrics, *result);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontRendererGetOutlineBufferSize(OrbisFontRenderer fontRenderer, u32* size) {
    LOG_INFO(Lib_Font, "called");

    if (!size) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    *size = 0;

    auto* renderer = static_cast<Internal::RendererOpaque*>(fontRenderer);
    if (!renderer || renderer->magic != 0x0F07) {
        LOG_ERROR(Lib_Font, "INVALID_RENDERER");
        return ORBIS_FONT_ERROR_INVALID_RENDERER;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontRenderer", fontRenderer),
                  Param("size", size),
              }));

    *size = static_cast<u32>(renderer->workspace_size);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontRendererResetOutlineBuffer(OrbisFontRenderer fontRenderer) {
    LOG_INFO(Lib_Font, "called");

    auto* renderer = static_cast<Internal::RendererOpaque*>(fontRenderer);
    if (!renderer || renderer->magic != 0x0F07) {
        LOG_ERROR(Lib_Font, "INVALID_RENDERER");
        return ORBIS_FONT_ERROR_INVALID_RENDERER;
    }

    LOG_DEBUG(Lib_Font, "{}", formatParams({Param("fontRenderer", fontRenderer)}));

    if (renderer->workspace && renderer->workspace_size) {
        std::memset(renderer->workspace, 0, static_cast<std::size_t>(renderer->workspace_size));
    }

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontRendererSetOutlineBufferPolicy(OrbisFontRenderer fontRenderer,
                                                       u64 bufferPolicy, u32 basalSize,
                                                       u32 limitSize) {
    LOG_INFO(Lib_Font, "called");

    auto* renderer = static_cast<Internal::RendererOpaque*>(fontRenderer);
    if (!renderer || renderer->magic != 0x0F07) {
        LOG_ERROR(Lib_Font, "INVALID_RENDERER");
        return ORBIS_FONT_ERROR_INVALID_RENDERER;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontRenderer", fontRenderer),
                  Param("bufferPolicy", bufferPolicy),
                  Param("basalSize", basalSize),
                  Param("limitSize", limitSize),
              }));

    if (limitSize != 0 && basalSize > limitSize) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    const auto alloc_fn = reinterpret_cast<Internal::FontAllocFn>(renderer->alloc_fn);
    const auto free_fn = reinterpret_cast<Internal::FontFreeFn>(renderer->free_fn);
    if (!alloc_fn || !free_fn || !renderer->alloc_ctx) {
        LOG_ERROR(Lib_Font, "INVALID_MEMORY");
        return ORBIS_FONT_ERROR_INVALID_MEMORY;
    }

    std::size_t desired_size = static_cast<std::size_t>(renderer->workspace_size);
    desired_size = std::max(desired_size, static_cast<std::size_t>(basalSize));
    if (limitSize != 0) {
        desired_size = std::min(desired_size, static_cast<std::size_t>(limitSize));
    }

    if (desired_size == 0) {
        desired_size = 0x4000;
    }

    if (!renderer->workspace || renderer->workspace_size != desired_size) {
        void* new_workspace = alloc_fn(renderer->alloc_ctx, static_cast<u32>(desired_size));
        if (!new_workspace) {
            LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
            return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
        }

        if (renderer->workspace) {
            free_fn(renderer->alloc_ctx, renderer->workspace);
        }

        renderer->workspace = new_workspace;
        renderer->workspace_size = desired_size;
    }

    (void)bufferPolicy;
    return ORBIS_OK;
}

void PS4_SYSV_ABI sceFontRenderSurfaceInit(OrbisFontRenderSurface* renderSurface, void* buffer,
                                           int bufWidthByte, int pixelSizeByte, int widthPixel,
                                           int heightPixel) {
    LOG_INFO(Lib_Font, "called");

    if (!renderSurface) {
        LOG_ERROR(Lib_Font, "NULL_POINTER");
        return;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("renderSurface", renderSurface),
                  Param("buffer", buffer),
                  Param("bufWidthByte", bufWidthByte),
                  Param("pixelSizeByte", pixelSizeByte),
                  Param("widthPixel", widthPixel),
                  Param("heightPixel", heightPixel),
              }));

    LOG_DEBUG(Lib_Font, "RenderSurfaceInit: writing struct");
    const u32 w_nonneg = (widthPixel < 0) ? 0u : static_cast<u32>(widthPixel);
    const u32 h_nonneg = (heightPixel < 0) ? 0u : static_cast<u32>(heightPixel);
    renderSurface->buffer = buffer;
    renderSurface->widthByte = bufWidthByte;
    renderSurface->pixelSizeByte = static_cast<int8_t>(pixelSizeByte);
    renderSurface->pad0 = 0;
    renderSurface->styleFlag = 0;
    renderSurface->pad2 = 0;
    renderSurface->width = static_cast<s32>(w_nonneg);
    renderSurface->height = static_cast<s32>(h_nonneg);
    renderSurface->sc_x0 = 0;
    renderSurface->sc_y0 = 0;
    renderSurface->sc_x1 = w_nonneg;
    renderSurface->sc_y1 = h_nonneg;
    LOG_DEBUG(Lib_Font, "RenderSurfaceInit: done");
}

void PS4_SYSV_ABI sceFontRenderSurfaceSetScissor(OrbisFontRenderSurface* renderSurface, int x0,
                                                 int y0, int w, int h) {
    LOG_INFO(Lib_Font, "called");

    if (!renderSurface) {
        LOG_ERROR(Lib_Font, "NULL_POINTER");
        return;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("renderSurface", renderSurface),
                  Param("x0", x0),
                  Param("y0", y0),
                  Param("w", w),
                  Param("h", h),
              }));

    const u32 surface_w = static_cast<u32>(renderSurface->width);
    if (surface_w != 0) {
        u32 x1;
        u32 x0_out;
        u32 w_u = static_cast<u32>(w);
        if (x0 < 0) {
            x1 = w_u + static_cast<u32>(x0);
            if (surface_w < x1) {
                x1 = surface_w;
            }
            if (w_u <= static_cast<u32>(-x0)) {
                x1 = 0;
            }
            x0_out = 0;
        } else {
            x1 = surface_w;
            x0_out = surface_w;
            if (static_cast<u32>(x0) <= surface_w) {
                if (surface_w < w_u) {
                    w_u = surface_w;
                }
                x1 = w_u + static_cast<u32>(x0);
                x0_out = static_cast<u32>(x0);
                if (surface_w < x1) {
                    x1 = surface_w;
                }
            }
        }
        renderSurface->sc_x0 = x0_out;
        renderSurface->sc_x1 = x1;
    }

    const u32 surface_h = static_cast<u32>(renderSurface->height);
    if (surface_h == 0) {
        return;
    }

    u32 y0_out;
    u32 y1 = surface_h;
    u32 h_u = static_cast<u32>(h);
    if (y0 < 0) {
        y0_out = 0;
        if (h_u <= static_cast<u32>(-y0)) {
            y1 = 0;
            renderSurface->sc_y0 = 0;
            renderSurface->sc_y1 = 0;
            return;
        }
    } else {
        y0_out = surface_h;
        if (surface_h < static_cast<u32>(y0)) {
            renderSurface->sc_y0 = y0_out;
            renderSurface->sc_y1 = y1;
            return;
        }
        y0_out = static_cast<u32>(y0);
        if (surface_h < h_u) {
            h_u = surface_h;
        }
    }

    const u32 y1_candidate = h_u + static_cast<u32>(y0);
    if (y1_candidate <= surface_h) {
        y1 = y1_candidate;
    }
    renderSurface->sc_y0 = y0_out;
    renderSurface->sc_y1 = y1;
}

s32 PS4_SYSV_ABI sceFontRenderSurfaceSetStyleFrame(OrbisFontRenderSurface* renderSurface,
                                                   OrbisFontStyleFrame* styleFrame) {
    LOG_INFO(Lib_Font, "called");

    if (!renderSurface) {
        LOG_ERROR(Lib_Font, "NULL_POINTER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    {
        auto* memory = Core::Memory::Instance();
        if (memory && !memory->IsValidMapping(reinterpret_cast<VAddr>(renderSurface),
                                              sizeof(OrbisFontRenderSurface))) {
            LOG_ERROR(Lib_Font, "INVALID_ADDR renderSurface={}", fmt::ptr(renderSurface));
            return ORBIS_FONT_ERROR_INVALID_PARAMETER;
        }
        if (styleFrame && !memory->IsValidMapping(reinterpret_cast<VAddr>(styleFrame),
                                                  sizeof(OrbisFontStyleFrame))) {
            LOG_ERROR(Lib_Font, "INVALID_ADDR styleFrame={}", fmt::ptr(styleFrame));
            return ORBIS_FONT_ERROR_INVALID_PARAMETER;
        }
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("renderSurface", renderSurface),
                  Param("styleFrame", styleFrame),
              }));
    if (!styleFrame) {
        renderSurface->styleFlag &= ~u8{0x1};
        renderSurface->reserved_q[0] = 0;
        renderSurface->reserved_q[1] = 0;
        return ORBIS_OK;
    }
    if (styleFrame->magic != kStyleFrameMagic) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    renderSurface->styleFlag |= 0x1;
    renderSurface->reserved_q[0] = reinterpret_cast<u64>(styleFrame);
    renderSurface->reserved_q[1] = 0;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetEffectSlant(OrbisFontHandle fontHandle, float slantRatio) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("slantRatio", slantRatio),
              }));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_lock = 0;
    if (!AcquireFontLock(font, prev_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (Internal::StyleStateSetSlantRatio(font->style_frame, slantRatio) != 0) {
        font->cached_style.layout_cache_state = 0;
    }
    ReleaseFontLock(font, prev_lock);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetEffectWeight(OrbisFontHandle fontHandle, float weightXScale,
                                        float weightYScale, u32 mode) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("weightXScale", weightXScale),
                  Param("weightYScale", weightYScale),
                  Param("mode", mode),
              }));

    if (mode != 0) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_lock = 0;
    if (!AcquireFontLock(font, prev_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (Internal::StyleStateSetWeightScale(font->style_frame, weightXScale, weightYScale) != 0) {
        font->cached_style.layout_cache_state = 0;
    }
    ReleaseFontLock(font, prev_lock);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetFontsOpenMode(OrbisFontLib library, u32 openMode) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("library", library),
                  Param("openMode", openMode),
              }));

    if (!library) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    auto* lib = static_cast<Internal::FontLibOpaque*>(library);
    if (lib->magic != 0x0F01) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    if (openMode > 2) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetResolutionDpi(OrbisFontHandle fontHandle, u32 h_dpi, u32 v_dpi) {
    auto* font = GetNativeFont(fontHandle);
    if (!font) {
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_font_lock = 0;
    if (!AcquireFontLock(font, prev_font_lock)) {
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (Internal::StyleStateSetDpi(font->style_frame, h_dpi, v_dpi) != 0) {
        font->cached_style.layout_cache_state = 0;
    }

    if (auto* st = Internal::TryGetState(fontHandle)) {
        st->dpi_x = font->style_frame[0];
        st->dpi_y = font->style_frame[1];
        st->ext_scale_for_height = 0.0f;
        st->layout_cached = false;
    }

    ReleaseFontLock(font, prev_font_lock);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetScalePixel(OrbisFontHandle fontHandle, float w, float h) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({Param("fontHandle", fontHandle), Param("w", w), Param("h", h)}));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_font_lock = 0;
    if (!AcquireFontLock(font, prev_font_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (Internal::StyleStateSetScalePixel(font->style_frame, w, h) != 0) {
        font->cached_style.layout_cache_state = 0;
    }

    if (auto* st = Internal::TryGetState(fontHandle)) {
        st->scale_w = w;
        st->scale_h = h;
        st->scale_point_active = false;
        st->ext_scale_for_height = 0.0f;
        st->layout_cached = false;
    }
    ReleaseFontLock(font, prev_font_lock);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetScalePoint(OrbisFontHandle fontHandle, float w, float h) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({Param("fontHandle", fontHandle), Param("w", w), Param("h", h)}));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_font_lock = 0;
    if (!AcquireFontLock(font, prev_font_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    if (Internal::StyleStateSetScalePoint(font->style_frame, w, h) != 0) {
        font->cached_style.layout_cache_state = 0;
    }

    if (auto* st = Internal::TryGetState(fontHandle)) {
        st->scale_point_w = w;
        st->scale_point_h = h;
        st->scale_point_active = true;
        st->ext_scale_for_height = 0.0f;
        st->layout_cached = false;
    }
    ReleaseFontLock(font, prev_font_lock);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetScriptLanguage() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetTypographicDesign() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSetupRenderEffectSlant(OrbisFontHandle fontHandle, float slantRatio) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("slantRatio", slantRatio),
              }));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_cached_lock = 0;
    if (!AcquireCachedStyleLock(font, prev_cached_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    s32 rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
    if (font->renderer_binding.renderer != nullptr) {
        if (Internal::StyleStateSetSlantRatio(&font->cached_style, slantRatio) != 0) {
            font->cached_style.cache_flags_and_direction &= 0xFFFF0000u;
        }
        rc = ORBIS_OK;
    }

    ReleaseCachedStyleLock(font, prev_cached_lock);
    if (rc != ORBIS_OK) {
        if (rc == ORBIS_FONT_ERROR_NOT_BOUND_RENDERER) {
            LOG_ERROR(Lib_Font, "NOT_BOUND");
        } else {
            LOG_ERROR(Lib_Font, "FAILED");
        }
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontSetupRenderEffectWeight(OrbisFontHandle fontHandle, float weightXScale,
                                                float weightYScale, u32 mode) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontHandle", fontHandle),
                  Param("weightXScale", weightXScale),
                  Param("weightYScale", weightYScale),
                  Param("mode", mode),
              }));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_cached_lock = 0;
    if (!AcquireCachedStyleLock(font, prev_cached_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    s32 rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
    if (font->renderer_binding.renderer != nullptr) {
        rc = ORBIS_FONT_ERROR_INVALID_PARAMETER;
        if (mode == 0) {
            if (Internal::StyleStateSetWeightScale(&font->cached_style, weightXScale,
                                                   weightYScale) != 0) {
                font->cached_style.cache_flags_and_direction &= 0xFFFF0000u;
            }
            rc = ORBIS_OK;
        }
    }

    ReleaseCachedStyleLock(font, prev_cached_lock);
    if (rc != ORBIS_OK) {
        if (rc == ORBIS_FONT_ERROR_NOT_BOUND_RENDERER) {
            LOG_ERROR(Lib_Font, "NOT_BOUND");
        } else if (rc == ORBIS_FONT_ERROR_INVALID_PARAMETER) {
            LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        } else {
            LOG_ERROR(Lib_Font, "FAILED");
        }
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontSetupRenderScalePixel(OrbisFontHandle fontHandle, float w, float h) {
    LOG_INFO(Lib_Font, "called");

    if (!fontHandle) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    LOG_DEBUG(Lib_Font, "{}",
              formatParams({Param("fontHandle", fontHandle), Param("w", w), Param("h", h)}));

    auto* font = GetNativeFont(fontHandle);
    if (!font || font->magic != 0x0F02) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_cached_lock = 0;
    if (!AcquireCachedStyleLock(font, prev_cached_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    s32 rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
    if (font->renderer_binding.renderer != nullptr) {
        if (Internal::StyleStateSetScalePixel(&font->cached_style, w, h) != 0) {
            font->cached_style.cache_flags_and_direction &= 0xFFFF0000u;
        }
        rc = ORBIS_OK;
        if (auto* st = Internal::TryGetState(fontHandle)) {
            st->render_scale_w = w;
            st->render_scale_h = h;
            st->render_scale_point_active = false;
        }
    }

    ReleaseCachedStyleLock(font, prev_cached_lock);
    if (rc != ORBIS_OK) {
        if (rc == ORBIS_FONT_ERROR_NOT_BOUND_RENDERER) {
            LOG_ERROR(Lib_Font, "NOT_BOUND");
        } else {
            LOG_ERROR(Lib_Font, "FAILED");
        }
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontSetupRenderScalePoint(OrbisFontHandle fontHandle, float w, float h) {
    auto* font = GetNativeFont(fontHandle);
    if (!font) {
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_cached_lock = 0;
    if (!AcquireCachedStyleLock(font, prev_cached_lock)) {
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    s32 rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
    if (font->renderer_binding.renderer != nullptr) {
        if (Internal::StyleStateSetScalePoint(&font->cached_style, w, h) != 0) {
            font->cached_style.cache_flags_and_direction &= 0xFFFF0000u;
        }
        rc = ORBIS_OK;
        if (auto* st = Internal::TryGetState(fontHandle)) {
            st->render_scale_point_w = w;
            st->render_scale_point_h = h;
            st->render_scale_point_active = true;
        }
    }

    ReleaseCachedStyleLock(font, prev_cached_lock);
    return rc;
}

u32 PS4_SYSV_ABI sceFontStringGetTerminateCode(OrbisFontString fontString) {
    auto* s = GetHleFontString(fontString);
    return s ? s->terminate_code : 0;
}

void* PS4_SYSV_ABI sceFontStringGetTerminateOrder(OrbisFontString fontString) {
    auto* s = GetHleFontString(fontString);
    return s ? s->terminate_order : nullptr;
}

s32 PS4_SYSV_ABI sceFontStringGetWritingForm(OrbisFontString fontString) {
    auto* s = GetHleFontString(fontString);
    return s ? static_cast<s32>(s->writing_form) : 0;
}

OrbisFontRenderCharacter PS4_SYSV_ABI sceFontStringRefersRenderCharacters(
    OrbisFontString fontString, OrbisFontTextCharacter* startCharacter,
    OrbisFontTextCharacter* lastCharacter, u32* characterCount) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontString", fontString),
                  Param("startCharacter", startCharacter),
                  Param("lastCharacter", lastCharacter),
                  Param("characterCount", characterCount),
              }));

    auto* s = GetHleFontString(fontString);
    if (!s || !characterCount || s->render_count == 0) {
        if (characterCount) {
            *characterCount = 0;
        }
        return nullptr;
    }

    auto* characters = GetTextCharacters(s);
    if (!characters) {
        *characterCount = 0;
        return nullptr;
    }

    const auto* begin = characters;
    const auto* end = characters + s->render_count;
    if (!startCharacter) {
        startCharacter = characters;
    }
    if (startCharacter < begin || startCharacter >= end) {
        *characterCount = 0;
        return nullptr;
    }

    if (lastCharacter && (lastCharacter < begin || lastCharacter >= end)) {
        *characterCount = 0;
        return nullptr;
    }

    auto level_of = [](const OrbisFontTextCharacter* character) -> u32 {
        return static_cast<u32>((character->flags >> 24) & 0xFFu);
    };

    auto* probe = startCharacter;
    if (startCharacter->clusterKind > 1) {
        do {
            startCharacter = probe;
            probe = startCharacter->prev;
            if (!probe) {
                break;
            }
        } while (probe->synthetic < 0);
    }

    u32 start_flags = static_cast<u32>(startCharacter->flags);
    const u32 paragraph_level = (s->writing_form >> 8) & 1u;
    if ((start_flags & 0xFF00u) == 0x100u && startCharacter->prev != nullptr) {
        auto* prev = startCharacter->prev;
        if (prev->clusterKind == 1) {
            startCharacter = prev;
        }
        start_flags = static_cast<u32>(startCharacter->flags);
    }

    u32 start_level = start_flags >> 24;
    u32 last_level = start_level;
    u32 min_level = start_level;
    u32 count = startCharacter->clusterIndex == 0 ? 1u : 0u;
    probe = startCharacter;
    while (probe != lastCharacter) {
        probe = probe->next;
        if (!probe) {
            if (lastCharacter) {
                *characterCount = 0;
                return nullptr;
            }
            break;
        }
        if (probe->clusterIndex == 0) {
            last_level = level_of(probe);
            if (last_level < min_level && (((last_level ^ paragraph_level) & 1u) == 0)) {
                min_level = last_level;
            }
            ++count;
        }
    }

    if (start_level != last_level || start_level != min_level) {
        probe = startCharacter->prev;
        while (probe) {
            if (probe->clusterIndex == 0) {
                if (level_of(probe) <= min_level) {
                    break;
                }
                ++count;
            }
            startCharacter = probe;
            probe = probe->prev;
        }

        if (lastCharacter) {
            probe = lastCharacter->next;
            while (probe) {
                if (probe->clusterIndex == 0) {
                    if (level_of(probe) <= min_level) {
                        break;
                    }
                    ++count;
                    lastCharacter = probe;
                }
                probe = probe->next;
            }
        } else {
            lastCharacter = nullptr;
        }
    }

    if (lastCharacter) {
        probe = lastCharacter->next;
        int cluster_trim = 0;
        while (probe) {
            int next_trim = cluster_trim;
            if (probe->clusterIndex == 0) {
                if (probe->synthetic == 0) {
                    break;
                }
                next_trim = 0;
                auto* next_last = probe;
                if (probe->synthetic < 1) {
                    if (probe->clusterKind == 1) {
                        break;
                    }
                    next_trim = cluster_trim + 1;
                    next_last = lastCharacter;
                }
                lastCharacter = next_last;
                ++count;
            }
            probe = probe->next;
            count -= static_cast<u32>(next_trim);
            cluster_trim = next_trim;
        }
    }

    start_level = level_of(startCharacter);
    if (start_level != paragraph_level) {
        probe = startCharacter;
        if (lastCharacter == nullptr || level_of(lastCharacter) != start_level) {
            do {
                probe = probe->next;
                if (!probe) {
                    if (lastCharacter) {
                        startCharacter = nullptr;
                    }
                    break;
                }

                auto* best = startCharacter;
                u32 best_level = start_level;
                if (probe->clusterIndex == 0) {
                    const u32 probe_level = level_of(probe);
                    if (probe_level <= paragraph_level) {
                        break;
                    }
                    best = probe;
                    best_level = probe_level;
                    if ((start_level & 1u) == paragraph_level && probe_level < start_level &&
                        (probe_level & 1u) != paragraph_level) {
                        best = probe;
                    } else {
                        best = startCharacter;
                        best_level = start_level;
                    }
                }
                start_level = best_level;
                startCharacter = best;
            } while (probe != lastCharacter);
        } else if ((level_of(startCharacter) & 1u) != paragraph_level) {
            startCharacter = lastCharacter;
        }
    }

    if (!startCharacter) {
        count = 0;
    }

    *characterCount = count;
    return startCharacter;
}

OrbisFontTextCharacter* PS4_SYSV_ABI sceFontStringRefersTextCharacters(OrbisFontString fontString,
                                                                       u32* characterCount) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontString", fontString),
                  Param("characterCount", characterCount),
              }));

    auto* s = GetHleFontString(fontString);
    if (!s || s->text_count == 0) {
        if (characterCount) {
            *characterCount = 0;
        }
        return nullptr;
    }

    if (characterCount) {
        *characterCount = s->text_count;
    }

    return GetTextCharacters(s);
}

s32 PS4_SYSV_ABI sceFontStyleFrameGetEffectSlant(OrbisFontStyleFrame* styleFrame,
                                                 float* slantRatio) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if ((styleFrame->flags1 & 2u) == 0) {
        return ORBIS_FONT_ERROR_UNSET_PARAMETER;
    }
    if (!slantRatio) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    *slantRatio = styleFrame->slantRatio;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameGetEffectWeight(OrbisFontStyleFrame* fontStyleFrame,
                                                  float* weightXScale, float* weightYScale,
                                                  uint32_t* mode) {
    if (!fontStyleFrame || fontStyleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if ((fontStyleFrame->flags1 & 4u) == 0) {
        return ORBIS_FONT_ERROR_UNSET_PARAMETER;
    }
    if (weightXScale) {
        *weightXScale = fontStyleFrame->effectWeightX + 1.0f;
    }
    if (weightYScale) {
        *weightYScale = fontStyleFrame->effectWeightY + 1.0f;
    }
    if (mode) {
        *mode = 0;
    }
    if (!weightXScale && !weightYScale && !mode) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameGetResolutionDpi(const OrbisFontStyleFrame* styleFrame,
                                                   u32* h_dpi, u32* v_dpi) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (h_dpi) {
        *h_dpi = styleFrame->hDpi;
    } else if (!v_dpi) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (v_dpi) {
        *v_dpi = styleFrame->vDpi;
    }
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameGetScalePixel(const OrbisFontStyleFrame* styleFrame, float* w,
                                                float* h) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if ((styleFrame->flags1 & 1u) == 0) {
        return ORBIS_FONT_ERROR_UNSET_PARAMETER;
    }
    if (!w && !h) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    const u32 scale_unit = styleFrame->scaleUnit;
    if (w) {
        float out = styleFrame->scalePixelW;
        if (scale_unit != 0 && styleFrame->hDpi != 0) {
            out = out * (static_cast<float>(styleFrame->hDpi) / kPointsPerInch);
        }
        *w = out;
    }
    if (h) {
        float out = styleFrame->scalePixelH;
        if (scale_unit != 0 && styleFrame->vDpi != 0) {
            out = out * (static_cast<float>(styleFrame->vDpi) / kPointsPerInch);
        }
        *h = out;
    }
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameGetScalePoint(const OrbisFontStyleFrame* styleFrame, float* w,
                                                float* h) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if ((styleFrame->flags1 & 1u) == 0) {
        return ORBIS_FONT_ERROR_UNSET_PARAMETER;
    }
    if (!w && !h) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    const u32 scale_unit = styleFrame->scaleUnit;
    if (w) {
        float out = styleFrame->scalePixelW;
        if (scale_unit == 0 && styleFrame->hDpi != 0) {
            out = out * (kPointsPerInch / static_cast<float>(styleFrame->hDpi));
        }
        *w = out;
    }
    if (h) {
        float out = styleFrame->scalePixelH;
        if (scale_unit == 0 && styleFrame->vDpi != 0) {
            out = out * (kPointsPerInch / static_cast<float>(styleFrame->vDpi));
        }
        *h = out;
    }
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameInit(OrbisFontStyleFrame* styleFrame) {
    if (!styleFrame) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    std::memset(reinterpret_cast<u8*>(&styleFrame->layout_cache_bytes[0x08]), 0, 0x20);
    std::memset(reinterpret_cast<u8*>(&styleFrame->layout_cache_state), 0, 0x20);
    std::memset(reinterpret_cast<u8*>(&styleFrame->scaleUnit), 0, 0x20);
    styleFrame->magic = kStyleFrameMagic;
    styleFrame->flags1 = 0;
    styleFrame->flags2 = 0;
    styleFrame->hDpi = 0x48;
    styleFrame->vDpi = 0x48;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameSetEffectSlant(OrbisFontStyleFrame* styleFrame,
                                                 float slantRatio) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    float clamped = slantRatio;
    if (clamped > 1.0f) {
        clamped = 1.0f;
    } else if (clamped < -1.0f) {
        clamped = -1.0f;
    }
    if (styleFrame->slantRatio != clamped) {
        styleFrame->slantRatio = clamped;
    }
    styleFrame->flags1 |= 2u;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameSetEffectWeight(OrbisFontStyleFrame* styleFrame,
                                                  float weightXScale, float weightYScale,
                                                  u32 mode) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (mode != 0) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    constexpr float kClamp = 0.04f;
    auto clamp_delta = [&](float delta) {
        if (delta > kClamp) {
            return kClamp;
        }
        if (delta < -kClamp) {
            return -kClamp;
        }
        return delta;
    };

    const float dx = clamp_delta(weightXScale - 1.0f);
    const float dy = clamp_delta(weightYScale - 1.0f);
    if (styleFrame->effectWeightX != dx) {
        styleFrame->effectWeightX = dx;
    }
    if (styleFrame->effectWeightY != dy) {
        styleFrame->effectWeightY = dy;
    }
    styleFrame->flags1 |= 4u;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameSetResolutionDpi(OrbisFontStyleFrame* styleFrame, u32 h_dpi,
                                                   u32 v_dpi) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    if (h_dpi == 0) {
        h_dpi = 0x48;
    }
    if (v_dpi == 0) {
        v_dpi = 0x48;
    }
    styleFrame->hDpi = h_dpi;
    styleFrame->vDpi = v_dpi;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameSetScalePixel(OrbisFontStyleFrame* styleFrame, float w, float h) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    styleFrame->scaleUnit = 0;
    styleFrame->scalePixelW = w;
    styleFrame->scalePixelH = h;
    styleFrame->flags1 |= 1u;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameSetScalePoint(OrbisFontStyleFrame* styleFrame, float w, float h) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    styleFrame->scaleUnit = 1;
    styleFrame->scalePixelW = w;
    styleFrame->scalePixelH = h;
    styleFrame->flags1 |= 1u;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameUnsetEffectSlant(OrbisFontStyleFrame* styleFrame) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    styleFrame->flags1 &= 0xfdu;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameUnsetEffectWeight(OrbisFontStyleFrame* styleFrame) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    styleFrame->flags1 &= 0xfbu;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontStyleFrameUnsetScale(OrbisFontStyleFrame* styleFrame) {
    if (!styleFrame || styleFrame->magic != kStyleFrameMagic) {
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }
    styleFrame->flags1 &= 0xfeu;
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSupportExternalFonts(OrbisFontLib library, u32 fontMax, u32 formats) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("library", library),
                  Param("fontMax", fontMax),
                  Param("formats", formats),
              }));

    if (!library) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    auto* lib = static_cast<Internal::FontLibOpaque*>(library);
    if (lib->magic != 0x0F01) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    u32 prev_lock_word = 0;
    if (!AcquireLibraryLock(lib, prev_lock_word)) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    const auto alloc_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontAllocFn>(lib->alloc_vtbl[0]) : nullptr;
    const auto free_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontFreeFn>(lib->alloc_vtbl[1]) : nullptr;

    if (lib->external_fonts_ctx) {
        ReleaseLibraryLock(lib, prev_lock_word);
        LOG_ERROR(Lib_Font, "ALREADY_SPECIFIED");
        return ORBIS_FONT_ERROR_ALREADY_SPECIFIED;
    }

    const u32 ctx_size = (fontMax << 6) | 0x20u;
    void* ctx = alloc_fn(lib->alloc_ctx, ctx_size);
    if (!ctx) {
        ReleaseLibraryLock(lib, prev_lock_word);
        LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
        return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
    }
    std::memset(ctx, 0, ctx_size);

    auto* header = static_cast<Internal::FontCtxHeader*>(ctx);
    void* list_head = nullptr;
    if (fontMax != 0) {
        list_head = static_cast<u8*>(ctx) + sizeof(Internal::FontCtxHeader);
    }
    if (fontMax != 0) {
        auto* entry = static_cast<Internal::FontCtxEntry*>(list_head);
        for (u32 i = 0; i < fontMax; i++) {
            std::memset(&entry[i], 0, sizeof(entry[i]));
        }
    }

    header->lock_word = 0;
    header->max_entries = fontMax;
    header->base = list_head;

    const auto* driver =
        lib->sys_driver ? reinterpret_cast<const Internal::SysDriver*>(lib->sys_driver) : nullptr;
    const auto support_fn = driver ? driver->support_formats : nullptr;
    if (!support_fn) {
        free_fn(lib->alloc_ctx, ctx);
        ReleaseLibraryLock(lib, prev_lock_word);
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    const s32 support_rc = support_fn(library, formats);
    if (support_rc != ORBIS_OK) {
        free_fn(lib->alloc_ctx, ctx);
        ReleaseLibraryLock(lib, prev_lock_word);
        LOG_ERROR(Lib_Font, "SUPPORT_FAILED");
        return support_rc;
    }

    lib->external_fonts_ctx = ctx;

    auto& ls = GetLibState(library);
    ls.alloc_ctx = lib->alloc_ctx;
    ls.alloc_fn = alloc_fn;
    ls.free_fn = free_fn;
    ls.support_external = true;
    ls.external_fontMax = fontMax;
    ls.external_formats = formats;
    ls.owned_external_fonts_ctx = ctx;
    ls.owned_external_fonts_ctx_size = ctx_size;

    ReleaseLibraryLock(lib, prev_lock_word);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSupportGlyphs() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontSupportSystemFonts(OrbisFontLib library) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}", formatParams({Param("library", library)}));

    if (!library) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    auto* lib = static_cast<Internal::FontLibOpaque*>(library);
    if (lib->magic != 0x0F01) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    u32 prev_lock_word = 0;
    if (!AcquireLibraryLock(lib, prev_lock_word)) {
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }

    const auto alloc_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontAllocFn>(lib->alloc_vtbl[0]) : nullptr;
    const auto free_fn =
        lib->alloc_vtbl ? reinterpret_cast<Internal::FontFreeFn>(lib->alloc_vtbl[1]) : nullptr;

    if (lib->sysfonts_ctx) {
        ReleaseLibraryLock(lib, prev_lock_word);
        LOG_ERROR(Lib_Font, "ALREADY_SPECIFIED");
        return ORBIS_FONT_ERROR_ALREADY_SPECIFIED;
    }

    constexpr u32 kSysCtxSize = 0x1020;
    void* ctx = alloc_fn(lib->alloc_ctx, kSysCtxSize);
    if (!ctx) {
        ReleaseLibraryLock(lib, prev_lock_word);
        LOG_ERROR(Lib_Font, "ALLOCATION_FAILED");
        return ORBIS_FONT_ERROR_ALLOCATION_FAILED;
    }
    std::memset(ctx, 0, kSysCtxSize);

    auto* header = static_cast<Internal::FontCtxHeader*>(ctx);
    header->lock_word = 0;
    header->max_entries = 0x40;
    header->base = reinterpret_cast<u8*>(ctx) + sizeof(Internal::FontCtxHeader);

    auto* entries = static_cast<Internal::FontCtxEntry*>(header->base);
    for (u32 i = 0; i < header->max_entries; i++) {
        std::memset(&entries[i], 0, sizeof(entries[i]));
    }

    const auto* driver =
        lib->sys_driver ? reinterpret_cast<const Internal::SysDriver*>(lib->sys_driver) : nullptr;
    const auto support_fn = driver ? driver->support_formats : nullptr;
    if (!support_fn) {
        free_fn(lib->alloc_ctx, ctx);
        ReleaseLibraryLock(lib, prev_lock_word);
        LOG_ERROR(Lib_Font, "INVALID_LIBRARY");
        return ORBIS_FONT_ERROR_INVALID_LIBRARY;
    }
    const s32 support_rc = support_fn(library, 0x52);
    if (support_rc != ORBIS_OK) {
        free_fn(lib->alloc_ctx, ctx);
        ReleaseLibraryLock(lib, prev_lock_word);
        LOG_ERROR(Lib_Font, "SUPPORT_FAILED");
        return support_rc;
    }

    lib->sysfonts_ctx = ctx;

    auto& ls = GetLibState(library);
    ls.alloc_ctx = lib->alloc_ctx;
    ls.alloc_fn = alloc_fn;
    ls.free_fn = free_fn;
    ls.support_system = true;
    ls.owned_sysfonts_ctx = ctx;
    ls.owned_sysfonts_ctx_size = kSysCtxSize;

    ReleaseLibraryLock(lib, prev_lock_word);
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontTextCodesStepBack() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontTextCodesStepNext() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontTextSourceInit(OrbisFontTextSource* fontTextSource, const void* textAddress,
                                       u32 textSizeByte, OrbisFontTextParser textParser,
                                       void* textObject) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontTextSource", fontTextSource),
                  Param("textAddress", textAddress),
                  Param("textSizeByte", textSizeByte),
                  Param("textParser", reinterpret_cast<const void*>(textParser)),
                  Param("textObject", textObject),
              }));

    if (!fontTextSource) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    if (!textParser) {
        std::memset(fontTextSource, 0, sizeof(*fontTextSource));
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    const void* end = nullptr;
    if (textSizeByte != 0) {
        const auto start_addr = reinterpret_cast<std::uintptr_t>(textAddress);
        end = reinterpret_cast<const void*>(start_addr + static_cast<std::uintptr_t>(textSizeByte));
    }

    std::memset(fontTextSource, 0, sizeof(*fontTextSource));

    fontTextSource->systemUse0 =
        (static_cast<u64>(kWritingFormHorizontal) << 32) | kTextSourceMagic;

    fontTextSource->start = textAddress;
    fontTextSource->end = end;
    fontTextSource->current = textAddress;
    fontTextSource->textParser = textParser;
    fontTextSource->textObject = textObject;
    fontTextSource->defaultFont = nullptr;

    fontTextSource->systemUse[0] = const_cast<void*>(textAddress);
    fontTextSource->systemUse[1] = const_cast<void*>(end);
    fontTextSource->systemUse[2] = reinterpret_cast<void*>(textParser);
    fontTextSource->systemUse[3] = textObject;
    fontTextSource->systemUse[4] = nullptr;

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontTextSourceRewind(OrbisFontTextSource* fontTextSource) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}", formatParams({Param("fontTextSource", fontTextSource)}));

    if (!fontTextSource) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    if (TextSourceMagic(fontTextSource) != kTextSourceMagic) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    fontTextSource->start = fontTextSource->systemUse[0];
    fontTextSource->end = fontTextSource->systemUse[1];
    fontTextSource->current = fontTextSource->systemUse[0];
    fontTextSource->textParser =
        reinterpret_cast<OrbisFontTextParseFunction>(fontTextSource->systemUse[2]);
    fontTextSource->textObject = fontTextSource->systemUse[3];
    fontTextSource->defaultFont = static_cast<OrbisFontHandle>(fontTextSource->systemUse[4]);

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontTextSourceSetDefaultFont(OrbisFontTextSource* fontTextSource,
                                                 OrbisFontHandle defaultFont) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontTextSource", fontTextSource),
                  Param("defaultFont", defaultFont),
              }));

    if (!fontTextSource) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    if (TextSourceMagic(fontTextSource) != kTextSourceMagic) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    fontTextSource->defaultFont = defaultFont;
    fontTextSource->systemUse[4] = defaultFont;

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontTextSourceSetWritingForm(OrbisFontTextSource* fontTextSource,
                                                 s32 writingForm) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontTextSource", fontTextSource),
                  Param("writingForm", writingForm),
              }));

    if (!fontTextSource) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    if (TextSourceMagic(fontTextSource) != kTextSourceMagic) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    if (writingForm < static_cast<s32>(kWritingFormHorizontal) ||
        writingForm > static_cast<s32>(kWritingFormHorizontalLtr)) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    SetTextSourceWritingForm(fontTextSource, static_cast<u32>(writingForm));
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontUnbindRenderer(OrbisFontHandle fontHandle) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}", formatParams({Param("fontHandle", fontHandle)}));

    auto* font = GetNativeFont(fontHandle);
    if (!font) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    u32 prev_cached_lock = 0;
    if (!AcquireCachedStyleLock(font, prev_cached_lock)) {
        LOG_ERROR(Lib_Font, "INVALID_HANDLE");
        return ORBIS_FONT_ERROR_INVALID_FONT_HANDLE;
    }

    s32 rc = ORBIS_FONT_ERROR_NOT_BOUND_RENDERER;
    if (font->renderer_binding.renderer != nullptr) {
        rc = ORBIS_OK;
        font->renderer_binding.renderer = nullptr;
        if (auto* st = Internal::TryGetState(fontHandle)) {
            st->bound_renderer = nullptr;
        }
    }

    ReleaseCachedStyleLock(font, prev_cached_lock);
    if (rc != ORBIS_OK) {
        if (rc == ORBIS_FONT_ERROR_NOT_BOUND_RENDERER) {
            LOG_ERROR(Lib_Font, "NOT_BOUND");
        } else {
            LOG_ERROR(Lib_Font, "FAILED");
        }
    }
    return rc;
}

s32 PS4_SYSV_ABI sceFontWordsFindWordCharacters() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontWritingGetRenderMetrics(OrbisFontWriting* fontWriting,
                                                OrbisFontWritingMetrics* writingMetrics) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontWriting", fontWriting),
                  Param("writingMetrics", writingMetrics),
              }));

    if (!fontWriting || !writingMetrics) {
        ZeroWritingMetrics(writingMetrics);
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    auto* w = GetHleFontWriting(fontWriting);
    if (!w) {
        ZeroWritingMetrics(writingMetrics);
        LOG_ERROR(Lib_Font, "INVALID_WRITING");
        return ORBIS_FONT_ERROR_INVALID_WRITING;
    }

    *writingMetrics = w->metrics;
    if (w->debug_trace_label) {
        LOG_INFO(Lib_Font, "TextMetrics[{}]: advanceX={} advanceY={} extent=[l={} r={} t={} b={}]",
                 w->debug_trace_label, writingMetrics->advanceX, writingMetrics->advanceY,
                 writingMetrics->Extent.left, writingMetrics->Extent.right,
                 writingMetrics->Extent.top, writingMetrics->Extent.bottom);
    }
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontWritingInit(OrbisFontWriting* fontWriting, OrbisFontString fontString,
                                    OrbisFontRenderCharacter fontCharacter) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontWriting", fontWriting),
                  Param("fontString", fontString),
                  Param("fontCharacter", fontCharacter),
              }));

    if (!fontWriting || !fontString || !fontCharacter) {
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    auto* s = GetHleFontString(fontString);
    if (!s) {
        LOG_ERROR(Lib_Font, "INVALID_STRING");
        return ORBIS_FONT_ERROR_INVALID_STRING;
    }

    if (auto* old_w = GetHleFontWriting(fontWriting)) {
        ReleaseWritingCharacterStorage(*old_w);
    }

    std::memset(fontWriting, 0, sizeof(*fontWriting));

    auto* w = reinterpret_cast<HleFontWriting*>(fontWriting->systemUse);
    new (w) HleFontWriting{};

    w->string = fontString;
    w->character_storage = s->character_storage;
    w->default_font = s->default_font;
    AddRefCharacterStorage(w->character_storage);
    w->owns_character_storage = true;
    w->writing_form = s->writing_form;
    if (MatchesAsciiPrompt(*s, "Press Any Button")) {
        w->debug_trace_label = "Prompt";
    } else if (ContainsAsciiText(*s, "Some online features cannot be used") ||
               ContainsAsciiText(*s, "connected to the internet")) {
        w->debug_trace_label = "Notice";
    }
    const ptrdiff_t start_index = FindCharacterIndex(s, fontCharacter);
    if (start_index < 0) {
        ReleaseWritingCharacterStorage(*w);
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER render character does not belong to string");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    w->next_index = static_cast<size_t>(start_index);
    w->current_index = w->next_index;
    w->has_current_step = false;
    if (!PopulateWritingStep(*w, w->next_index, w->default_font)) {
        ReleaseWritingCharacterStorage(*w);
        LOG_ERROR(Lib_Font, "INVALID_PARAMETER failed to populate initial writing step");
        return ORBIS_FONT_ERROR_INVALID_PARAMETER;
    }

    LOG_INFO(
        Lib_Font,
        "sceFontWritingInit: prepared first render step code={} advanceX={} width={} height={} "
        "bearingX={} bearingY={}",
        w->step.glyphCode, w->step.advanceX, w->step.GlyphMetrics.width,
        w->step.GlyphMetrics.height, w->step.GlyphMetrics.Horizontal.bearingX,
        w->step.GlyphMetrics.Horizontal.bearingY);
    if (w->debug_trace_label) {
        LOG_INFO(Lib_Font, "TextTrace[{}]: writing init start_index={} text_count={}",
                 w->debug_trace_label, static_cast<size_t>(start_index), s->text_count);
    }
    w->pen_x = 0.0f;
    w->pen_y = 0.0f;
    ResetWritingAggregateMetrics(*w);

    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontWritingLineClear() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontWritingLineGetOrderingSpace() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontWritingLineGetRenderMetrics() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontWritingLineRefersRenderStep() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI sceFontWritingLineWritesOrder() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

OrbisFontWritingRenderStep PS4_SYSV_ABI
sceFontWritingRefersRenderStep(OrbisFontWriting* fontWriting) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}", formatParams({Param("fontWriting", fontWriting)}));

    auto* w = GetHleFontWriting(fontWriting);
    if (!w) {
        return nullptr;
    }

    if (!w->character_storage || w->next_index >= w->character_storage->characters.size()) {
        return nullptr;
    }

    if (!PopulateWritingStep(*w, w->next_index, w->default_font)) {
        return nullptr;
    }

    w->current_index = w->next_index;
    w->has_current_step = true;
    AccumulateWritingMetrics(*w);
    if (w->debug_trace_label) {
        g_prompt_render_trace.active = true;
        g_prompt_render_trace.label = w->debug_trace_label;
        g_prompt_render_trace.index = w->next_index;
        g_prompt_render_trace.glyph_code = w->step.glyphCode;
        g_prompt_render_trace.step_x = w->step.x;
        g_prompt_render_trace.step_y = w->step.y;
        LOG_INFO(Lib_Font,
                 "TextTrace[{}]: step index={} code=U+{:04X} x={} y={} advanceX={} advanceY={} "
                 "anchor=({}, {}) bearingX={} bearingY={} width={} height={} profile[count={} "
                 "invisible={}]",
                 w->debug_trace_label, w->next_index, w->step.glyphCode, w->step.x, w->step.y,
                 w->step.advanceX, w->step.advanceY, w->step.Positioning.x, w->step.Positioning.y,
                 w->step.GlyphMetrics.Horizontal.bearingX, w->step.GlyphMetrics.Horizontal.bearingY,
                 w->step.GlyphMetrics.width, w->step.GlyphMetrics.height,
                 static_cast<u32>(w->step.Profile.characterCount),
                 static_cast<u32>(w->step.Profile.invisibleGlyph));
    }
    ++w->next_index;
    return &w->step;
}

OrbisFontTextCharacter* PS4_SYSV_ABI sceFontWritingRefersRenderStepCharacter(
    OrbisFontWriting* fontWriting, OrbisFontWritingLetterStep* pLetterStep) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontWriting", fontWriting),
                  Param("pLetterStep", pLetterStep),
              }));

    if (pLetterStep) {
        std::memset(pLetterStep, 0, sizeof(*pLetterStep));
    }

    auto* w = GetHleFontWriting(fontWriting);
    if (!w || !w->has_current_step) {
        return nullptr;
    }

    if (!w->character_storage || w->current_index >= w->character_storage->characters.size()) {
        return nullptr;
    }

    if (pLetterStep) {
        pLetterStep->x = w->step.x;
        pLetterStep->y = w->step.y;
        pLetterStep->advanceX = w->step.advanceX;
        pLetterStep->advanceY = w->step.advanceY;
        pLetterStep->Components.textsCount = 1;
        pLetterStep->Components.textsIndex = static_cast<u32>(w->current_index);
        pLetterStep->Components.glyphsCount = 1;
        pLetterStep->Components.glyphsIndex = static_cast<u32>(w->current_index);
        pLetterStep->Components.characterTextCount =
            static_cast<u8>(std::max<u32>(static_cast<u32>(w->step.Profile.characterCount), 1));
    }

    return &w->character_storage->characters[w->current_index];
}

s32 PS4_SYSV_ABI sceFontWritingSetMaskInvisible(OrbisFontWriting* fontWriting, s32 mask) {
    LOG_INFO(Lib_Font, "called");
    LOG_DEBUG(Lib_Font, "{}",
              formatParams({
                  Param("fontWriting", fontWriting),
                  Param("mask", mask),
              }));

    auto* w = GetHleFontWriting(fontWriting);
    if (!w) {
        LOG_ERROR(Lib_Font, "INVALID_WRITING");
        return ORBIS_FONT_ERROR_INVALID_WRITING;
    }

    if (mask == kWritingMaskFormatCharacters) {
        w->mask_format_characters = false;
        return ORBIS_OK;
    }
    if (mask == kWritingMaskNone) {
        w->mask_format_characters = true;
        return ORBIS_OK;
    }

    LOG_ERROR(Lib_Font, "INVALID_PARAMETER");
    return ORBIS_FONT_ERROR_INVALID_PARAMETER;
}

s32 PS4_SYSV_ABI Func_00F4D778F1C88CB3() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_03C650025FBB0DE7() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_07EAB8A163B27E1A() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_09408E88E4F97CE3() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_09F92905ED82A814() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_0D142CEE1AB21ABE() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_14BD2E9E119C16F2() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_1AC53C9EDEAE8D75() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_1D401185D5E24C3D() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_1E83CD20C2CC996F() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_314B1F765B9FE78A() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_350E6725FEDE29E1() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_3DB773F0A604BF39() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_4FF49DD21E311B1C() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_526287664A493981() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_55CA718DBC84A6E9() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_563FC5F0706A8B4D() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_569E2ECD34290F45() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_5A04775B6BE47685() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_5FD93BCAB6F79750() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_62B5398F864BD3B4() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_6F9010294D822367() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_7757E947423A7A67() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_7E06BA52077F54FA() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_93B36DEA021311D6() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_94B0891E7111598A() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_9785C9128C2FE7CD() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_97DFBC9B65FBC0E1() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_ACD9717405D7D3CA() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_B19A8AEC3FD4F16F() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_C10F488AD7CF103D() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_D0C8B5FF4A6826C7() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_E48D3CD01C342A33() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_EAC96B2186B71E14() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_FE4788A96EF46256() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

s32 PS4_SYSV_ABI Func_FE7E5AE95D3058F5() {
    LOG_ERROR(Lib_Font, "(STUBBED) called");
    return ORBIS_OK;
}

void RegisterLib(Core::Loader::SymbolsResolver* sym) {
    LIB_FUNCTION("CUKn5pX-NVY", "libSceFont", 1, "libSceFont", sceFontAttachDeviceCacheBuffer);
    LIB_FUNCTION("3OdRkSjOcog", "libSceFont", 1, "libSceFont", sceFontBindRenderer);
    LIB_FUNCTION("6DFUkCwQLa8", "libSceFont", 1, "libSceFont", sceFontCharacterGetBidiLevel);
    LIB_FUNCTION("coCrV6IWplE", "libSceFont", 1, "libSceFont",
                 sceFontCharacterGetSyllableStringState);
    LIB_FUNCTION("zN3+nuA0SFQ", "libSceFont", 1, "libSceFont", sceFontCharacterGetTextFontCode);
    LIB_FUNCTION("mxgmMj-Mq-o", "libSceFont", 1, "libSceFont", sceFontCharacterGetTextOrder);
    LIB_FUNCTION("-P6X35Rq2-E", "libSceFont", 1, "libSceFont",
                 sceFontCharacterLooksFormatCharacters);
    LIB_FUNCTION("SaRlqtqaCew", "libSceFont", 1, "libSceFont", sceFontCharacterLooksWhiteSpace);
    LIB_FUNCTION("6Gqlv5KdTbU", "libSceFont", 1, "libSceFont", sceFontCharacterRefersTextBack);
    LIB_FUNCTION("BkjBP+YC19w", "libSceFont", 1, "libSceFont", sceFontCharacterRefersTextNext);
    LIB_FUNCTION("lVSR5ftvNag", "libSceFont", 1, "libSceFont", sceFontCharactersRefersTextCodes);
    LIB_FUNCTION("I9R5VC6eZWo", "libSceFont", 1, "libSceFont", sceFontClearDeviceCache);
    LIB_FUNCTION("vzHs3C8lWJk", "libSceFont", 1, "libSceFont", sceFontCloseFont);
    LIB_FUNCTION("MpKSBaYKluo", "libSceFont", 1, "libSceFont", sceFontControl);
    LIB_FUNCTION("WBNBaj9XiJU", "libSceFont", 1, "libSceFont", sceFontCreateGraphicsDevice);
    LIB_FUNCTION("4So0MC3oBIM", "libSceFont", 1, "libSceFont", sceFontCreateGraphicsService);
    LIB_FUNCTION("NlO5Qlhjkng", "libSceFont", 1, "libSceFont",
                 sceFontCreateGraphicsServiceWithEdition);
    LIB_FUNCTION("nWrfPI4Okmg", "libSceFont", 1, "libSceFont", sceFontCreateLibrary);
    LIB_FUNCTION("n590hj5Oe-k", "libSceFont", 1, "libSceFont", sceFontCreateLibraryWithEdition);
    LIB_FUNCTION("u5fZd3KZcs0", "libSceFont", 1, "libSceFont", sceFontCreateRenderer);
    LIB_FUNCTION("WaSFJoRWXaI", "libSceFont", 1, "libSceFont", sceFontCreateRendererWithEdition);
    LIB_FUNCTION("MO24vDhmS4E", "libSceFont", 1, "libSceFont", sceFontCreateString);
    LIB_FUNCTION("cYrMGk1wrMA", "libSceFont", 1, "libSceFont", sceFontCreateWords);
    LIB_FUNCTION("7rogx92EEyc", "libSceFont", 1, "libSceFont", sceFontCreateWritingLine);
    LIB_FUNCTION("8h-SOB-asgk", "libSceFont", 1, "libSceFont", sceFontDefineAttribute);
    LIB_FUNCTION("LHDoRWVFGqk", "libSceFont", 1, "libSceFont", sceFontDeleteGlyph);
    LIB_FUNCTION("5QG71IjgOpQ", "libSceFont", 1, "libSceFont", sceFontDestroyGraphicsDevice);
    LIB_FUNCTION("zZQD3EwJo3c", "libSceFont", 1, "libSceFont", sceFontDestroyGraphicsService);
    LIB_FUNCTION("FXP359ygujs", "libSceFont", 1, "libSceFont", sceFontDestroyLibrary);
    LIB_FUNCTION("exAxkyVLt0s", "libSceFont", 1, "libSceFont", sceFontDestroyRenderer);
    LIB_FUNCTION("SSCaczu2aMQ", "libSceFont", 1, "libSceFont", sceFontDestroyString);
    LIB_FUNCTION("hWE4AwNixqY", "libSceFont", 1, "libSceFont", sceFontDestroyWords);
    LIB_FUNCTION("PEjv7CVDRYs", "libSceFont", 1, "libSceFont", sceFontDestroyWritingLine);
    LIB_FUNCTION("UuY-OJF+f0k", "libSceFont", 1, "libSceFont", sceFontDettachDeviceCacheBuffer);
    LIB_FUNCTION("C-4Qw5Srlyw", "libSceFont", 1, "libSceFont", sceFontGenerateCharGlyph);
    LIB_FUNCTION("5kx49CAlO-M", "libSceFont", 1, "libSceFont", sceFontGetAttribute);
    LIB_FUNCTION("OINC0X9HGBY", "libSceFont", 1, "libSceFont", sceFontGetCharGlyphCode);
    LIB_FUNCTION("L97d+3OgMlE", "libSceFont", 1, "libSceFont", sceFontGetCharGlyphMetrics);
    LIB_FUNCTION("ynSqYL8VpoA", "libSceFont", 1, "libSceFont", sceFontGetEffectSlant);
    LIB_FUNCTION("d7dDgRY+Bzw", "libSceFont", 1, "libSceFont", sceFontGetEffectWeight);
    LIB_FUNCTION("ZB8xRemRRG8", "libSceFont", 1, "libSceFont", sceFontGetFontGlyphsCount);
    LIB_FUNCTION("4X14YSK4Ldk", "libSceFont", 1, "libSceFont", sceFontGetFontGlyphsOutlineProfile);
    LIB_FUNCTION("eb9S3zNlV5o", "libSceFont", 1, "libSceFont", sceFontGetFontMetrics);
    LIB_FUNCTION("tiIlroGki+g", "libSceFont", 1, "libSceFont", sceFontGetFontResolution);
    LIB_FUNCTION("3hVv3SNoL6E", "libSceFont", 1, "libSceFont", sceFontGetFontStyleInformation);
    LIB_FUNCTION("gVQpMBuB7fE", "libSceFont", 1, "libSceFont", sceFontGetGlyphExpandBufferState);
    LIB_FUNCTION("imxVx8lm+KM", "libSceFont", 1, "libSceFont", sceFontGetHorizontalLayout);
    LIB_FUNCTION("sDuhHGNhHvE", "libSceFont", 1, "libSceFont", sceFontGetKerning);
    LIB_FUNCTION("LzmHDnlcwfQ", "libSceFont", 1, "libSceFont", sceFontGetLibrary);
    LIB_FUNCTION("BozJej5T6fs", "libSceFont", 1, "libSceFont", sceFontGetPixelResolution);
    LIB_FUNCTION("IQtleGLL5pQ", "libSceFont", 1, "libSceFont", sceFontGetRenderCharGlyphMetrics);
    LIB_FUNCTION("Gqa5Pp7y4MU", "libSceFont", 1, "libSceFont", sceFontGetRenderEffectSlant);
    LIB_FUNCTION("woOjHrkjIYg", "libSceFont", 1, "libSceFont", sceFontGetRenderEffectWeight);
    LIB_FUNCTION("ryPlnDDI3rU", "libSceFont", 1, "libSceFont", sceFontGetRenderScaledKerning);
    LIB_FUNCTION("EY38A01lq2k", "libSceFont", 1, "libSceFont", sceFontGetRenderScalePixel);
    LIB_FUNCTION("FEafYUcxEGo", "libSceFont", 1, "libSceFont", sceFontGetRenderScalePoint);
    LIB_FUNCTION("8REoLjNGCpM", "libSceFont", 1, "libSceFont", sceFontGetResolutionDpi);
    LIB_FUNCTION("CkVmLoCNN-8", "libSceFont", 1, "libSceFont", sceFontGetScalePixel);
    LIB_FUNCTION("GoF2bhB7LYk", "libSceFont", 1, "libSceFont", sceFontGetScalePoint);
    LIB_FUNCTION("IrXeG0Lc6nA", "libSceFont", 1, "libSceFont", sceFontGetScriptLanguage);
    LIB_FUNCTION("7-miUT6pNQw", "libSceFont", 1, "libSceFont", sceFontGetTypographicDesign);
    LIB_FUNCTION("3BrWWFU+4ts", "libSceFont", 1, "libSceFont", sceFontGetVerticalLayout);
    LIB_FUNCTION("8-zmgsxkBek", "libSceFont", 1, "libSceFont", sceFontGlyphDefineAttribute);
    LIB_FUNCTION("oO33Uex4Ui0", "libSceFont", 1, "libSceFont", sceFontGlyphGetAttribute);
    LIB_FUNCTION("PXlA0M8ax40", "libSceFont", 1, "libSceFont", sceFontGlyphGetGlyphForm);
    LIB_FUNCTION("XUfSWpLhrUw", "libSceFont", 1, "libSceFont", sceFontGlyphGetMetricsForm);
    LIB_FUNCTION("lNnUqa1zA-M", "libSceFont", 1, "libSceFont", sceFontGlyphGetScalePixel);
    LIB_FUNCTION("ntrc3bEWlvQ", "libSceFont", 1, "libSceFont", sceFontGlyphRefersMetrics);
    LIB_FUNCTION("9kTbF59TjLs", "libSceFont", 1, "libSceFont", sceFontGlyphRefersMetricsHorizontal);
    LIB_FUNCTION("nJavPEdMDvM", "libSceFont", 1, "libSceFont",
                 sceFontGlyphRefersMetricsHorizontalAdvance);
    LIB_FUNCTION("JCnVgZgcucs", "libSceFont", 1, "libSceFont",
                 sceFontGlyphRefersMetricsHorizontalX);
    LIB_FUNCTION("R1T4i+DOhNY", "libSceFont", 1, "libSceFont", sceFontGlyphRefersOutline);
    LIB_FUNCTION("RmkXfBcZnrM", "libSceFont", 1, "libSceFont", sceFontGlyphRenderImage);
    LIB_FUNCTION("r4KEihtwxGs", "libSceFont", 1, "libSceFont", sceFontGlyphRenderImageHorizontal);
    LIB_FUNCTION("n22d-HIdmMg", "libSceFont", 1, "libSceFont", sceFontGlyphRenderImageVertical);
    LIB_FUNCTION("RL2cAQgyXR8", "libSceFont", 1, "libSceFont", sceFontGraphicsBeginFrame);
    LIB_FUNCTION("dUmIK6QjT7E", "libSceFont", 1, "libSceFont", sceFontGraphicsDrawingCancel);
    LIB_FUNCTION("X2Vl3yU19Zw", "libSceFont", 1, "libSceFont", sceFontGraphicsDrawingFinish);
    LIB_FUNCTION("DOmdOwV3Aqw", "libSceFont", 1, "libSceFont", sceFontGraphicsEndFrame);
    LIB_FUNCTION("zdYdKRQC3rw", "libSceFont", 1, "libSceFont", sceFontGraphicsExchangeResource);
    LIB_FUNCTION("UkMUIoj-e9s", "libSceFont", 1, "libSceFont", sceFontGraphicsFillMethodInit);
    LIB_FUNCTION("DJURdcnVUqo", "libSceFont", 1, "libSceFont", sceFontGraphicsFillPlotInit);
    LIB_FUNCTION("eQac6ftmBQQ", "libSceFont", 1, "libSceFont", sceFontGraphicsFillPlotSetLayout);
    LIB_FUNCTION("PEYQJa+MWnk", "libSceFont", 1, "libSceFont", sceFontGraphicsFillPlotSetMapping);
    LIB_FUNCTION("21g4m4kYF6g", "libSceFont", 1, "libSceFont", sceFontGraphicsFillRatesInit);
    LIB_FUNCTION("pJzji5FvdxU", "libSceFont", 1, "libSceFont",
                 sceFontGraphicsFillRatesSetFillEffect);
    LIB_FUNCTION("scaro-xEuUM", "libSceFont", 1, "libSceFont", sceFontGraphicsFillRatesSetLayout);
    LIB_FUNCTION("W66Kqtt0xU0", "libSceFont", 1, "libSceFont", sceFontGraphicsFillRatesSetMapping);
    LIB_FUNCTION("FzpLsBQEegQ", "libSceFont", 1, "libSceFont", sceFontGraphicsGetDeviceUsage);
    LIB_FUNCTION("W80hs0g5d+E", "libSceFont", 1, "libSceFont", sceFontGraphicsRegionInit);
    LIB_FUNCTION("S48+njg9p-o", "libSceFont", 1, "libSceFont", sceFontGraphicsRegionInitCircular);
    LIB_FUNCTION("wcOQ8Fz73+M", "libSceFont", 1, "libSceFont", sceFontGraphicsRegionInitRoundish);
    LIB_FUNCTION("YBaw2Yyfd5E", "libSceFont", 1, "libSceFont", sceFontGraphicsRelease);
    LIB_FUNCTION("qkySrQ4FGe0", "libSceFont", 1, "libSceFont", sceFontGraphicsRenderResource);
    LIB_FUNCTION("qzNjJYKVli0", "libSceFont", 1, "libSceFont", sceFontGraphicsSetFramePolicy);
    LIB_FUNCTION("9iRbHCtcx-o", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupClipping);
    LIB_FUNCTION("KZ3qPyz5Opc", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupColorRates);
    LIB_FUNCTION("LqclbpVzRvM", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupFillMethod);
    LIB_FUNCTION("Wl4FiI4qKY0", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupFillRates);
    LIB_FUNCTION("WC7s95TccVo", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupGlyphFill);
    LIB_FUNCTION("zC6I4ty37NA", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupGlyphFillPlot);
    LIB_FUNCTION("drZUF0XKTEI", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupHandleDefault);
    LIB_FUNCTION("MEAmHMynQXE", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupLocation);
    LIB_FUNCTION("XRUOmQhnYO4", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupPositioning);
    LIB_FUNCTION("98XGr2Bkklg", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupRotation);
    LIB_FUNCTION("Nj-ZUVOVAvc", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupScaling);
    LIB_FUNCTION("p0avT2ggev0", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupShapeFill);
    LIB_FUNCTION("0C5aKg9KghY", "libSceFont", 1, "libSceFont", sceFontGraphicsSetupShapeFillPlot);
    LIB_FUNCTION("4pA3qqAcYco", "libSceFont", 1, "libSceFont", sceFontGraphicsStructureCanvas);
    LIB_FUNCTION("cpjgdlMYdOM", "libSceFont", 1, "libSceFont",
                 sceFontGraphicsStructureCanvasSequence);
    LIB_FUNCTION("774Mee21wKk", "libSceFont", 1, "libSceFont", sceFontGraphicsStructureDesign);
    LIB_FUNCTION("Hp3NIFhUXvQ", "libSceFont", 1, "libSceFont",
                 sceFontGraphicsStructureDesignResource);
    LIB_FUNCTION("bhmZlml6NBs", "libSceFont", 1, "libSceFont",
                 sceFontGraphicsStructureSurfaceTexture);
    LIB_FUNCTION("5sAWgysOBfE", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateClipping);
    LIB_FUNCTION("W4e8obm+w6o", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateColorRates);
    LIB_FUNCTION("EgIn3QBajPs", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateFillMethod);
    LIB_FUNCTION("MnUYAs2jVuU", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateFillRates);
    LIB_FUNCTION("R-oVDMusYbc", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateGlyphFill);
    LIB_FUNCTION("b9R+HQuHSMI", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateGlyphFillPlot);
    LIB_FUNCTION("IN4P5pJADQY", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateLocation);
    LIB_FUNCTION("U+LLXdr2DxM", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdatePositioning);
    LIB_FUNCTION("yStTYSeb4NM", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateRotation);
    LIB_FUNCTION("eDxmMoxE5xU", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateScaling);
    LIB_FUNCTION("Ax6LQJJq6HQ", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateShapeFill);
    LIB_FUNCTION("I5Rf2rXvBKQ", "libSceFont", 1, "libSceFont", sceFontGraphicsUpdateShapeFillPlot);
    LIB_FUNCTION("whrS4oksXc4", "libSceFont", 1, "libSceFont", sceFontMemoryInit);
    LIB_FUNCTION("h6hIgxXEiEc", "libSceFont", 1, "libSceFont", sceFontMemoryTerm);
    LIB_FUNCTION("RvXyHMUiLhE", "libSceFont", 1, "libSceFont", sceFontOpenFontFile);
    LIB_FUNCTION("JzCH3SCFnAU", "libSceFont", 1, "libSceFont", sceFontOpenFontInstance);
    LIB_FUNCTION("KXUpebrFk1U", "libSceFont", 1, "libSceFont", sceFontOpenFontMemory);
    LIB_FUNCTION("cKYtVmeSTcw", "libSceFont", 1, "libSceFont", sceFontOpenFontSet);
    LIB_FUNCTION("Z2cdsqJH+5k", "libSceFont", 1, "libSceFont", sceFontRebindRenderer);
    LIB_FUNCTION("3G4zhgKuxE8", "libSceFont", 1, "libSceFont", sceFontRenderCharGlyphImage);
    LIB_FUNCTION("kAenWy1Zw5o", "libSceFont", 1, "libSceFont",
                 sceFontRenderCharGlyphImageHorizontal);
    LIB_FUNCTION("i6UNdSig1uE", "libSceFont", 1, "libSceFont", sceFontRenderCharGlyphImageVertical);
    LIB_FUNCTION("amcmrY62BD4", "libSceFont", 1, "libSceFont", sceFontRendererGetOutlineBufferSize);
    LIB_FUNCTION("ai6AfGrBs4o", "libSceFont", 1, "libSceFont", sceFontRendererResetOutlineBuffer);
    LIB_FUNCTION("ydF+WuH0fAk", "libSceFont", 1, "libSceFont",
                 sceFontRendererSetOutlineBufferPolicy);
    LIB_FUNCTION("gdUCnU0gHdI", "libSceFont", 1, "libSceFont", sceFontRenderSurfaceInit);
    LIB_FUNCTION("vRxf4d0ulPs", "libSceFont", 1, "libSceFont", sceFontRenderSurfaceSetScissor);
    LIB_FUNCTION("0hr-w30SjiI", "libSceFont", 1, "libSceFont", sceFontRenderSurfaceSetStyleFrame);
    LIB_FUNCTION("TMtqoFQjjbA", "libSceFont", 1, "libSceFont", sceFontSetEffectSlant);
    LIB_FUNCTION("v0phZwa4R5o", "libSceFont", 1, "libSceFont", sceFontSetEffectWeight);
    LIB_FUNCTION("kihFGYJee7o", "libSceFont", 1, "libSceFont", sceFontSetFontsOpenMode);
    LIB_FUNCTION("I1acwR7Qp8E", "libSceFont", 1, "libSceFont", sceFontSetResolutionDpi);
    LIB_FUNCTION("N1EBMeGhf7E", "libSceFont", 1, "libSceFont", sceFontSetScalePixel);
    LIB_FUNCTION("sw65+7wXCKE", "libSceFont", 1, "libSceFont", sceFontSetScalePoint);
    LIB_FUNCTION("PxSR9UfJ+SQ", "libSceFont", 1, "libSceFont", sceFontSetScriptLanguage);
    LIB_FUNCTION("SnsZua35ngs", "libSceFont", 1, "libSceFont", sceFontSetTypographicDesign);
    LIB_FUNCTION("lz9y9UFO2UU", "libSceFont", 1, "libSceFont", sceFontSetupRenderEffectSlant);
    LIB_FUNCTION("XIGorvLusDQ", "libSceFont", 1, "libSceFont", sceFontSetupRenderEffectWeight);
    LIB_FUNCTION("6vGCkkQJOcI", "libSceFont", 1, "libSceFont", sceFontSetupRenderScalePixel);
    LIB_FUNCTION("nMZid4oDfi4", "libSceFont", 1, "libSceFont", sceFontSetupRenderScalePoint);
    LIB_FUNCTION("ObkDGDBsVtw", "libSceFont", 1, "libSceFont", sceFontStringGetTerminateCode);
    LIB_FUNCTION("+B-xlbiWDJ4", "libSceFont", 1, "libSceFont", sceFontStringGetTerminateOrder);
    LIB_FUNCTION("o1vIEHeb6tw", "libSceFont", 1, "libSceFont", sceFontStringGetWritingForm);
    LIB_FUNCTION("hq5LffQjz-s", "libSceFont", 1, "libSceFont", sceFontStringRefersRenderCharacters);
    LIB_FUNCTION("Avv7OApgCJk", "libSceFont", 1, "libSceFont", sceFontStringRefersTextCharacters);
    LIB_FUNCTION("lOfduYnjgbo", "libSceFont", 1, "libSceFont", sceFontStyleFrameGetEffectSlant);
    LIB_FUNCTION("HIUdjR-+Wl8", "libSceFont", 1, "libSceFont", sceFontStyleFrameGetEffectWeight);
    LIB_FUNCTION("VSw18Aqzl0U", "libSceFont", 1, "libSceFont", sceFontStyleFrameGetResolutionDpi);
    LIB_FUNCTION("2QfqfeLblbg", "libSceFont", 1, "libSceFont", sceFontStyleFrameGetScalePixel);
    LIB_FUNCTION("7x2xKiiB7MA", "libSceFont", 1, "libSceFont", sceFontStyleFrameGetScalePoint);
    LIB_FUNCTION("la2AOWnHEAc", "libSceFont", 1, "libSceFont", sceFontStyleFrameInit);
    LIB_FUNCTION("394sckksiCU", "libSceFont", 1, "libSceFont", sceFontStyleFrameSetEffectSlant);
    LIB_FUNCTION("faw77-pEBmU", "libSceFont", 1, "libSceFont", sceFontStyleFrameSetEffectWeight);
    LIB_FUNCTION("dB4-3Wdwls8", "libSceFont", 1, "libSceFont", sceFontStyleFrameSetResolutionDpi);
    LIB_FUNCTION("da4rQ4-+p-4", "libSceFont", 1, "libSceFont", sceFontStyleFrameSetScalePixel);
    LIB_FUNCTION("O997laxY-Ys", "libSceFont", 1, "libSceFont", sceFontStyleFrameSetScalePoint);
    LIB_FUNCTION("dUmABkAnVgk", "libSceFont", 1, "libSceFont", sceFontStyleFrameUnsetEffectSlant);
    LIB_FUNCTION("hwsuXgmKdaw", "libSceFont", 1, "libSceFont", sceFontStyleFrameUnsetEffectWeight);
    LIB_FUNCTION("bePC0L0vQWY", "libSceFont", 1, "libSceFont", sceFontStyleFrameUnsetScale);
    LIB_FUNCTION("mz2iTY0MK4A", "libSceFont", 1, "libSceFont", sceFontSupportExternalFonts);
    LIB_FUNCTION("71w5DzObuZI", "libSceFont", 1, "libSceFont", sceFontSupportGlyphs);
    LIB_FUNCTION("SsRbbCiWoGw", "libSceFont", 1, "libSceFont", sceFontSupportSystemFonts);
    LIB_FUNCTION("IPoYwwlMx-g", "libSceFont", 1, "libSceFont", sceFontTextCodesStepBack);
    LIB_FUNCTION("olSmXY+XP1E", "libSceFont", 1, "libSceFont", sceFontTextCodesStepNext);
    LIB_FUNCTION("oaJ1BpN2FQk", "libSceFont", 1, "libSceFont", sceFontTextSourceInit);
    LIB_FUNCTION("VRFd3diReec", "libSceFont", 1, "libSceFont", sceFontTextSourceRewind);
    LIB_FUNCTION("eCRMCSk96NU", "libSceFont", 1, "libSceFont", sceFontTextSourceSetDefaultFont);
    LIB_FUNCTION("OqQKX0h5COw", "libSceFont", 1, "libSceFont", sceFontTextSourceSetWritingForm);
    LIB_FUNCTION("1QjhKxrsOB8", "libSceFont", 1, "libSceFont", sceFontUnbindRenderer);
    LIB_FUNCTION("H-FNq8isKE0", "libSceFont", 1, "libSceFont", sceFontWordsFindWordCharacters);
    LIB_FUNCTION("fljdejMcG1c", "libSceFont", 1, "libSceFont", sceFontWritingGetRenderMetrics);
    LIB_FUNCTION("fD5rqhEXKYQ", "libSceFont", 1, "libSceFont", sceFontWritingInit);
    LIB_FUNCTION("1+DgKL0haWQ", "libSceFont", 1, "libSceFont", sceFontWritingLineClear);
    LIB_FUNCTION("JQKWIsS9joE", "libSceFont", 1, "libSceFont", sceFontWritingLineGetOrderingSpace);
    LIB_FUNCTION("nlU2VnfpqTM", "libSceFont", 1, "libSceFont", sceFontWritingLineGetRenderMetrics);
    LIB_FUNCTION("+FYcYefsVX0", "libSceFont", 1, "libSceFont", sceFontWritingLineRefersRenderStep);
    LIB_FUNCTION("wyKFUOWdu3Q", "libSceFont", 1, "libSceFont", sceFontWritingLineWritesOrder);
    LIB_FUNCTION("W-2WOXEHGck", "libSceFont", 1, "libSceFont", sceFontWritingRefersRenderStep);
    LIB_FUNCTION("f4Onl7efPEY", "libSceFont", 1, "libSceFont",
                 sceFontWritingRefersRenderStepCharacter);
    LIB_FUNCTION("BbCZjJizU4A", "libSceFont", 1, "libSceFont", sceFontWritingSetMaskInvisible);
    LIB_FUNCTION("APTXePHIjLM", "libSceFont", 1, "libSceFont", Func_00F4D778F1C88CB3);
    LIB_FUNCTION("A8ZQAl+7Dec", "libSceFont", 1, "libSceFont", Func_03C650025FBB0DE7);
    LIB_FUNCTION("B+q4oWOyfho", "libSceFont", 1, "libSceFont", Func_07EAB8A163B27E1A);
    LIB_FUNCTION("CUCOiOT5fOM", "libSceFont", 1, "libSceFont", Func_09408E88E4F97CE3);
    LIB_FUNCTION("CfkpBe2CqBQ", "libSceFont", 1, "libSceFont", Func_09F92905ED82A814);
    LIB_FUNCTION("DRQs7hqyGr4", "libSceFont", 1, "libSceFont", Func_0D142CEE1AB21ABE);
    LIB_FUNCTION("FL0unhGcFvI", "libSceFont", 1, "libSceFont", Func_14BD2E9E119C16F2);
    LIB_FUNCTION("GsU8nt6ujXU", "libSceFont", 1, "libSceFont", Func_1AC53C9EDEAE8D75);
    LIB_FUNCTION("HUARhdXiTD0", "libSceFont", 1, "libSceFont", Func_1D401185D5E24C3D);
    LIB_FUNCTION("HoPNIMLMmW8", "libSceFont", 1, "libSceFont", Func_1E83CD20C2CC996F);
    LIB_FUNCTION("MUsfdluf54o", "libSceFont", 1, "libSceFont", Func_314B1F765B9FE78A);
    LIB_FUNCTION("NQ5nJf7eKeE", "libSceFont", 1, "libSceFont", Func_350E6725FEDE29E1);
    LIB_FUNCTION("Pbdz8KYEvzk", "libSceFont", 1, "libSceFont", Func_3DB773F0A604BF39);
    LIB_FUNCTION("T-Sd0h4xGxw", "libSceFont", 1, "libSceFont", Func_4FF49DD21E311B1C);
    LIB_FUNCTION("UmKHZkpJOYE", "libSceFont", 1, "libSceFont", Func_526287664A493981);
    LIB_FUNCTION("VcpxjbyEpuk", "libSceFont", 1, "libSceFont", Func_55CA718DBC84A6E9);
    LIB_FUNCTION("Vj-F8HBqi00", "libSceFont", 1, "libSceFont", Func_563FC5F0706A8B4D);
    LIB_FUNCTION("Vp4uzTQpD0U", "libSceFont", 1, "libSceFont", Func_569E2ECD34290F45);
    LIB_FUNCTION("WgR3W2vkdoU", "libSceFont", 1, "libSceFont", Func_5A04775B6BE47685);
    LIB_FUNCTION("X9k7yrb3l1A", "libSceFont", 1, "libSceFont", Func_5FD93BCAB6F79750);
    LIB_FUNCTION("YrU5j4ZL07Q", "libSceFont", 1, "libSceFont", Func_62B5398F864BD3B4);
    LIB_FUNCTION("b5AQKU2CI2c", "libSceFont", 1, "libSceFont", Func_6F9010294D822367);
    LIB_FUNCTION("d1fpR0I6emc", "libSceFont", 1, "libSceFont", Func_7757E947423A7A67);
    LIB_FUNCTION("fga6Ugd-VPo", "libSceFont", 1, "libSceFont", Func_7E06BA52077F54FA);
    LIB_FUNCTION("k7Nt6gITEdY", "libSceFont", 1, "libSceFont", Func_93B36DEA021311D6);
    LIB_FUNCTION("lLCJHnERWYo", "libSceFont", 1, "libSceFont", Func_94B0891E7111598A);
    LIB_FUNCTION("l4XJEowv580", "libSceFont", 1, "libSceFont", Func_9785C9128C2FE7CD);
    LIB_FUNCTION("l9+8m2X7wOE", "libSceFont", 1, "libSceFont", Func_97DFBC9B65FBC0E1);
    LIB_FUNCTION("rNlxdAXX08o", "libSceFont", 1, "libSceFont", Func_ACD9717405D7D3CA);
    LIB_FUNCTION("sZqK7D-U8W8", "libSceFont", 1, "libSceFont", Func_B19A8AEC3FD4F16F);
    LIB_FUNCTION("wQ9IitfPED0", "libSceFont", 1, "libSceFont", Func_C10F488AD7CF103D);
    LIB_FUNCTION("0Mi1-0poJsc", "libSceFont", 1, "libSceFont", Func_D0C8B5FF4A6826C7);
    LIB_FUNCTION("5I080Bw0KjM", "libSceFont", 1, "libSceFont", Func_E48D3CD01C342A33);
    LIB_FUNCTION("6slrIYa3HhQ", "libSceFont", 1, "libSceFont", Func_EAC96B2186B71E14);
    LIB_FUNCTION("-keIqW70YlY", "libSceFont", 1, "libSceFont", Func_FE4788A96EF46256);
    LIB_FUNCTION("-n5a6V0wWPU", "libSceFont", 1, "libSceFont", Func_FE7E5AE95D3058F5);
};

} // namespace Libraries::Font
