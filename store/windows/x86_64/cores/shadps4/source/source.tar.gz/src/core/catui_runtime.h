// SPDX-License-Identifier: GPL-2.0-or-later
// Narrow, dependency-free hooks used when shadPS4 is embedded by CATUI.
#pragma once

#include <cstddef>
#include <cstdint>
#include <mutex>

namespace Core::CatuiRuntime {

struct InputState {
    std::int16_t buttons[17]{};
    std::int16_t axes[4]{};
    std::int16_t touch_x{};
    std::int16_t touch_y{};
    bool touch_pressed{};
    float gyro[3]{};
};

struct Callbacks {
    void* user{};
    void (*video_rgba)(void* user, const std::uint8_t* pixels, std::uint32_t width,
                       std::uint32_t height, std::size_t pitch){};
    bool (*audio)(void* user, int port_id, const void* samples, std::size_t frames,
                  std::uint32_t channels, bool is_float, bool is_std, const int* channel_layout,
                  const int* volume){};
    bool (*rumble)(void* user, std::uint8_t small_motor, std::uint8_t large_motor){};
};

inline std::mutex callbacks_mutex{};
inline Callbacks callbacks{};

inline void SetCallbacks(const Callbacks& value) {
    std::scoped_lock lock{callbacks_mutex};
    callbacks = value;
}

inline void ClearCallbacks() {
    SetCallbacks({});
}

inline bool WantsSoftwareFrames() {
    std::scoped_lock lock{callbacks_mutex};
    return callbacks.video_rgba != nullptr;
}

inline bool HasAudioCallback() {
    std::scoped_lock lock{callbacks_mutex};
    return callbacks.audio != nullptr;
}

inline void SubmitSoftwareFrame(const std::uint8_t* pixels, const std::uint32_t width,
                                const std::uint32_t height, const std::size_t pitch) {
    Callbacks current{};
    {
        std::scoped_lock lock{callbacks_mutex};
        current = callbacks;
    }
    if (current.video_rgba) {
        current.video_rgba(current.user, pixels, width, height, pitch);
    }
}

inline bool SubmitAudio(const int port_id, const void* samples, const std::size_t frames,
                        const std::uint32_t channels, const bool is_float, const bool is_std,
                        const int* channel_layout, const int* volume) {
    Callbacks current{};
    {
        std::scoped_lock lock{callbacks_mutex};
        current = callbacks;
    }
    return current.audio &&
           current.audio(current.user, port_id, samples, frames, channels, is_float, is_std,
                         channel_layout, volume);
}

inline bool SubmitRumble(const std::uint8_t small_motor, const std::uint8_t large_motor) {
    Callbacks current{};
    {
        std::scoped_lock lock{callbacks_mutex};
        current = callbacks;
    }
    return current.rumble && current.rumble(current.user, small_motor, large_motor);
}

} // namespace Core::CatuiRuntime
