# CATUI shadPS4 Libretro maintenance

This document is the update contract for an agent or developer changing the
CATUI heavy core. The core is an isolated Libretro boundary around shadPS4;
the renderer is Vulkan only. Do not add DirectX, OpenGL, software, or fake
accuracy options to the CATUI profile unless the upstream implementation is
actually wired through the boundary.

## Updating upstream safely

Keep the CATUI work as a small patch on top of upstream. Before rebasing,
record the current revision and preserve unrelated worktree changes:

```text
cd C:\Users\arthi\Projetos\shadPS4
rtk git status --short
rtk git fetch origin
rtk git log -1 --oneline
```

After updating, inspect conflicts instead of resetting the worktree. The
CATUI-owned seam is limited to `src/libretro/`, `src/core/catui_runtime.h`,
and the narrowly required lifecycle/readback changes in the emulator, SDL
window, signal, and Vulkan presenter paths. Keep the Libretro API free of
upstream-private types and keep the owner thread responsible for all shadPS4
window/renderer work.

## Build and validation

Configure or reuse the clang-cl build directory, then build the DLL and both
smoke/probe targets:

```text
rtk "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe" -C build-clang-catui shadps4_libretro catui_shadps4_libretro_smoke catui_shadps4_libretro_real_probe -j 4
```

Use an extracted title executable, never a PKG as the boot path. PKG/FPKG are
installation containers: install the base package and every compatible update
into a title directory, then boot `installed\\<TITLE_ID>-base\\uroot\\eboot.bin`
with the update overlay `uroot-UPDATE` present. Do not modify or redistribute
copyrighted package contents.

The mandatory gate is:

1. Vulkan is selected and reported by the environment callback.
2. The owner thread starts and stops without a hang or callback-after-clear.
3. At least two decoded PNG frames are visible, non-black, and have different
   hashes.
4. Audio callbacks remain active during the run.
5. `git diff --check` passes in both repositories.

The real probe is a video gate, not a performance result. It validates
`retro_unload_game` and `retro_deinit` first, then uses an explicit process
boundary because upstream Vulkan/HLE singletons are process-lifetime objects.
Do not use that boundary in the Libretro core itself or treat it as a shortcut
for joining the owner thread.

## CATUI catalog rules

Update `addons/catui-libretros/core_profile_catalog.gd` only with options that
map to real shadPS4 settings. Current presets vary resolution scale, present
mode, FSR, and RCAS. Do not reintroduce invented AA, anisotropic filtering,
CPU/GPU accuracy, multicore, generic scaling, or shader-cache toggles.

Record the upstream commit, compiler, GPU/driver, title ID, app version,
renderer, frame hashes, and any known title-specific failure in
`documents/catui-libretro-benchmark.md` and the CATUI `PS4_CORE.md` summary.
