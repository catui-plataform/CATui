# CATUI shadPS4 Libretro port

This directory describes the isolated CATUI integration for shadPS4. The
integration is intentionally kept at the boundary of the emulator: CATUI owns
the Libretro ABI, controller mapping, frame pacing, and lifecycle, while
shadPS4 owns PS4 guest execution and Vulkan rendering.

## Current upstream base

The current CATUI work is based on upstream release `v.0.20.0`
(`529ceb32f5546b820588f194b903cc39d08015fe`, 2026-10-14). Keep the small
CATUI patch set isolated at the Libretro boundary.

## CATUI Proxy

The Windows isolation system is called **CATUI Proxy**. Its registered DLL
launches one disposable host process per session and exports
`retro_get_process_id` for that exact live host. CATUI samples CPU, GPU-engine
utilization and working-set RAM against this PID, never by window title.
`retro_get_game_fps` reports the rate of video frames published by the host,
including publications skipped by frontend polling. This is host video FPS,
not a guest simulation counter or CATUI presentation FPS. Paused/stopped
sessions report zero FPS and unavailable host resources. Other cores retain
the normal in-process metrics path. Keep proxy, host and engine together when
packaging the store archive.

## Required Libretro contract

The core must export the standard Libretro entry points. The current validation
implementation retains shadPS4's SDL Vulkan surface because its renderer still
owns the swapchain; replacing it with the frontend's negotiated Vulkan device
is required before the hardware fast path is complete. The video callback
must receive a complete frame before the callback returns. The preferred
format is `RETRO_PIXEL_FORMAT_XRGB8888`; the fallback is `RGB565`.

## Renderer choice

The CATUI core uses shadPS4's Vulkan renderer. DirectX is not exposed as a
pretend backend: shadPS4's guest GPU path, shader cache, pipeline cache, and
image ownership are Vulkan-based upstream. The intended fast path keeps Vulkan
images on the owner thread and hands them to a compatible CATUI hardware
session, but it is not implemented yet. The current core copies the composed
Vulkan image through a staging buffer to XRGB8888 for software-video callbacks
and mandatory PNG validation. Do not treat readback benchmark numbers as the
final maximum-performance path.

The frontend supplies:

- Vulkan, OpenGL, or software video through the CATUI session;
- one DualShock 4 pad per port, including analog sticks, triggers, touchpad
  click, motion, and rumble;
- an audio callback with a bounded queue;
- a content path to an installed `eboot.bin`, `SELF`, `ELF`, or `ZAR`.

`PKG` and `FPKG` are installation containers, not directly bootable content.
Install the base into `uroot`, install the update into its sibling
`uroot-UPDATE`, and pass the base `uroot/eboot.bin` to the core. The source
packages remain unchanged.

The core must report geometry with `retro_get_system_av_info`, keep a stable
pixel aspect ratio, and return `pitch` in bytes. A frame counter alone is not
evidence of video: CATUI validation requires a non-null frame, non-zero width
and height, a changing checksum across two frames, and a saved PNG.

## Performance policy

The CATUI profile defaults to Vulkan, native resolution, persistent pipeline
caches, FIFO presentation, and Windows static guest-red-zone patching. Only
settings implemented by the current shadPS4 upstream are advertised: output
and internal resolution, present mode, VBlank, PS4 Pro mode, FSR/RCAS, HDR,
GPU selection, pipeline caches, readback/DMA controls, Vulkan diagnostics,
and motion/touch input. Do not add speculative anti-aliasing, anisotropic,
CPU/GPU accuracy, async, or latency switches unless upstream gains a real
setting and the backend applies it.

Do not copy a GPU image to the CPU every frame when a hardware path is active.
Use a persistent staging/readback resource only for screenshots or when the
frontend explicitly requests software video. Keep all Vulkan objects on the
owner thread and defer destruction until the last CATUI frame is released.

## Updating shadPS4 safely

1. Create a fresh worktree at the new upstream commit.
2. Apply only the CATUI patch series; do not edit generated files or vendored
   dependencies.
3. Reconcile changes in emulator startup, renderer ownership, input, and
   guest memory before compiling the Libretro target.
4. Build both Debug and Release x86_64 targets.
5. Run the ABI smoke test, then boot a known-good homebrew ELF or installed
   title for at least two seconds.
6. Save the first visible frame and compare its checksum and dimensions with
   the validation record. A successful process exit without a frame is a
   failure.
7. Run the CATUI heavy-core lifecycle test and the benchmark protocol before
   replacing the installed DLL.

Keep the upstream commit, CATUI patch hash, compiler version, GPU driver,
game/title ID, and benchmark JSON together. If any check fails, keep the old
core installed and report the failure instead of silently falling back to an
unrelated emulator.

## Initial validation record

On 2026-09-23, the supported Windows build path used CMake 4.2.3 and
clang-cl 23.1.2 with `ENABLE_CATUI_LIBRETRO=ON`. It produced both
`shadps4.exe` and `shadps4_libretro.dll`. Keep the Clang check before the
plain `_MSC_VER` check for `PS4_SYSV_ABI`: clang-cl defines `_MSC_VER`, but
PS4 guest entry points still require `__attribute__((sysv_abi))`. Host
libraries such as Windows libusb need a narrow host-ABI thunk when they call
a guest-ABI callback; changing the guest ABI globally causes a crash as soon
as the first game thread starts.

The isolated `retro_*` ABI was subsequently built and smoke-tested with a
synthetic backend: two 1280x720 XRGB8888 callbacks arrived through
`retro_run`, the lifecycle unloaded cleanly, and FFmpeg decoded the captured
PNG (`SHA-256 7D61B1C37C76E3EA4AAB0DC7D0B1669C6F6C8685C0A4356A987F23E4FC2E443`).
This proves callback plumbing and image encoding only; it is not evidence that
shadPS4 booted a PS4 title or that Vulkan guest rendering is connected.

`catui_shadps4_libretro_real_probe` is the real-title gate. It links the actual
DLL, boots the supplied content path, rejects near-black boot clears, and writes
the first and last accepted frames as PNG. A missing file, fewer than two
visible frames, identical hashes, or a non-zero exit is a failed validation.

Gravity Rush 2 (`CUSA04943`) was extracted without modifying the source PKGs.
The base lives in an `uroot` directory and update 1.11 in the sibling
`uroot-UPDATE`, matching shadPS4's overlay lookup. The standalone emulator
recognizes app version 01.11, creates a Vulkan 1.3.260 device on the Radeon RX
580, initializes video/audio/input, and begins compiling compute pipelines.
It then raises Windows exception `0xc0000005` after roughly three seconds.
Desktop captures at three and four seconds show a completely black shadPS4
client area, and the process is gone by the five-second capture. Therefore no
real game PNG, FPS result, or benchmark has passed yet. The local firmware
module directory is also empty and the emulator warns that dumped system
fonts are missing; retest with legally dumped modules before treating the
remaining failure as a renderer regression.

At upstream `7910dfe1`, the real Libretro DLL loads the Gravity Rush 2
`eboot.bin`, selects Vulkan, starts audio/game/render threads, and compiles the
first compute pipelines. Its real-title probe still terminates with exception
`0xc0000005` before a video callback arrives; the standalone executable reaches
the same guest crash. No real non-black PNG or benchmark result is claimed until
that runtime/title failure is resolved.

The validation machine currently has no legally dumped `sys_modules`, `font`,
or `font2` data. Before attributing the remaining crash to CATUI, repeat the
real probe with the upstream-required firmware modules and fonts dumped from
the user's own PS4. These files must never be downloaded, committed, bundled,
or copied into a release artifact by the update process.

### Sonic Mania real-title result (2026-09-24)

The user's existing open-source LibOrbisPkg `PkgTool` extracted Sonic Mania
`CUSA07023` without modifying either source PKG. Base 1.01 is installed at
`CUSA07023-base/uroot`; update 1.03 is installed at the required sibling
`CUSA07023-base/uroot-UPDATE`. `param.sfo` and the base icon were extracted
from their PKG metadata entries because they are outside the inner PFS image.

The real Libretro probe selected Vulkan 1.3.260 on the Radeon RX 580, detected
app version 01.03, reached the title sequence, and captured two distinct,
decodable 1280x720 PNGs. Their SHA-256 values are
`F3388AC4B3F6914BC16348AEA748ECC9A1BD1A10C107ADD5BE2F382CDB5C18DF` and
`E36AF7C9D06D0AB4CBE7237BF87686DBAD02F1E04E3603B0F9329C21DD18F9B2`.
This passes the real-video gate. The final probe returns zero after the
Libretro unload/deinit lifecycle and the 30-second Vulkan benchmarks pass all
three presets: Performance 39.484 FPS, Balanced 39.144 FPS, and Quality
39.553 FPS. The harness uses a process boundary only after unload/deinit to
avoid re-entering upstream process-lifetime singletons during DLL detach.

The final DLL SHA-256 is
`7b3cb78a85bafe71a6859ba61301bd6a7c2cc9bcd3cd424f34c72e485158a14b`.

Latest retained validation PNGs are `sonic-validation.png` and
`sonic-validation.last.png`; their SHA-256 values are
`73cb29e37e79a7a76e39b4ad62588f6e35f2e2b7377f79d22ad1938b00267396` and
`a5cd31674dc66a8ecba6c3d7a16b22adb7ab3b8d2ec88eb8908475c9d0809c76`.

## Legal and test data

CATUI does not redistribute firmware, keys, PKG/FPKG files, or commercial
games. A local Gravity Rush 2 package may be used only by the owner of the
content and only after shadPS4 supports that title. Eden is a Nintendo Switch
emulator and is not a valid PS4 comparator for Gravity Rush 2; it may be used
for a separate CATUI heavy-core/frame-pacing smoke benchmark only.
