<!--
SPDX-FileCopyrightText: 2024 shadPS4 Emulator Project
SPDX-License-Identifier: GPL-2.0-or-later
-->

## Build shadPS4 for Linux

First and foremost, Clang 19 is the **recommended compiler** as it is used for official Linux builds and CI. GCC 14 is also tested by CI. If you build with GCC, you might encounter issues — please report any you find. Additionally, if you choose to use GCC, please build shadPS4 with Clang at least once before creating an `[APP BUG]` issue or submitting a pull request.

## Preparatory steps

### Installing dependencies

#### Debian & Ubuntu

Make sure Clang 19 is installed. On Ubuntu 24.04, the default `clang` package may still provide Clang 18, while the current Linux CI uses Clang 19 from apt.llvm.org.

For Ubuntu 24.04, add the LLVM 19 repository first:

```bash
wget -O - https://apt.llvm.org/llvm-snapshot.gpg.key | sudo apt-key add -
sudo add-apt-repository 'deb http://apt.llvm.org/noble/ llvm-toolchain-noble-19 main'
sudo apt update
```

Then install the build dependencies:

```bash
sudo apt install build-essential clang-19 git cmake libasound2-dev \
    libpulse-dev libopenal-dev libssl-dev zlib1g-dev libedit-dev \
    libudev-dev libevdev-dev libsdl2-dev libjack-dev libsndio-dev \
    libvulkan-dev vulkan-validationlayers libpng-dev
```

#### Fedora

```bash
sudo dnf install ninja-build clang git cmake libatomic alsa-lib-devel \
    pipewire-jack-audio-connection-kit-devel openal-soft-devel \
    openssl-devel libevdev-devel libudev-devel libXext-devel \
    libXcursor-devel libXi-devel libXrandr-devel libXScrnSaver-devel \
    vulkan-devel vulkan-validation-layers libpng-devel libuuid-devel
```

#### Arch Linux

```bash
sudo pacman -S base-devel clang git cmake sndio jack2 openal \
    sdl2 vulkan-validation-layers libpng
```

**Note**: The `shadps4-git` AUR package is not maintained by any of the developers, and it uses the default compiler, which is often set to GCC. Use at your own discretion.

#### OpenSUSE

```bash
sudo zypper install clang git cmake libasound2 libpulse-devel \
    libsndio7 libjack-devel openal-soft-devel libopenssl-devel \
    zlib-devel libedit-devel systemd-devel libevdev-devel \
    vulkan-devel vulkan-validationlayers libpng-devel
```

#### Nix Flake Development Shell
```bash
nix develop
cmake -S . -B build/
ln -s ./build/compile_commands.json .
```

#### Nix Flake Build
```bash
nix build .?submodules=1#debug
```
```bash
nix build .?submodules=1#release
```
```bash
nix build .?submodules=1#releaseWithDebInfo
```
#### Other Linux distributions

You can try one of two methods:

- Search the packages by name and install them with your package manager, or
- Install [distrobox](https://distrobox.it/), create a container using any of the distributions cited above as a base, for Arch Linux you'd do:

```bash
distrobox create --name archlinux --init --image archlinux:latest
```

and install the dependencies on that container as cited above.
This option is **highly recommended** for distributions with immutable/atomic filesystems (example: Fedora Kinoite, SteamOS).

### Cloning
The project uses submodules to manage dependencies, and they need to be initialized before you can build the project. To achieve this, make sure you've cloned the repository with the --recursive flag

```bash
git clone --recursive https://github.com/shadps4-emu/shadPS4.git
cd shadPS4
```

## Building

There are 3 options you can choose from. Option 1 is **highly recommended**.

#### Option 1: Terminal-only

1. Generate the build directory in the shadPS4 directory.

```bash
cmake -S . -B build/ -DCMAKE_C_COMPILER=clang-19 -DCMAKE_CXX_COMPILER=clang++-19
```

To change the build type (for debugging), add `-DCMAKE_BUILD_TYPE=Debug`.

1. Use CMake to build the project:

```bash
cmake --build ./build --parallel$(nproc)
```

If your computer freezes during this step, this could be caused by excessive system resource usage. In that case, remove `--parallel$(nproc)`.

Now run the emulator to get the list of options:

```bash
./build/shadps4
```

You can also specify the Game ID as an argument for which game to boot, as long as the folder containing the games is specified in config.toml (example: Bloodborne (US) is CUSA00900).
#### Option 2: Configuring with cmake-gui

`cmake-gui` should be installed by default alongside `cmake`, if not search for the package in your package manager and install it.

Open `cmake-gui` and specify the source code and build directories. If you cloned the source code to your Home directory, it would be `/home/user/shadPS4` and `/home/user/shadPS4/build`.

Click on Configure, select "Unix Makefiles", select "Specify native compilers", click Next and choose `clang-19` and `clang++-19` as the C and CXX compilers. Click on Finish and let it configure the project.

Now every option should be displayed in red. Change anything you want, then click on Generate to make the changes permanent, then open a terminal window and do step 2 of Option 1.

#### Option 3: Visual Studio Code

This option is pretty convoluted and should only be used if you have VSCode as your default IDE, or just prefer building and debugging projects through it. This also assumes that you're using an Arch Linux environment, as the naming for some options might differ from other distros.

[Download Visual Studio Code for your platform](https://code.visualstudio.com/download), or use [Code - OSS](https://github.com/microsoft/vscode) if you'd like. Code - OSS is available on most Linux distributions' package repositories (on Arch Linux it is simply named `code`).

Once set up, go to Extensions and install "CMake Tools":

![image](https://raw.githubusercontent.com/shadps4-emu/shadPS4/refs/heads/main/documents/Screenshots/Linux/3.png)

You can also install other CMake and Clang related extensions if you'd like, but this one is what enables you to configure and build CMake projects directly within VSCode.

Go to Settings, filter by `@ext:ms-vscode.cmake-tools configure` and disable this option:

![image](https://raw.githubusercontent.com/shadps4-emu/shadPS4/refs/heads/main/documents/Screenshots/Linux/1.png)

On the CMake tab, change the options as you wish, but make sure that it looks similar to or exactly like this:

![image](https://raw.githubusercontent.com/shadps4-emu/shadPS4/refs/heads/main/documents/Screenshots/Linux/4.png)

When hovering over Project Status > Configure, there should be an icon titled "Configure". Click on it and let it configure the project, then do the same for Project Status > Build.

If you want to debug it, change the build type under Project Status > Configure to Debug (it should be the default) and compile it, then click on the icon in Project Status > Debug. If you simply want to launch the shadPS4 executable from within VSCode, click on the icon in Project Status > Launch.

Don't forget to change the launch target for both options to the shadPS4 executable inside shadPS4/build:

![image](https://raw.githubusercontent.com/shadps4-emu/shadPS4/refs/heads/main/documents/Screenshots/Linux/5.png)
