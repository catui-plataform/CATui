#ifndef __CDI_H__
#define __CDI_H__

#include "../../oslib/storage.h"

/* Basic structures */

typedef struct image_s
       {
       long               header_offset;
       long               header_position;
       long               length;
       unsigned long      version;
       unsigned short int sessions;
       unsigned short int tracks;
       unsigned short int remaining_sessions;
       unsigned short int remaining_tracks;
       unsigned short int global_current_session;
       } image_s;

typedef struct track_s
       {
       unsigned short int global_current_track;
       unsigned short int number;
       long               position;
       unsigned long      mode;
       unsigned long      sector_size;
       unsigned long      sector_size_value;
       long               length;
       long               pregap_length;
       long               total_length;
       unsigned long      start_lba;
       unsigned char      filename_length;
       } track_s;


#define CDI_V2  0x80000004
#define CDI_V3  0x80000005
#define CDI_V35 0x80000006

unsigned long ask_type(hostfs::File *fsource, long header_position);
bool CDI_init(hostfs::File *fsource, image_s *image, const char *fsourcename);
bool CDI_get_sessions(hostfs::File *fsource, image_s *image);
bool CDI_get_tracks(hostfs::File *fsource, image_s *image);
bool CDI_read_track(hostfs::File *fsource, image_s *image, track_s *track);
void CDI_skip_next_session(hostfs::File *fsource, image_s *image);

#endif
